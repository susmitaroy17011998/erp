package com.example

import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.SemanticsMatcher
import androidx.compose.ui.test.assertCountEquals
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onFirst
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToIndex
import androidx.compose.ui.test.performScrollToNode
import com.example.erp.core.config.SupabaseConfig
import com.example.erp.core.i18n.AppLanguage
import com.example.erp.core.i18n.LocalAppLanguage
import com.example.erp.core.i18n.LocalAppStrings
import com.example.erp.core.i18n.stringsFor
import com.example.erp.core.model.AssignedClassLink
import com.example.erp.core.model.AuthSession
import com.example.erp.core.model.LinkedAccountProfile
import com.example.erp.core.model.LoadableState
import com.example.erp.core.model.SchoolClassItem
import com.example.erp.core.model.StaffDraft
import com.example.erp.core.model.StaffRecord
import com.example.erp.core.model.StaffRoutineSlot
import com.example.erp.core.model.StaffStatusFilter
import com.example.erp.core.model.UserProfile
import com.example.erp.core.model.UserRole
import com.example.erp.core.network.SupabaseClient
import com.example.erp.features.teachers.StaffDetailPayload
import com.example.erp.features.teachers.TeacherProfileContent
import com.example.erp.features.teachers.TeachersRepository
import com.example.erp.features.teachers.TeachersScreen
import com.example.erp.features.teachers.TeachersUiState
import com.example.erp.features.teachers.TeachersViewModel
import com.example.ui.theme.ShubhadishaErpTheme
import kotlinx.coroutines.test.runTest
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import okio.Buffer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class TeachersVerificationTest {

    @get:Rule
    val composeRule = createComposeRule()

    private val testConfig = SupabaseConfig(
        url = "https://mock-academy.supabase.co",
        anonKey = "sb_publishable_test_key_12345",
    )

    private data class RecordedCall(
        val method: String,
        val path: String,
        val query: String,
        val rangeHeader: String?,
        val authHeader: String?,
        val body: String,
    )

    private fun sessionFor(role: UserRole): AuthSession = AuthSession(
        accessToken = "jwt_${role.key}_token",
        refreshToken = "refresh_${role.key}",
        expiresAtEpochSeconds = 9999999999L,
        user = UserProfile(
            userId = "uid-${role.key}-1",
            email = "${role.key}@shubhadisha.edu.in",
            fullName = "Test ${role.key}",
            role = role,
            profileVerified = true,
        ),
    )

    private fun buildRepository(
        recordedCalls: MutableList<RecordedCall> = mutableListOf(),
    ): TeachersRepository {
        val interceptor = Interceptor { chain ->
            val req = chain.request()
            val buffer = Buffer()
            req.body?.writeTo(buffer)
            val reqBody = if (req.url.encodedPath.contains("/storage/v1/")) "<binary>" else buffer.readUtf8()
            val path = req.url.encodedPath
            val query = req.url.encodedQuery.orEmpty()

            recordedCalls.add(
                RecordedCall(
                    method = req.method,
                    path = path,
                    query = query,
                    rangeHeader = req.header("Range"),
                    authHeader = req.header("Authorization"),
                    body = reqBody,
                ),
            )

            var contentRange: String? = null
            val responseJson = when {
                path.endsWith("/rest/v1/classes") -> """[{"id":"cls-4","class_name":"Class IV","section":"A"}]"""
                path.endsWith("/rest/v1/staff") && req.method == "GET" -> {
                    val range = req.header("Range")
                    if (query.contains("id=eq.staff-inactive")) {
                        """[{"id":"staff-inactive","profile_id":null,"staff_name":"Former Staff","designation":"Teacher","is_active":false}]"""
                    } else if (range == "2-3") {
                        contentRange = "2-2/3"
                        """[{"id":"staff-3","profile_id":null,"staff_name":"Ananya Roy","designation":"Office Staff","phone":"9800000003","joining_date":"2024-02-10","photo_url":null,"is_active":true}]"""
                    } else {
                        contentRange = "0-1/3"
                        """
                        [
                          {"id":"staff-1","profile_id":"uid-teacher-1","staff_name":"Subir Sen","designation":"Principal","phone":"9800000001","joining_date":"2020-01-15","photo_url":"staff/subir.jpg","is_active":true},
                          {"id":"staff-2","profile_id":"uid-teacher-2","staff_name":"Mita Das","designation":"Teacher","phone":"9800000002","joining_date":"2022-05-01","photo_url":null,"is_active":true}
                        ]
                        """.trimIndent()
                    }
                }
                path.endsWith("/rest/v1/staff") && req.method == "POST" -> {
                    """[{"id":"staff-new-4","profile_id":"uid-teacher-1","staff_name":"Debashis Pal","designation":"Assistant Teacher","phone":"9800000009","joining_date":"2026-04-01","photo_url":"staff/debashis.jpg","is_active":true}]"""
                }
                path.endsWith("/rest/v1/staff") && req.method == "PATCH" -> {
                    """[{"id":"staff-1","profile_id":"uid-teacher-1","staff_name":"Subir Sen Updated","designation":"Principal","phone":"9800000001","joining_date":"2020-01-15","photo_url":"staff/subir.jpg","is_active":true}]"""
                }
                path.endsWith("/rest/v1/profiles") -> {
                    """[{"id":"uid-teacher-1","full_name":"Subir Sen","role":"teacher","phone":"9800000001","is_active":true}]"""
                }
                path.endsWith("/rest/v1/class_teachers") && req.method == "GET" -> {
                    """[{"id":"ct-1","teacher_profile_id":"uid-teacher-1","class_id":"cls-4","classes":{"id":"cls-4","class_name":"Class IV","section":"A"}}]"""
                }
                path.endsWith("/rest/v1/class_teachers") && (req.method == "POST" || req.method == "DELETE") -> "[]"
                path.endsWith("/rest/v1/class_routines") -> {
                    """[{"id":"cr-1","day":"Monday","class_name":"Class IV","period":1,"subject":"Bengali","teacher":"Subir Sen","routine_time":"10:30 AM","room":"102"}]"""
                }
                path.contains("/storage/v1/object/school-files/staff/") -> {
                    """{"Key":"school-files/staff/test.jpg"}"""
                }
                else -> "[]"
            }

            Response.Builder()
                .request(req)
                .protocol(Protocol.HTTP_1_1)
                .code(200)
                .message("OK")
                .apply {
                    if (contentRange != null) header("Content-Range", contentRange)
                }
                .body(responseJson.toResponseBody("application/json".toMediaType()))
                .build()
        }

        return TeachersRepository(SupabaseClient(config = testConfig, extraInterceptor = interceptor))
    }

    @Test
    fun `admin staff pagination search CRUD photo upload and class teacher links work`() = runTest {
        val calls = mutableListOf<RecordedCall>()
        val repo = buildRepository(calls)
        val admin = sessionFor(UserRole.ADMIN)

        val page1 = repo.fetchStaffPage(
            session = admin,
            designationFilter = "Teacher",
            statusFilter = StaffStatusFilter.ACTIVE,
            query = "Subir",
            offset = 0,
            limit = 2,
        ).getOrThrow()
        assertEquals(2, page1.items.size)
        assertEquals(3, page1.totalCount)
        assertTrue(page1.hasMore)
        assertTrue(calls.last().query.contains("designation=eq.Teacher"))
        assertTrue(calls.last().query.contains("is_active=eq.true"))
        assertEquals("0-1", calls.last().rangeHeader)

        val page2 = repo.fetchStaffPage(session = admin, offset = 2, limit = 2).getOrThrow()
        assertEquals(1, page2.items.size)
        assertFalse(page2.hasMore)

        val upload = repo.uploadStaffPhoto(
            session = admin,
            staffKey = "Debashis",
            imageBytes = byteArrayOf(1, 2, 3),
            timestampMillis = 777L,
        ).getOrThrow()
        assertEquals("staff/Debashis_777.jpg", upload.storagePath)
        assertTrue(upload.authenticatedUrl.contains("/storage/v1/object/authenticated/school-files/staff/Debashis_777.jpg"))

        val created = repo.createStaff(
            session = admin,
            draft = StaffDraft(
                profileId = "uid-teacher-1",
                staffName = "Debashis Pal",
                designation = "Assistant Teacher",
                photoPath = upload.storagePath,
            ),
        ).getOrThrow()
        assertEquals("staff-new-4", created.id)

        val updated = repo.updateStaff(
            session = admin,
            staffId = "staff-1",
            draft = StaffDraft(id = "staff-1", staffName = "Subir Sen Updated", designation = "Principal"),
        ).getOrThrow()
        assertEquals("Subir Sen Updated", updated.staffName)

        val detail = repo.fetchStaffDetail(admin, page1.items.first()).getOrThrow()
        assertEquals(1, detail.assignedClasses.size)
        assertEquals("Class IV", detail.assignedClasses.first().className)
        assertEquals(1, detail.routineSlots.size)
        assertEquals("Bengali", detail.routineSlots.first().subject)

        repo.assignClassTeacher(admin, "uid-teacher-1", "cls-4").getOrThrow()
        assertEquals("POST", calls.last().method)
        repo.removeClassTeacher(admin, detail.assignedClasses.first()).getOrThrow()
        assertEquals("DELETE", calls.last().method)
    }

    @Test
    fun `teacher can view active staff read only while student and parent are blocked`() = runTest {
        val calls = mutableListOf<RecordedCall>()
        val repo = buildRepository(calls)
        val teacher = sessionFor(UserRole.TEACHER)
        val student = sessionFor(UserRole.STUDENT)
        val parent = sessionFor(UserRole.PARENT)

        repo.fetchStaffPage(teacher).getOrThrow()
        assertTrue(calls.last().query.contains("is_active=eq.true"))

        assertTrue(
            repo.fetchStaffDetail(
                teacher,
                StaffRecord("staff-inactive", null, "Former", "Teacher", null, null, null, null, isActive = false),
            ).isFailure,
        )

        val beforeRestricted = calls.size
        assertTrue(repo.fetchStaffPage(student).isFailure)
        assertTrue(repo.fetchStaffPage(parent).isFailure)
        assertTrue(repo.createStaff(teacher, StaffDraft(staffName = "Blocked")).isFailure)
        assertTrue(repo.updateStaff(teacher, "staff-1", StaffDraft(id = "staff-1", staffName = "Blocked")).isFailure)
        assertTrue(repo.uploadStaffPhoto(teacher, "staff-1", byteArrayOf(1)).isFailure)
        assertTrue(repo.assignClassTeacher(teacher, "uid-teacher-1", "cls-4").isFailure)
        assertEquals(beforeRestricted, calls.size)
    }

    @Test
    fun `teachers screen enforces admin vs teacher ui permissions and bilingual profile tabs`() {
        val repo = buildRepository()
        val vm = TeachersViewModel(repository = repo, pageSize = 2)
        val sampleStaff = listOf(
            StaffRecord(
                id = "staff-1",
                profileId = "uid-teacher-1",
                staffName = "Subir Sen",
                designation = "Principal",
                phone = "9800000001",
                joiningDate = "2020-01-15",
                photoPath = null,
                photoUrl = null,
                isActive = true,
            ),
        )
        val uiState = TeachersUiState(
            classes = listOf(SchoolClassItem("cls-4", "Class IV", "A")),
            staffState = LoadableState.Success(sampleStaff),
            totalCount = 3,
            hasMore = true,
        )

        composeRule.setContent {
            CompositionLocalProvider(
                LocalAppLanguage provides AppLanguage.ENGLISH,
                LocalAppStrings provides stringsFor(AppLanguage.ENGLISH),
            ) {
                ShubhadishaErpTheme {
                    TeachersScreen(
                        session = sessionFor(UserRole.TEACHER),
                        uiState = uiState,
                        viewModel = vm,
                        onLanguageSelected = {},
                        onBack = {},
                    )
                }
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("teachers_role_banner").assertIsDisplayed()
        composeRule.onNodeWithText("Subir Sen").assertIsDisplayed()
        composeRule.onNode(SemanticsMatcher.keyIsDefined(SemanticsProperties.VerticalScrollAxisRange))
            .performScrollToNode(hasTestTag("load_more_staff_button"))
        composeRule.onNodeWithTag("load_more_staff_button").assertIsDisplayed()
        composeRule.onAllNodesWithTag("add_staff_fab").assertCountEquals(0)
        composeRule.onAllNodesWithTag("edit_staff_staff-1").assertCountEquals(0)
    }

    @Test
    fun `teacher profile displays bilingual assigned classes and routine tabs`() {
        val sample = StaffRecord(
            id = "staff-1",
            profileId = "uid-teacher-1",
            staffName = "Subir Sen",
            designation = "Principal",
            phone = "9800000001",
            joiningDate = "2020-01-15",
            photoPath = null,
            photoUrl = null,
            isActive = true,
        )
        val detail = StaffDetailPayload(
            staff = sample,
            linkedProfile = LinkedAccountProfile("uid-teacher-1", "Subir Sen", "9800000001", "teacher", true),
            assignedClasses = listOf(AssignedClassLink("ct-1", "uid-teacher-1", "cls-4", "Class IV", "A")),
            routineSlots = listOf(StaffRoutineSlot("cr-1", "Monday", "Class IV", 1, "Bengali", "Subir Sen", "10:30 AM", "102")),
        )

        composeRule.setContent {
            CompositionLocalProvider(
                LocalAppLanguage provides AppLanguage.BENGALI,
                LocalAppStrings provides stringsFor(AppLanguage.BENGALI),
            ) {
                ShubhadishaErpTheme(language = AppLanguage.BENGALI) {
                    TeacherProfileContent(
                        session = sessionFor(UserRole.ADMIN),
                        staff = sample,
                        detailState = LoadableState.Success(detail),
                        allClasses = listOf(SchoolClassItem("cls-4", "Class IV", "A")),
                        showAssignClassDialog = false,
                        isMutatingClassLink = false,
                        actionError = null,
                        showTopBar = true,
                        onBack = {},
                        onRefresh = {},
                        onEdit = {},
                        onOpenAssignClass = {},
                        onDismissAssignClass = {},
                        onConfirmAssignClass = {},
                        onRemoveClassAssignment = {},
                    )
                }
            }
        }

        composeRule.waitForIdle()
        composeRule.onAllNodesWithText("Subir Sen").onFirst().assertIsDisplayed()
        composeRule.onNodeWithTag("staff_profile_tab_1").performClick()
        composeRule.waitForIdle()
        composeRule.onNode(SemanticsMatcher.keyIsDefined(SemanticsProperties.VerticalScrollAxisRange))
            .performScrollToIndex(2)
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Class IV • A").assertIsDisplayed()
        composeRule.onNodeWithTag("staff_profile_tab_2").performClick()
        composeRule.waitForIdle()
        composeRule.onNode(SemanticsMatcher.keyIsDefined(SemanticsProperties.VerticalScrollAxisRange))
            .performScrollToIndex(2)
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Bengali").assertIsDisplayed()
    }
}
