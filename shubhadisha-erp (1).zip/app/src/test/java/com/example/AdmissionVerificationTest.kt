package com.example

import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import com.example.erp.core.config.SupabaseConfig
import com.example.erp.core.i18n.AppLanguage
import com.example.erp.core.i18n.LocalAppLanguage
import com.example.erp.core.i18n.LocalAppStrings
import com.example.erp.core.i18n.stringsFor
import com.example.erp.core.model.AdmissionEnquiryDraft
import com.example.erp.core.model.AdmissionEnquiryRecord
import com.example.erp.core.model.AdmissionStatus
import com.example.erp.core.model.AdmissionStatusFilter
import com.example.erp.core.model.AuthSession
import com.example.erp.core.model.LoadableState
import com.example.erp.core.model.UserProfile
import com.example.erp.core.model.UserRole
import com.example.erp.core.network.SupabaseClient
import com.example.erp.features.admission.AdmissionRepository
import com.example.erp.features.admission.AdmissionScreen
import com.example.erp.features.admission.AdmissionUiState
import com.example.erp.features.admission.AdmissionViewModel
import com.example.ui.theme.ShubhadishaErpTheme
import kotlinx.coroutines.test.runTest
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import okio.Buffer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AdmissionVerificationTest {

    @get:Rule
    val composeRule = createComposeRule()

    private val testConfig = SupabaseConfig(
        url = "https://mock-academy.supabase.co",
        anonKey = "sb_publishable_test_key_12345",
    )

    private fun sessionFor(role: UserRole): AuthSession = AuthSession(
        accessToken = "jwt_${role.key}",
        refreshToken = "ref_${role.key}",
        expiresAtEpochSeconds = 9999999999L,
        user = UserProfile(
            userId = "uid-${role.key}-1",
            email = "${role.key}@shubhadisha.edu.in",
            fullName = "User ${role.key}",
            role = role,
            profileVerified = true,
        ),
    )

    @Test
    fun `admission CRUD preserves extra record_data keys enrolls student and blocks non admin`() = runTest {
        val calls = mutableListOf<Triple<String, String, String>>()
        val interceptor = Interceptor { chain ->
            val req = chain.request()
            val buf = Buffer()
            req.body?.writeTo(buf)
            val bodyStr = buf.readUtf8()
            val path = req.url.encodedPath
            calls.add(Triple(req.method, path, bodyStr))

            val json = when {
                path.endsWith("/rest/v1/admission_enquiries") && req.method == "GET" -> {
                    """
                    [
                      {
                        "id": "adm-1",
                        "school_id": "shubhadisha",
                        "record_id": "ADM-001",
                        "record_data": {
                          "student_name": "Koushik Roy",
                          "guardian_name": "Tapan Roy",
                          "phone": "9831112233",
                          "applied_class": "Class II",
                          "status": "approved",
                          "legacy_custom_flag": "keep_me"
                        },
                        "updated_at": "2026-11-20T10:00:00Z"
                      }
                    ]
                    """.trimIndent()
                }
                path.endsWith("/rest/v1/admission_enquiries") && req.method == "POST" -> {
                    """
                    [
                      {
                        "id": "adm-2",
                        "school_id": "shubhadisha",
                        "record_id": "ADM-NEW",
                        "record_data": {
                          "student_name": "Ritam Paul",
                          "guardian_name": "Dipak Paul",
                          "phone": "9832223344",
                          "applied_class": "Class I",
                          "status": "pending"
                        },
                        "updated_at": "2026-11-26T10:00:00Z"
                      }
                    ]
                    """.trimIndent()
                }
                path.endsWith("/rest/v1/admission_enquiries") && req.method == "PATCH" -> {
                    """
                    [
                      {
                        "id": "adm-1",
                        "school_id": "shubhadisha",
                        "record_id": "ADM-001",
                        "record_data": {
                          "student_name": "Koushik Roy",
                          "guardian_name": "Tapan Roy",
                          "phone": "9831112233",
                          "applied_class": "Class II",
                          "status": "admitted",
                          "enrolled_student_id": "stu-enrolled-1",
                          "legacy_custom_flag": "keep_me"
                        },
                        "updated_at": "2026-11-26T11:00:00Z"
                      }
                    ]
                    """.trimIndent()
                }
                path.endsWith("/rest/v1/students") && req.method == "POST" -> {
                    """[{"id":"stu-enrolled-1","student_name":"Koushik Roy","admission_no":"ADM-001","roll_no":"1","class_id":"cls-2","is_active":true}]"""
                }
                else -> "[]"
            }

            Response.Builder()
                .request(req)
                .protocol(Protocol.HTTP_1_1)
                .code(200)
                .message("OK")
                .body(json.toResponseBody("application/json".toMediaType()))
                .build()
        }

        val repo = AdmissionRepository(SupabaseClient(testConfig, extraInterceptor = interceptor))
        val admin = sessionFor(UserRole.ADMIN)

        val list = repo.fetchEnquiries(admin, AdmissionStatusFilter.APPROVED, "Koushik").getOrThrow()
        assertEquals(1, list.size)
        assertEquals("Koushik Roy", list.first().studentName)

        val created = repo.createEnquiry(
            admin,
            AdmissionEnquiryDraft(studentName = "Ritam Paul", guardianName = "Dipak Paul", phone = "9832223344", appliedClass = "Class I"),
            "2026-11-26",
        ).getOrThrow()
        assertEquals("adm-2", created.id)

        val (updatedEnquiry, enrolledStudent) = repo.enrollEnquiryAsStudent(
            session = admin,
            enquiry = list.first(),
            admissionNo = "ADM-001",
            rollNo = "1",
            classId = "cls-2",
            className = "Class II",
            todayIso = "2026-11-26",
        ).getOrThrow()
        assertEquals("stu-enrolled-1", enrolledStudent.id)
        assertEquals(AdmissionStatus.ADMITTED, updatedEnquiry.status)
        val patchBody = calls.last { it.first == "PATCH" }.third
        assertTrue(patchBody.contains("keep_me"))

        repo.deleteEnquiry(admin, "adm-2").getOrThrow()

        // Non-admin roles blocked without network calls
        val beforeBlocked = calls.size
        for (role in listOf(UserRole.TEACHER, UserRole.STUDENT, UserRole.PARENT)) {
            assertTrue(repo.fetchEnquiries(sessionFor(role)).isFailure)
            assertTrue(repo.createEnquiry(sessionFor(role), AdmissionEnquiryDraft(studentName = "X"), "2026-11-26").isFailure)
        }
        assertEquals(beforeBlocked, calls.size)
    }

    @Test
    fun `admission screen renders bilingual Bengali filters and cards`() {
        val repo = AdmissionRepository(SupabaseClient(testConfig))
        val vm = AdmissionViewModel(repo)
        val uiState = AdmissionUiState(
            enquiriesState = LoadableState.Success(
                listOf(
                    AdmissionEnquiryRecord(
                        id = "adm-1",
                        schoolId = "shubhadisha",
                        recordId = "ADM-001",
                        studentName = "Koushik Roy",
                        guardianName = "Tapan Roy",
                        phone = "9831112233",
                        email = null,
                        appliedClass = "Class II",
                        classId = "cls-2",
                        enquiryDate = "2026-11-20",
                        dateOfBirth = null,
                        gender = null,
                        previousSchool = null,
                        address = null,
                        status = AdmissionStatus.APPROVED,
                        notes = null,
                        enrolledStudentId = null,
                        updatedAt = "",
                    ),
                ),
            ),
        )

        composeRule.setContent {
            CompositionLocalProvider(
                LocalAppLanguage provides AppLanguage.BENGALI,
                LocalAppStrings provides stringsFor(AppLanguage.BENGALI),
            ) {
                ShubhadishaErpTheme(language = AppLanguage.BENGALI) {
                    AdmissionScreen(
                        session = sessionFor(UserRole.ADMIN),
                        uiState = uiState,
                        viewModel = vm,
                        onLanguageSelected = {},
                        onBack = {},
                    )
                }
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("new_enquiry_fab").assertIsDisplayed()
        composeRule.onNodeWithText("Koushik Roy").assertIsDisplayed()
        composeRule.onNodeWithText("অনুমোদিত").assertIsDisplayed()
    }
}
