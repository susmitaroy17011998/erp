package com.example

import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasScrollAction
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToIndex
import com.example.erp.core.config.SupabaseConfig
import com.example.erp.core.i18n.AppLanguage
import com.example.erp.core.i18n.LocalAppLanguage
import com.example.erp.core.i18n.LocalAppStrings
import com.example.erp.core.i18n.stringsFor
import com.example.erp.core.model.AuthSession
import com.example.erp.core.model.DashboardSnapshot
import com.example.erp.core.model.ErpModule
import com.example.erp.core.model.LinkedStaffInfo
import com.example.erp.core.model.LinkedStudentInfo
import com.example.erp.core.model.UserProfile
import com.example.erp.core.model.UserRole
import com.example.erp.core.network.InactiveAccountException
import com.example.erp.core.network.ProfileMissingException
import com.example.erp.core.network.SupabaseAuthService
import com.example.erp.core.network.SupabaseClient
import com.example.erp.features.auth.LoginFormState
import com.example.erp.features.auth.LoginScreen
import com.example.erp.features.dashboard.AdminShellScreen
import com.example.erp.features.dashboard.ParentShellScreen
import com.example.erp.features.dashboard.StudentShellScreen
import com.example.erp.features.dashboard.TeacherShellScreen
import com.example.erp.ui.navigation.AppRoutes
import com.example.ui.theme.ShubhadishaErpTheme
import kotlinx.coroutines.test.runTest
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class Batch1Module1VerificationTest {

    @get:Rule
    val composeRule = createComposeRule()

    private val testConfig = SupabaseConfig(
        url = "https://mock-academy.supabase.co",
        anonKey = "sb_publishable_test_key_12345",
    )

    private fun buildService(
        role: String,
        profileActive: Boolean = true,
        profileExists: Boolean = true,
        staffActive: Boolean = true,
        studentActive: Boolean = true,
        recordedLogoutCalls: MutableList<String> = mutableListOf(),
        recordedAuthHeadersOnLogin: MutableList<String?> = mutableListOf(),
    ): SupabaseAuthService {
        val interceptor = Interceptor { chain ->
            val req = chain.request()
            val path = req.url.encodedPath
            val query = req.url.encodedQuery.orEmpty()
            val json = "application/json".toMediaType()

            val body = when {
                path.endsWith("/auth/v1/token") -> {
                    recordedAuthHeadersOnLogin.add(req.header("Authorization"))
                    """
                    {
                      "access_token": "jwt_user_token_$role",
                      "refresh_token": "refresh_token_$role",
                      "expires_in": 3600,
                      "user": {
                        "id": "uid-$role-1",
                        "email": "$role@shubhadisha.edu.in"
                      }
                    }
                    """.trimIndent()
                }
                path.endsWith("/auth/v1/logout") -> {
                    recordedLogoutCalls.add(req.header("Authorization").orEmpty())
                    "{}"
                }
                path.endsWith("/rest/v1/profiles") -> {
                    if (!profileExists) {
                        "[]"
                    } else {
                        """
                        [
                          {
                            "id": "uid-$role-1",
                            "full_name": "Test ${role.replaceFirstChar { it.uppercase() }}",
                            "role": "$role",
                            "phone": "9800000001",
                            "is_active": $profileActive
                          }
                        ]
                        """.trimIndent()
                    }
                }
                path.endsWith("/rest/v1/staff") -> {
                    """
                    [
                      {
                        "id": "staff-1",
                        "staff_name": "Teacher Roy",
                        "designation": "Assistant Teacher",
                        "phone": "9800000002",
                        "joining_date": "2023-04-01",
                        "photo_url": "staff/avatar.jpg",
                        "is_active": $staffActive
                      }
                    ]
                    """.trimIndent()
                }
                path.endsWith("/rest/v1/class_teachers") -> {
                    """[{"classes": {"class_name": "Class IV"}}]"""
                }
                path.endsWith("/rest/v1/students") -> {
                    """
                    [
                      {
                        "id": "stu-1",
                        "student_name": "Aarav Mondal",
                        "admission_no": "PMS-2026-014",
                        "roll_no": "14",
                        "class_id": "cls-4",
                        "photo_url": "students/aarav.jpg",
                        "is_active": $studentActive,
                        "classes": {"class_name": "Class IV"}
                      }
                    ]
                    """.trimIndent()
                }
                path.endsWith("/rest/v1/student_guardians") -> {
                    """
                    [
                      {
                        "relationship": "Father",
                        "students": {
                          "id": "stu-1",
                          "student_name": "Aarav Mondal",
                          "admission_no": "PMS-2026-014",
                          "roll_no": "14",
                          "class_id": "cls-4",
                          "photo_url": "students/aarav.jpg",
                          "classes": {"class_name": "Class IV"}
                        }
                      }
                    ]
                    """.trimIndent()
                }
                path.endsWith("/rest/v1/portal_shared_data") && query.contains("shubhadisha") -> "[]"
                else -> "[]"
            }

            Response.Builder()
                .request(req)
                .protocol(Protocol.HTTP_1_1)
                .code(200)
                .message("OK")
                .body(body.toResponseBody(json))
                .build()
        }

        val client = SupabaseClient(config = testConfig, extraInterceptor = interceptor)
        return SupabaseAuthService(client)
    }

    @Test
    fun `admin teacher student parent login flows resolve verified profile and linked data`() = runTest {
        val authHeaders = mutableListOf<String?>()

        // 1. Admin login (even if selectedRoleHint was STUDENT, profile overrides to ADMIN)
        val adminService = buildService(role = "admin", recordedAuthHeadersOnLogin = authHeaders)
        val adminSession = adminService.signInWithPassword("admin@shubhadisha.edu.in", "secret123", UserRole.STUDENT).getOrThrow()
        assertEquals(UserRole.ADMIN, adminSession.user.role)
        assertTrue(adminSession.user.profileVerified)
        assertNull(authHeaders.first()) // sb_publishable_ must NOT send Authorization: Bearer on /token

        // 2. Teacher login resolves staff + assigned classes
        val teacherService = buildService(role = "teacher")
        val teacherSession = teacherService.signInWithPassword("teacher@shubhadisha.edu.in", "secret123", UserRole.TEACHER).getOrThrow()
        assertEquals(UserRole.TEACHER, teacherSession.user.role)
        assertEquals("Assistant Teacher", teacherSession.user.staffInfo?.designation)
        assertEquals(listOf("Class IV"), teacherSession.user.staffInfo?.assignedClasses)

        // 3. Student login resolves student_name, roll_no, className, and authenticated storage URL
        val studentService = buildService(role = "student")
        val studentSession = studentService.signInWithPassword("student@shubhadisha.edu.in", "secret123", UserRole.STUDENT).getOrThrow()
        assertEquals(UserRole.STUDENT, studentSession.user.role)
        assertEquals("Aarav Mondal", studentSession.user.studentInfo?.studentName)
        assertEquals("Class IV", studentSession.user.studentInfo?.className)
        assertTrue(studentSession.user.studentInfo?.photoUrl?.contains("/storage/v1/object/authenticated/school-files/") == true)

        // 4. Parent login resolves linkedWards from student_guardians
        val parentService = buildService(role = "parent")
        val parentSession = parentService.signInWithPassword("parent@shubhadisha.edu.in", "secret123", UserRole.PARENT).getOrThrow()
        assertEquals(UserRole.PARENT, parentSession.user.role)
        assertEquals(1, parentSession.user.linkedWards.size)
        assertEquals("Father", parentSession.user.linkedWards.first().relationship)
    }

    @Test
    fun `inactive users and missing profiles are blocked and signed out`() = runTest {
        val logouts = mutableListOf<String>()
        val inactiveService = buildService(role = "teacher", profileActive = false, recordedLogoutCalls = logouts)
        val inactiveResult = inactiveService.signInWithPassword("t@shubhadisha.edu.in", "secret123", UserRole.TEACHER)
        assertTrue(inactiveResult.isFailure)
        assertTrue(inactiveResult.exceptionOrNull() is InactiveAccountException)
        assertEquals(1, logouts.size)

        val inactiveStaffService = buildService(role = "teacher", profileActive = true, staffActive = false, recordedLogoutCalls = logouts)
        val inactiveStaffResult = inactiveStaffService.signInWithPassword("t@shubhadisha.edu.in", "secret123", UserRole.TEACHER)
        assertTrue(inactiveStaffResult.exceptionOrNull() is InactiveAccountException)
        assertEquals(2, logouts.size)

        val missingProfileService = buildService(role = "student", profileExists = false, recordedLogoutCalls = logouts)
        val missingResult = missingProfileService.signInWithPassword("s@shubhadisha.edu.in", "secret123", UserRole.STUDENT)
        assertTrue(missingResult.exceptionOrNull() is ProfileMissingException)
        assertEquals(3, logouts.size)
    }

    @Test
    fun `session refresh and sign out work cleanly`() = runTest {
        val logouts = mutableListOf<String>()
        val service = buildService(role = "admin", recordedLogoutCalls = logouts)
        val refreshed = service.refreshSession("refresh_token_admin", UserRole.STUDENT).getOrThrow()
        assertEquals(UserRole.ADMIN, refreshed.user.role)
        assertEquals("jwt_user_token_admin", refreshed.accessToken)

        service.signOut(refreshed.accessToken).getOrThrow()
        assertEquals(listOf("Bearer jwt_user_token_admin"), logouts)
    }

    @Test
    fun `role authorization enforces strict dashboard and module separation`() {
        assertEquals(AppRoutes.ADMIN_SHELL, AppRoutes.shellForRole(UserRole.ADMIN))
        assertEquals(AppRoutes.TEACHER_SHELL, AppRoutes.shellForRole(UserRole.TEACHER))
        assertEquals(AppRoutes.STUDENT_SHELL, AppRoutes.shellForRole(UserRole.STUDENT))
        assertEquals(AppRoutes.PARENT_SHELL, AppRoutes.shellForRole(UserRole.PARENT))

        val adminMods = ErpModule.forRole(UserRole.ADMIN)
        val teacherMods = ErpModule.forRole(UserRole.TEACHER)
        val studentMods = ErpModule.forRole(UserRole.STUDENT)
        val parentMods = ErpModule.forRole(UserRole.PARENT)

        assertTrue(ErpModule.ADMISSION in adminMods)
        assertFalse(ErpModule.ADMISSION in teacherMods)
        assertFalse(ErpModule.FEES in teacherMods)
        assertFalse(ErpModule.STUDENTS in studentMods)
        assertFalse(ErpModule.TEACHERS in studentMods)
        assertFalse(ErpModule.REPORTS in parentMods)
        assertTrue(ErpModule.FEES in parentMods)
        assertTrue(ErpModule.NOTICES in studentMods)
        assertTrue(ErpModule.HOLIDAYS in parentMods)
    }

    @Test
    fun `login screen renders role chips and toggles Bengali strings`() {
        var selectedLang = AppLanguage.ENGLISH
        composeRule.setContent {
            val lang = selectedLang
            CompositionLocalProvider(
                LocalAppLanguage provides lang,
                LocalAppStrings provides stringsFor(lang),
            ) {
                ShubhadishaErpTheme(language = lang) {
                    LoginScreen(
                        formState = LoginFormState(),
                        isLoading = false,
                        isSupabaseConfigured = true,
                        onLanguageSelected = { selectedLang = it },
                        onRoleSelected = {},
                        onEmailChanged = {},
                        onPasswordChanged = {},
                        onTogglePasswordVisibility = {},
                        onSignInClick = {},
                        onForgotPasswordClick = {},
                        onDismissResetDialog = {},
                        onResetEmailChanged = {},
                        onSubmitPasswordReset = {},
                    )
                }
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("role_chip_admin").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("role_chip_teacher").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("role_chip_student").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("role_chip_parent").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("lang_option_bn").performScrollTo().performClick()
        assertEquals(AppLanguage.BENGALI, selectedLang)
    }

    @Test
    fun `each role dashboard renders only its own role context`() {
        val parentSession = AuthSession(
            accessToken = "tok",
            refreshToken = "ref",
            expiresAtEpochSeconds = 9999999999L,
            user = UserProfile(
                userId = "p1",
                email = "parent@shubhadisha.edu.in",
                fullName = "Subhash Mondal",
                role = UserRole.PARENT,
                profileVerified = true,
                linkedWards = listOf(
                    LinkedStudentInfo(
                        studentId = "s1",
                        studentName = "Aarav Mondal",
                        admissionNo = "PMS-01",
                        rollNo = "14",
                        classId = "c4",
                        className = "Class IV",
                        photoUrl = null,
                        relationship = "Father",
                    ),
                ),
            ),
        )

        composeRule.setContent {
            CompositionLocalProvider(
                LocalAppLanguage provides AppLanguage.ENGLISH,
                LocalAppStrings provides stringsFor(AppLanguage.ENGLISH),
            ) {
                ShubhadishaErpTheme {
                    ParentShellScreen(
                        session = parentSession,
                        roleNotice = null,
                        snapshot = DashboardSnapshot(publishedNoticeCount = 3, holidayCount = 2),
                        isSyncingProfile = false,
                        onLanguageSelected = {},
                        onSyncProfile = {},
                        onOpenModule = {},
                        onSignOut = {},
                    )
                }
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithText("Subhash Mondal", substring = true).assertIsDisplayed()
        composeRule.onNode(hasScrollAction()).performScrollToIndex(2)
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Aarav Mondal").assertIsDisplayed()
        composeRule.onNodeWithText("Father").assertIsDisplayed()
    }
}
