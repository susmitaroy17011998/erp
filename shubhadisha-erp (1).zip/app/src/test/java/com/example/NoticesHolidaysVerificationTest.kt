package com.example

import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.test.assertCountEquals
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import com.example.erp.core.config.SupabaseConfig
import com.example.erp.core.i18n.AppLanguage
import com.example.erp.core.i18n.LocalAppLanguage
import com.example.erp.core.i18n.LocalAppStrings
import com.example.erp.core.i18n.stringsFor
import com.example.erp.core.model.AuthSession
import com.example.erp.core.model.ErpModule
import com.example.erp.core.model.HolidayDraft
import com.example.erp.core.model.HolidayItem
import com.example.erp.core.model.LoadableState
import com.example.erp.core.model.NoticeDraft
import com.example.erp.core.model.NoticeItem
import com.example.erp.core.model.NoticeStatusFilter
import com.example.erp.core.model.UserProfile
import com.example.erp.core.model.UserRole
import com.example.erp.core.network.SupabaseClient
import com.example.erp.features.notices.HolidaysScreen
import com.example.erp.features.notices.NoticesHolidaysRepository
import com.example.erp.features.notices.NoticesHolidaysUiState
import com.example.erp.features.notices.NoticesHolidaysViewModel
import com.example.erp.features.notices.NoticesScreen
import com.example.erp.ui.navigation.AppRoutes
import com.example.ui.theme.ShubhadishaErpTheme
import kotlinx.coroutines.test.runTest
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import okio.Buffer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NoticesHolidaysVerificationTest {

    @get:Rule
    val composeRule = createComposeRule()

    private val testConfig = SupabaseConfig(
        url = "https://mock-academy.supabase.co",
        anonKey = "sb_publishable_test_key_12345",
    )

    private data class RecordedCall(
        val method: String,
        val path: String,
        val query: String,
        val authHeader: String?,
        val body: String,
    )

    private fun sessionFor(role: UserRole): AuthSession = AuthSession(
        accessToken = "jwt_${role.key}_token",
        refreshToken = "refresh_${role.key}",
        expiresAtEpochSeconds = 9999999999L,
        user = UserProfile(
            userId = "uid-${role.key}-1",
            email = "${role.key}@shubhadisha.edu.in",
            fullName = "Test ${role.key}",
            role = role,
            profileVerified = true,
        ),
    )

    private fun buildRepository(
        recordedCalls: MutableList<RecordedCall> = mutableListOf(),
    ): NoticesHolidaysRepository {
        val interceptor = Interceptor { chain ->
            val req = chain.request()
            val buffer = Buffer()
            req.body?.writeTo(buffer)
            val reqBody = buffer.readUtf8()
            val path = req.url.encodedPath
            val query = req.url.encodedQuery.orEmpty()

            recordedCalls.add(
                RecordedCall(
                    method = req.method,
                    path = path,
                    query = query,
                    authHeader = req.header("Authorization"),
                    body = reqBody,
                ),
            )

            val responseJson = when {
                path.endsWith("/rest/v1/notices") && req.method == "GET" -> {
                    if (query.contains("is_published=eq.true")) {
                        """
                        [
                          {
                            "id": "n-pub-1",
                            "title": "Annual Sports Day",
                            "body": "Bring house uniform at 8 AM.",
                            "notice_type": "Event",
                            "publish_date": "2026-11-20",
                            "expiry_date": "2026-12-30",
                            "is_published": true,
                            "created_by": "uid-admin-1",
                            "created_at": "2026-11-20T09:00:00Z",
                            "thumbnail_url": "notices/sports.jpg"
                          }
                        ]
                        """.trimIndent()
                    } else {
                        """
                        [
                          {
                            "id": "n-pub-1",
                            "title": "Annual Sports Day",
                            "body": "Bring house uniform at 8 AM.",
                            "notice_type": "Event",
                            "publish_date": "2026-11-20",
                            "expiry_date": "2026-12-30",
                            "is_published": true,
                            "created_by": "uid-admin-1",
                            "created_at": "2026-11-20T09:00:00Z",
                            "thumbnail_url": "notices/sports.jpg"
                          },
                          {
                            "id": "n-draft-2",
                            "title": "Draft Exam Schedule",
                            "body": "Internal review only.",
                            "notice_type": "Exam",
                            "publish_date": "2026-11-25",
                            "expiry_date": null,
                            "is_published": false,
                            "created_by": "uid-admin-1",
                            "created_at": "2026-11-25T10:00:00Z",
                            "thumbnail_url": null
                          }
                        ]
                        """.trimIndent()
                    }
                }
                path.endsWith("/rest/v1/notices") && req.method == "POST" -> {
                    """
                    [
                      {
                        "id": "n-created-3",
                        "title": "Winter Uniform Reminder",
                        "body": "Sweaters mandatory from December.",
                        "notice_type": "General",
                        "publish_date": "2026-11-26",
                        "expiry_date": "2026-12-15",
                        "is_published": true,
                        "created_by": "uid-admin-1",
                        "created_at": "2026-11-26T10:00:00Z",
                        "thumbnail_url": null
                      }
                    ]
                    """.trimIndent()
                }
                path.endsWith("/rest/v1/notices") && req.method == "PATCH" -> {
                    val published = if (reqBody.contains("\"is_published\":false")) "false" else "true"
                    """
                    [
                      {
                        "id": "n-created-3",
                        "title": "Updated Winter Uniform",
                        "body": "Navy blue cardigan required.",
                        "notice_type": "Urgent",
                        "publish_date": "2026-11-26",
                        "expiry_date": "2026-12-20",
                        "is_published": $published,
                        "created_by": "uid-admin-1",
                        "created_at": "2026-11-26T10:00:00Z",
                        "thumbnail_url": null
                      }
                    ]
                    """.trimIndent()
                }
                path.endsWith("/rest/v1/notices") && req.method == "DELETE" -> "[]"
                path.endsWith("/rest/v1/holidays") && req.method == "GET" -> {
                    """
                    [
                      {
                        "id": "h-1",
                        "holiday_name": "Winter Vacation",
                        "holiday_date": "2026-12-25",
                        "end_date": "2027-01-02",
                        "holiday_type": "Vacation",
                        "description": "School closed for winter break.",
                        "school_reopen_date": "2027-01-03",
                        "created_at": "2026-11-01T08:00:00Z"
                      }
                    ]
                    """.trimIndent()
                }
                path.endsWith("/rest/v1/holidays") && req.method == "POST" -> {
                    """
                    [
                      {
                        "id": "h-2",
                        "holiday_name": "Netaji Jayanti",
                        "holiday_date": "2027-01-23",
                        "end_date": null,
                        "holiday_type": "Festival",
                        "description": "Morning flag hoisting at 8 AM.",
                        "school_reopen_date": "2027-01-24",
                        "created_at": "2026-11-26T10:00:00Z"
                      }
                    ]
                    """.trimIndent()
                }
                path.endsWith("/rest/v1/holidays") && req.method == "PATCH" -> {
                    """
                    [
                      {
                        "id": "h-2",
                        "holiday_name": "Netaji Birthday Celebration",
                        "holiday_date": "2027-01-23",
                        "end_date": null,
                        "holiday_type": "Festival",
                        "description": "Cultural assembly.",
                        "school_reopen_date": "2027-01-24",
                        "created_at": "2026-11-26T10:00:00Z"
                      }
                    ]
                    """.trimIndent()
                }
                path.endsWith("/rest/v1/holidays") && req.method == "DELETE" -> "[]"
                else -> "[]"
            }

            Response.Builder()
                .request(req)
                .protocol(Protocol.HTTP_1_1)
                .code(200)
                .message("OK")
                .body(responseJson.toResponseBody("application/json".toMediaType()))
                .build()
        }

        val client = SupabaseClient(config = testConfig, extraInterceptor = interceptor)
        return NoticesHolidaysRepository(client)
    }

    @Test
    fun `admin can fetch create edit publish unpublish and delete notices`() = runTest {
        val calls = mutableListOf<RecordedCall>()
        val repo = buildRepository(calls)
        val admin = sessionFor(UserRole.ADMIN)

        val fetched = repo.fetchNotices(admin).getOrThrow()
        assertEquals(2, fetched.size)
        assertFalse(calls.last().query.contains("is_published=eq.true"))
        assertTrue(fetched[0].thumbnailUrl?.contains("/storage/v1/object/authenticated/school-files/notices/sports.jpg") == true)

        val created = repo.createNotice(
            session = admin,
            draft = NoticeDraft(
                title = "Winter Uniform Reminder",
                body = "Sweaters mandatory from December.",
                noticeType = "General",
                publishDate = "2026-11-26",
                expiryDate = "2026-12-15",
                isPublished = true,
            ),
        ).getOrThrow()
        assertEquals("n-created-3", created.id)
        val postCall = calls.last()
        assertEquals("POST", postCall.method)
        assertEquals("Bearer jwt_admin_token", postCall.authHeader)
        assertTrue(postCall.body.contains("\"created_by\":\"uid-admin-1\""))

        val updated = repo.updateNotice(
            session = admin,
            noticeId = "n-created-3",
            draft = NoticeDraft(
                id = "n-created-3",
                title = "Updated Winter Uniform",
                body = "Navy blue cardigan required.",
                noticeType = "Urgent",
                publishDate = "2026-11-26",
                expiryDate = "2026-12-20",
                isPublished = true,
            ),
        ).getOrThrow()
        assertEquals("Updated Winter Uniform", updated.title)
        assertEquals("PATCH", calls.last().method)
        assertTrue(calls.last().query.contains("id=eq.n-created-3"))

        val unpublished = repo.setNoticePublished(admin, "n-created-3", false).getOrThrow()
        assertFalse(unpublished.isPublished)
        assertTrue(calls.last().body.contains("\"is_published\":false"))

        repo.deleteNotice(admin, "n-created-3").getOrThrow()
        assertEquals("DELETE", calls.last().method)
        assertTrue(calls.last().query.contains("id=eq.n-created-3"))
    }

    @Test
    fun `admin can perform holiday CRUD and non admins can only read`() = runTest {
        val calls = mutableListOf<RecordedCall>()
        val repo = buildRepository(calls)
        val admin = sessionFor(UserRole.ADMIN)

        val holidays = repo.fetchHolidays(admin).getOrThrow()
        assertEquals(1, holidays.size)
        assertEquals("2027-01-03", holidays.first().schoolReopenDate)

        val created = repo.createHoliday(
            session = admin,
            draft = HolidayDraft(
                holidayName = "Netaji Jayanti",
                holidayDate = "2027-01-23",
                holidayType = "Festival",
                description = "Morning flag hoisting at 8 AM.",
                schoolReopenDate = "2027-01-24",
            ),
        ).getOrThrow()
        assertEquals("h-2", created.id)
        assertEquals("POST", calls.last().method)

        val updated = repo.updateHoliday(
            session = admin,
            holidayId = "h-2",
            draft = HolidayDraft(
                id = "h-2",
                holidayName = "Netaji Birthday Celebration",
                holidayDate = "2027-01-23",
                holidayType = "Festival",
                description = "Cultural assembly.",
                schoolReopenDate = "2027-01-24",
            ),
        ).getOrThrow()
        assertEquals("Netaji Birthday Celebration", updated.holidayName)
        assertEquals("PATCH", calls.last().method)

        repo.deleteHoliday(admin, "h-2").getOrThrow()
        assertEquals("DELETE", calls.last().method)
    }

    @Test
    fun `non admin roles only query published notices and are blocked from mutations`() = runTest {
        val calls = mutableListOf<RecordedCall>()
        val repo = buildRepository(calls)

        val nonAdminRoles = listOf(UserRole.TEACHER, UserRole.STUDENT, UserRole.PARENT)
        for (role in nonAdminRoles) {
            val session = sessionFor(role)
            val notices = repo.fetchNotices(session).getOrThrow()
            assertEquals(1, notices.size)
            assertTrue(calls.last().query.contains("is_published=eq.true"))

            val beforeCount = calls.size
            assertTrue(repo.createNotice(session, NoticeDraft(title = "Hack")).isFailure)
            assertTrue(repo.updateNotice(session, "n-1", NoticeDraft(id = "n-1", title = "Hack")).isFailure)
            assertTrue(repo.setNoticePublished(session, "n-1", false).isFailure)
            assertTrue(repo.deleteNotice(session, "n-1").isFailure)
            assertTrue(repo.createHoliday(session, HolidayDraft(holidayName = "Hack", holidayDate = "2026-12-01")).isFailure)
            assertTrue(repo.updateHoliday(session, "h-1", HolidayDraft(id = "h-1", holidayName = "Hack", holidayDate = "2026-12-01")).isFailure)
            assertTrue(repo.deleteHoliday(session, "h-1").isFailure)
            assertEquals("No mutation HTTP call should be issued for ${role.key}", beforeCount, calls.size)
        }
    }

    @Test
    fun `search category status and expiry filters behave correctly per role`() {
        val repo = buildRepository()
        val vm = NoticesHolidaysViewModel(repository = repo, todayProvider = { "2026-11-26" })

        val sampleNotices = listOf(
            NoticeItem(
                id = "1",
                title = "Unit Test Routine",
                body = "Starts next Monday",
                noticeType = "Exam",
                publishDate = "2026-11-20",
                expiryDate = "2026-12-05",
                isPublished = true,
                createdBy = null,
                createdAt = "",
                thumbnailUrl = null,
            ),
            NoticeItem(
                id = "2",
                title = "Internal Fee Draft",
                body = "Draft notice",
                noticeType = "General",
                publishDate = "2026-11-22",
                expiryDate = null,
                isPublished = false,
                createdBy = null,
                createdAt = "",
                thumbnailUrl = null,
            ),
            NoticeItem(
                id = "3",
                title = "Old Picnic Notice",
                body = "Completed picnic",
                noticeType = "Event",
                publishDate = "2026-11-01",
                expiryDate = "2026-11-10",
                isPublished = true,
                createdBy = null,
                createdAt = "",
                thumbnailUrl = null,
            ),
        )

        // Student sees only published + non-expired
        val studentAll = vm.filterNotices(sampleNotices, UserRole.STUDENT, "", null, NoticeStatusFilter.ALL)
        assertEquals(listOf("1"), studentAll.map { it.id })

        // Teacher/Parent also cannot see draft or expired
        assertEquals(listOf("1"), vm.filterNotices(sampleNotices, UserRole.TEACHER, "", null, NoticeStatusFilter.DRAFT).map { it.id })
        assertEquals(listOf("1"), vm.filterNotices(sampleNotices, UserRole.PARENT, "", null, NoticeStatusFilter.ALL).map { it.id })

        // Admin sees all, plus status + category + search filters
        assertEquals(listOf("1", "2", "3"), vm.filterNotices(sampleNotices, UserRole.ADMIN, "", null, NoticeStatusFilter.ALL).map { it.id })
        assertEquals(listOf("2"), vm.filterNotices(sampleNotices, UserRole.ADMIN, "", null, NoticeStatusFilter.DRAFT).map { it.id })
        assertEquals(listOf("3"), vm.filterNotices(sampleNotices, UserRole.ADMIN, "", null, NoticeStatusFilter.EXPIRED).map { it.id })
        assertEquals(listOf("1"), vm.filterNotices(sampleNotices, UserRole.ADMIN, "monday", "Exam", NoticeStatusFilter.PUBLISHED).map { it.id })

        val sampleHolidays = listOf(
            HolidayItem("h1", "Saraswati Puja", "2027-02-10", null, "Festival", "Puja celebration", "2027-02-11", ""),
            HolidayItem("h2", "Summer Break", "2027-05-15", "2027-06-05", "Vacation", "Hot weather break", "2027-06-06", ""),
        )
        assertEquals(listOf("h1"), vm.filterHolidays(sampleHolidays, "puja", "Festival").map { it.id })
    }

    @Test
    fun `notices screen shows admin actions only for admin and hides for student`() {
        val repo = buildRepository()
        val vm = NoticesHolidaysViewModel(repository = repo, todayProvider = { "2026-11-26" })
        val sample = listOf(
            NoticeItem(
                id = "n1",
                title = "Annual Sports Notice",
                body = "Report at ground",
                noticeType = "Event",
                publishDate = "2026-11-20",
                expiryDate = "2026-12-20",
                isPublished = true,
                createdBy = null,
                createdAt = "",
                thumbnailUrl = null,
            ),
            NoticeItem(
                id = "n2",
                title = "Hidden Admin Draft",
                body = "Not published yet",
                noticeType = "General",
                publishDate = "2026-11-25",
                expiryDate = null,
                isPublished = false,
                createdBy = null,
                createdAt = "",
                thumbnailUrl = null,
            ),
        )
        val uiState = NoticesHolidaysUiState(
            noticesState = LoadableState.Success(sample),
        )

        composeRule.setContent {
            CompositionLocalProvider(
                LocalAppLanguage provides AppLanguage.ENGLISH,
                LocalAppStrings provides stringsFor(AppLanguage.ENGLISH),
            ) {
                ShubhadishaErpTheme {
                    NoticesScreen(
                        session = sessionFor(UserRole.STUDENT),
                        uiState = uiState,
                        viewModel = vm,
                        onLanguageSelected = {},
                        onOpenHolidays = {},
                        onBack = {},
                    )
                }
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithText("Annual Sports Notice").assertIsDisplayed()
        composeRule.onAllNodesWithTag("notice_card_n2").assertCountEquals(0)
        composeRule.onAllNodesWithTag("new_notice_fab").assertCountEquals(0)
        composeRule.onAllNodesWithTag("edit_notice_n1").assertCountEquals(0)
        composeRule.onAllNodesWithTag("delete_notice_n1").assertCountEquals(0)
    }

    @Test
    fun `admin notices screen and holidays screen render management controls and bilingual text`() {
        val repo = buildRepository()
        val vm = NoticesHolidaysViewModel(repository = repo, todayProvider = { "2026-11-26" })
        val admin = sessionFor(UserRole.ADMIN)
        val uiState = NoticesHolidaysUiState(
            noticesState = LoadableState.Success(
                listOf(
                    NoticeItem(
                        id = "n1",
                        title = "Annual Sports Notice",
                        body = "Report at ground",
                        noticeType = "Event",
                        publishDate = "2026-11-20",
                        expiryDate = "2026-12-20",
                        isPublished = true,
                        createdBy = null,
                        createdAt = "",
                        thumbnailUrl = null,
                    ),
                ),
            ),
            holidaysState = LoadableState.Success(
                listOf(
                    HolidayItem(
                        id = "h1",
                        holidayName = "Winter Vacation",
                        holidayDate = "2026-12-25",
                        endDate = "2027-01-02",
                        holidayType = "Vacation",
                        description = "Closed for winter",
                        schoolReopenDate = "2027-01-03",
                        createdAt = "",
                    ),
                ),
            ),
        )

        composeRule.setContent {
            CompositionLocalProvider(
                LocalAppLanguage provides AppLanguage.BENGALI,
                LocalAppStrings provides stringsFor(AppLanguage.BENGALI),
            ) {
                ShubhadishaErpTheme(language = AppLanguage.BENGALI) {
                    HolidaysScreen(
                        session = admin,
                        uiState = uiState,
                        viewModel = vm,
                        onLanguageSelected = {},
                        onOpenNotices = {},
                        onBack = {},
                    )
                }
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("new_holiday_fab").assertIsDisplayed()
        composeRule.onNodeWithTag("edit_holiday_h1").assertIsDisplayed()
        composeRule.onNodeWithTag("delete_holiday_h1").assertIsDisplayed()
        composeRule.onNodeWithText("Winter Vacation").assertIsDisplayed()
        composeRule.onNodeWithText("স্কুল খুলবে: 2027-01-03").assertIsDisplayed()
    }

    @Test
    fun `navigation routes route notices and holidays live while keeping teachers in preview`() {
        assertEquals(AppRoutes.NOTICES, AppRoutes.moduleRoute(ErpModule.NOTICES))
        assertEquals(AppRoutes.HOLIDAYS, AppRoutes.moduleRoute(ErpModule.HOLIDAYS))
        assertEquals(AppRoutes.STUDENTS, AppRoutes.moduleRoute(ErpModule.STUDENTS))
        assertEquals(AppRoutes.TEACHERS, AppRoutes.moduleRoute(ErpModule.TEACHERS))
    }
}
