package com.example

import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.SemanticsMatcher
import androidx.compose.ui.test.assertCountEquals
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToIndex
import androidx.compose.ui.test.performScrollToNode
import com.example.erp.core.config.SupabaseConfig
import com.example.erp.core.i18n.AppLanguage
import com.example.erp.core.i18n.LocalAppLanguage
import com.example.erp.core.i18n.LocalAppStrings
import com.example.erp.core.i18n.stringsFor
import com.example.erp.core.model.AuthSession
import com.example.erp.core.model.ErpModule
import com.example.erp.core.model.GuardianLinkItem
import com.example.erp.core.model.LinkedAccountProfile
import com.example.erp.core.model.LinkedStaffInfo
import com.example.erp.core.model.LinkedStudentInfo
import com.example.erp.core.model.LoadableState
import com.example.erp.core.model.SchoolClassItem
import com.example.erp.core.model.StudentDraft
import com.example.erp.core.model.StudentRecord
import com.example.erp.core.model.StudentStatusFilter
import com.example.erp.core.model.UserProfile
import com.example.erp.core.model.UserRole
import com.example.erp.core.network.SupabaseClient
import com.example.erp.features.students.StudentDetailPayload
import com.example.erp.features.students.StudentProfileContent
import com.example.erp.features.students.StudentsRepository
import com.example.erp.features.students.StudentsScreen
import com.example.erp.features.students.StudentsUiState
import com.example.erp.features.students.StudentsViewModel
import com.example.erp.ui.navigation.AppRoutes
import com.example.ui.theme.ShubhadishaErpTheme
import kotlinx.coroutines.test.runTest
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import okio.Buffer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class StudentsVerificationTest {

    @get:Rule
    val composeRule = createComposeRule()

    private val testConfig = SupabaseConfig(
        url = "https://mock-academy.supabase.co",
        anonKey = "sb_publishable_test_key_12345",
    )

    private data class RecordedCall(
        val method: String,
        val path: String,
        val query: String,
        val rangeHeader: String?,
        val authHeader: String?,
        val body: String,
    )

    private fun sessionFor(role: UserRole): AuthSession = AuthSession(
        accessToken = "jwt_${role.key}_token",
        refreshToken = "refresh_${role.key}",
        expiresAtEpochSeconds = 9999999999L,
        user = UserProfile(
            userId = "uid-${role.key}-1",
            email = "${role.key}@shubhadisha.edu.in",
            fullName = "Test ${role.key}",
            role = role,
            profileVerified = true,
            staffInfo = if (role == UserRole.TEACHER) {
                LinkedStaffInfo(
                    staffId = "staff-1",
                    staffName = "Teacher Roy",
                    designation = "Assistant Teacher",
                    phone = "9800000002",
                    joiningDate = "2023-04-01",
                    photoUrl = null,
                    assignedClasses = listOf("Class IV"),
                )
            } else {
                null
            },
            studentInfo = if (role == UserRole.STUDENT) {
                LinkedStudentInfo(
                    studentId = "stu-1",
                    studentName = "Aarav Mondal",
                    admissionNo = "PMS-2026-014",
                    rollNo = "14",
                    classId = "cls-4",
                    className = "Class IV",
                    photoUrl = null,
                )
            } else {
                null
            },
            linkedWards = if (role == UserRole.PARENT) {
                listOf(
                    LinkedStudentInfo(
                        studentId = "stu-1",
                        studentName = "Aarav Mondal",
                        admissionNo = "PMS-2026-014",
                        rollNo = "14",
                        classId = "cls-4",
                        className = "Class IV",
                        photoUrl = null,
                        relationship = "Father",
                    ),
                )
            } else {
                emptyList()
            },
        ),
    )

    private fun buildRepository(
        recordedCalls: MutableList<RecordedCall> = mutableListOf(),
        rejectGenderColumnOnce: Boolean = false,
    ): StudentsRepository {
        var rejectedOnce = false
        val interceptor = Interceptor { chain ->
            val req = chain.request()
            val buffer = Buffer()
            req.body?.writeTo(buffer)
            val reqBody = if (req.url.encodedPath.contains("/storage/v1/")) "<binary:${req.body?.contentLength()}>" else buffer.readUtf8()
            val path = req.url.encodedPath
            val query = req.url.encodedQuery.orEmpty()

            recordedCalls.add(
                RecordedCall(
                    method = req.method,
                    path = path,
                    query = query,
                    rangeHeader = req.header("Range"),
                    authHeader = req.header("Authorization"),
                    body = reqBody,
                ),
            )

            var statusCode = 200
            var contentRange: String? = null
            val responseJson = when {
                path.endsWith("/rest/v1/classes") -> {
                    """
                    [
                      {"id": "cls-3", "class_name": "Class III", "section": "A", "academic_year": "2026-27"},
                      {"id": "cls-4", "class_name": "Class IV", "section": "A", "academic_year": "2026-27"}
                    ]
                    """.trimIndent()
                }
                path.endsWith("/rest/v1/students") && req.method == "GET" -> {
                    val range = req.header("Range")
                    when {
                        query.contains("id=eq.stu-inactive") -> {
                            """
                            [
                              {
                                "id": "stu-inactive",
                                "profile_id": null,
                                "student_name": "Inactive Student",
                                "admission_no": "PMS-2026-099",
                                "roll_no": "99",
                                "class_id": "cls-4",
                                "photo_url": null,
                                "is_active": false,
                                "classes": {"class_name": "Class IV"}
                              }
                            ]
                            """.trimIndent()
                        }
                        query.contains("id=eq.stu-cls3") -> {
                            """
                            [
                              {
                                "id": "stu-cls3",
                                "profile_id": null,
                                "student_name": "Unassigned Class Student",
                                "admission_no": "PMS-2026-098",
                                "roll_no": "98",
                                "class_id": "cls-3",
                                "photo_url": null,
                                "is_active": true,
                                "classes": {"class_name": "Class III"}
                              }
                            ]
                            """.trimIndent()
                        }
                        range == "2-3" -> {
                            contentRange = "2-2/3"
                            """
                            [
                              {
                                "id": "stu-3",
                                "profile_id": null,
                                "student_name": "Riya Sen",
                                "admission_no": "PMS-2026-019",
                                "roll_no": "19",
                                "class_id": "cls-3",
                                "photo_url": null,
                                "is_active": false,
                                "classes": {"class_name": "Class III", "section": "A", "academic_year": "2026-27"}
                              }
                            ]
                            """.trimIndent()
                        }
                        else -> {
                        contentRange = "0-1/3"
                        """
                        [
                          {
                            "id": "stu-1",
                            "profile_id": "uid-student-1",
                            "student_name": "Aarav Mondal",
                            "admission_no": "PMS-2026-014",
                            "roll_no": "14",
                            "class_id": "cls-4",
                            "photo_url": "students/aarav.jpg",
                            "is_active": true,
                            "gender": "Male",
                            "classes": {"class_name": "Class IV", "section": "A", "academic_year": "2026-27"}
                          },
                          {
                            "id": "stu-2",
                            "profile_id": null,
                            "student_name": "Diya Das",
                            "admission_no": "PMS-2026-015",
                            "roll_no": "15",
                            "class_id": "cls-4",
                            "photo_url": null,
                            "is_active": true,
                            "classes": {"class_name": "Class IV", "section": "A", "academic_year": "2026-27"}
                          }
                        ]
                        """.trimIndent()
                        }
                    }
                }
                path.endsWith("/rest/v1/students") && req.method == "POST" -> {
                    if (rejectGenderColumnOnce && !rejectedOnce && reqBody.contains("\"gender\"")) {
                        rejectedOnce = true
                        statusCode = 400
                        """{"code":"PGRST204","message":"Could not find the 'gender' column of 'students' in the schema cache"}"""
                    } else {
                        """
                        [
                          {
                            "id": "stu-new-4",
                            "profile_id": null,
                            "student_name": "Soham Pal",
                            "admission_no": "PMS-2026-021",
                            "roll_no": "21",
                            "class_id": "cls-4",
                            "photo_url": "students/stu-new_123.jpg",
                            "is_active": true,
                            "classes": {"class_name": "Class IV"}
                          }
                        ]
                        """.trimIndent()
                    }
                }
                path.endsWith("/rest/v1/students") && req.method == "PATCH" -> {
                    """
                    [
                      {
                        "id": "stu-1",
                        "profile_id": "uid-student-1",
                        "student_name": "Aarav Mondal Updated",
                        "admission_no": "PMS-2026-014",
                        "roll_no": "14",
                        "class_id": "cls-4",
                        "photo_url": "students/aarav_new.jpg",
                        "is_active": true,
                        "classes": {"class_name": "Class IV"}
                      }
                    ]
                    """.trimIndent()
                }
                path.endsWith("/rest/v1/student_guardians") && req.method == "GET" -> {
                    """
                    [
                      {
                        "id": "sg-1",
                        "student_id": "stu-1",
                        "parent_profile_id": "uid-parent-1",
                        "relationship": "Father",
                        "is_primary": true
                      }
                    ]
                    """.trimIndent()
                }
                path.endsWith("/rest/v1/student_guardians") && (req.method == "POST" || req.method == "DELETE") -> "[]"
                path.endsWith("/rest/v1/profiles") -> {
                    """
                    [
                      {"id": "uid-parent-1", "full_name": "Subhash Mondal", "phone": "9830011223", "role": "parent", "is_active": true},
                      {"id": "uid-student-1", "full_name": "Aarav Mondal", "phone": "9830011224", "role": "student", "is_active": true}
                    ]
                    """.trimIndent()
                }
                path.contains("/storage/v1/object/school-files/students/") -> {
                    """{"Key":"school-files/students/stu-1_12345.jpg"}"""
                }
                else -> "[]"
            }

            Response.Builder()
                .request(req)
                .protocol(Protocol.HTTP_1_1)
                .code(statusCode)
                .message(if (statusCode == 200) "OK" else "Bad Request")
                .apply {
                    if (contentRange != null) header("Content-Range", contentRange)
                }
                .body(responseJson.toResponseBody("application/json".toMediaType()))
                .build()
        }

        return StudentsRepository(SupabaseClient(config = testConfig, extraInterceptor = interceptor))
    }

    @Test
    fun `pagination class filter and search query construct exact PostgREST headers and params`() = runTest {
        val calls = mutableListOf<RecordedCall>()
        val repo = buildRepository(calls)
        val admin = sessionFor(UserRole.ADMIN)

        val classes = repo.fetchClasses(admin).getOrThrow()
        assertEquals(2, classes.size)
        assertEquals("Class IV • A", classes[1].displayLabel)

        val page1 = repo.fetchStudentsPage(
            session = admin,
            classId = "cls-4",
            statusFilter = StudentStatusFilter.ACTIVE,
            query = "Aarav",
            offset = 0,
            limit = 2,
        ).getOrThrow()
        assertEquals(2, page1.items.size)
        assertEquals(3, page1.totalCount)
        assertTrue(page1.hasMore)
        assertEquals("0-1", calls.last().rangeHeader)
        assertTrue(calls.last().query.contains("class_id=eq.cls-4"))
        assertTrue(calls.last().query.contains("is_active=eq.true"))
        assertTrue(calls.last().query.contains("student_name.ilike."))

        val page2 = repo.fetchStudentsPage(
            session = admin,
            offset = 2,
            limit = 2,
        ).getOrThrow()
        assertEquals(1, page2.items.size)
        assertFalse(page2.hasMore)
        assertEquals("2-3", calls.last().rangeHeader)
    }

    @Test
    fun `admin can add edit upload photo to school-files and manage guardian links with PGRST204 fallback`() = runTest {
        val calls = mutableListOf<RecordedCall>()
        val repo = buildRepository(calls, rejectGenderColumnOnce = true)
        val admin = sessionFor(UserRole.ADMIN)

        val upload = repo.uploadStudentPhoto(
            session = admin,
            studentKey = "PMS-2026-021",
            imageBytes = byteArrayOf(1, 2, 3, 4),
            mimeType = "image/jpeg",
            fileExtension = "jpg",
            timestampMillis = 999L,
        ).getOrThrow()
        assertEquals("students/PMS-2026-021_999.jpg", upload.storagePath)
        assertTrue(upload.authenticatedUrl.contains("/storage/v1/object/authenticated/school-files/students/PMS-2026-021_999.jpg"))
        val storageCall = calls.last()
        assertEquals("POST", storageCall.method)
        assertEquals("Bearer jwt_admin_token", storageCall.authHeader)

        val created = repo.createStudent(
            session = admin,
            draft = StudentDraft(
                studentName = "Soham Pal",
                admissionNo = "PMS-2026-021",
                rollNo = "21",
                classId = "cls-4",
                photoPath = upload.storagePath,
                gender = "Male",
            ),
            knownColumns = StudentRecord.DEFAULT_CORE_COLUMNS + "gender",
        ).getOrThrow()
        assertEquals("stu-new-4", created.id)
        // Retried automatically without `gender` after PGRST204
        assertEquals(2, calls.count { it.path.endsWith("/rest/v1/students") && it.method == "POST" })

        val updated = repo.updateStudent(
            session = admin,
            studentId = "stu-1",
            draft = StudentDraft(
                id = "stu-1",
                studentName = "Aarav Mondal Updated",
                admissionNo = "PMS-2026-014",
                rollNo = "14",
                classId = "cls-4",
                photoPath = "students/aarav_new.jpg",
                isActive = true,
            ),
        ).getOrThrow()
        assertEquals("Aarav Mondal Updated", updated.studentName)
        assertEquals("PATCH", calls.last().method)

        val detail = repo.fetchStudentDetail(admin, updated.copy(id = "stu-1", profileId = "uid-student-1")).getOrThrow()
        assertEquals(1, detail.guardians.size)
        assertEquals("Subhash Mondal", detail.guardians.first().parentName)
        assertEquals("9830011223", detail.guardians.first().parentPhone)
        assertEquals("Aarav Mondal", detail.linkedProfile?.fullName)

        repo.linkGuardian(admin, "stu-1", "uid-parent-1", "Father").getOrThrow()
        assertEquals("POST", calls.last().method)

        repo.unlinkGuardian(admin, detail.guardians.first()).getOrThrow()
        assertEquals("DELETE", calls.last().method)
    }

    @Test
    fun `teacher student and parent roles obey scoped read access and are blocked from writes`() = runTest {
        val calls = mutableListOf<RecordedCall>()
        val repo = buildRepository(calls)

        // Teacher: scoped to active students in assigned classes + blocked from writes
        val teacher = sessionFor(UserRole.TEACHER)
        repo.fetchStudentsPage(session = teacher, allowedClassIds = setOf("cls-4")).getOrThrow()
        assertTrue(calls.last().query.contains("is_active=eq.true"))
        assertTrue(calls.last().query.contains("class_id=in.(cls-4)"))
        assertTrue(
            repo.fetchStudentDetail(
                teacher,
                StudentRecord(
                    id = "stu-inactive",
                    profileId = null,
                    studentName = "Inactive Student",
                    admissionNo = null,
                    rollNo = null,
                    classId = "cls-4",
                    className = "Class IV",
                    photoPath = null,
                    photoUrl = null,
                    isActive = false,
                ),
            ).isFailure,
        )
        assertTrue(
            repo.fetchStudentDetail(
                teacher,
                StudentRecord(
                    id = "stu-cls3",
                    profileId = null,
                    studentName = "Unassigned Class Student",
                    admissionNo = null,
                    rollNo = null,
                    classId = "cls-3",
                    className = "Class III",
                    photoPath = null,
                    photoUrl = null,
                    isActive = true,
                ),
            ).isFailure,
        )

        // Student: scoped strictly to self + cannot view another student
        val student = sessionFor(UserRole.STUDENT)
        repo.fetchStudentsPage(session = student).getOrThrow()
        assertTrue(calls.last().query.contains("profile_id.eq.uid-student-1"))
        val foreignStudent = StudentRecord(
            id = "stu-other",
            profileId = "uid-other",
            studentName = "Other",
            admissionNo = null,
            rollNo = null,
            classId = "cls-4",
            className = "Class IV",
            photoPath = null,
            photoUrl = null,
            isActive = true,
        )
        assertTrue(repo.fetchStudentDetail(student, foreignStudent).isFailure)

        // Parent: scoped strictly to student_guardians linked IDs + cannot view unlinked student
        val parent = sessionFor(UserRole.PARENT)
        repo.fetchStudentsPage(session = parent).getOrThrow()
        assertTrue(calls.last().query.contains("id=in.(stu-1)"))
        assertTrue(repo.fetchStudentDetail(parent, foreignStudent).isFailure)

        // Verify zero write calls issued for Teacher, Student, or Parent
        for (roleSession in listOf(teacher, student, parent)) {
            val countBefore = calls.size
            assertTrue(repo.createStudent(roleSession, StudentDraft(studentName = "X")).isFailure)
            assertTrue(repo.updateStudent(roleSession, "stu-1", StudentDraft(id = "stu-1", studentName = "X")).isFailure)
            assertTrue(repo.uploadStudentPhoto(roleSession, "stu-1", byteArrayOf(1)).isFailure)
            assertTrue(repo.linkGuardian(roleSession, "stu-1", "uid-parent-1", "Father").isFailure)
            assertTrue(repo.unlinkGuardian(roleSession, GuardianLinkItem("sg-1", "stu-1", "uid-parent-1", null, null, null)).isFailure)
            assertEquals("No write network call allowed for ${roleSession.user.role}", countBefore, calls.size)
        }
    }

    @Test
    fun `students screen renders admin controls pagination and hides edit controls for teacher`() {
        val repo = buildRepository()
        val vm = StudentsViewModel(repository = repo, pageSize = 2)
        val sampleStudents = listOf(
            StudentRecord(
                id = "stu-1",
                profileId = "uid-student-1",
                studentName = "Aarav Mondal",
                admissionNo = "PMS-2026-014",
                rollNo = "14",
                classId = "cls-4",
                className = "Class IV",
                photoPath = "students/aarav.jpg",
                photoUrl = null,
                isActive = true,
            ),
        )
        val uiState = StudentsUiState(
            classes = listOf(SchoolClassItem("cls-4", "Class IV", "A")),
            studentsState = LoadableState.Success(sampleStudents),
            totalCount = 3,
            hasMore = true,
        )

        composeRule.setContent {
            CompositionLocalProvider(
                LocalAppLanguage provides AppLanguage.ENGLISH,
                LocalAppStrings provides stringsFor(AppLanguage.ENGLISH),
            ) {
                ShubhadishaErpTheme {
                    StudentsScreen(
                        session = sessionFor(UserRole.TEACHER),
                        uiState = uiState,
                        viewModel = vm,
                        onLanguageSelected = {},
                        onBack = {},
                    )
                }
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("students_role_banner").assertIsDisplayed()
        composeRule.onNodeWithTag("students_pagination_summary").assertIsDisplayed()
        composeRule.onNodeWithText("Aarav Mondal").assertIsDisplayed()
        composeRule.onNode(SemanticsMatcher.keyIsDefined(SemanticsProperties.VerticalScrollAxisRange))
            .performScrollToNode(hasTestTag("load_more_students_button"))
        composeRule.onNodeWithTag("load_more_students_button").assertIsDisplayed()
        composeRule.onAllNodesWithTag("add_student_fab").assertCountEquals(0)
        composeRule.onAllNodesWithTag("edit_student_stu-1").assertCountEquals(0)
    }

    @Test
    fun `admin students screen renders add fab status filters and edit button`() {
        val repo = buildRepository()
        val vm = StudentsViewModel(repository = repo, pageSize = 2)
        val sampleStudents = listOf(
            StudentRecord(
                id = "stu-1",
                profileId = "uid-student-1",
                studentName = "Aarav Mondal",
                admissionNo = "PMS-2026-014",
                rollNo = "14",
                classId = "cls-4",
                className = "Class IV",
                photoPath = "students/aarav.jpg",
                photoUrl = null,
                isActive = true,
            ),
        )
        val uiState = StudentsUiState(
            classes = listOf(SchoolClassItem("cls-4", "Class IV", "A")),
            studentsState = LoadableState.Success(sampleStudents),
            totalCount = 1,
            hasMore = false,
        )

        composeRule.setContent {
            CompositionLocalProvider(
                LocalAppLanguage provides AppLanguage.ENGLISH,
                LocalAppStrings provides stringsFor(AppLanguage.ENGLISH),
            ) {
                ShubhadishaErpTheme {
                    StudentsScreen(
                        session = sessionFor(UserRole.ADMIN),
                        uiState = uiState,
                        viewModel = vm,
                        onLanguageSelected = {},
                        onBack = {},
                    )
                }
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("add_student_fab").assertIsDisplayed()
        composeRule.onNodeWithTag("student_status_filter_active").assertIsDisplayed()
        composeRule.onNodeWithTag("edit_student_stu-1").assertIsDisplayed()
    }

    @Test
    fun `student profile displays personal academic guardian tabs and bilingual Bengali labels`() {
        val sample = StudentRecord(
            id = "stu-1",
            profileId = "uid-student-1",
            studentName = "Aarav Mondal",
            admissionNo = "PMS-2026-014",
            rollNo = "14",
            classId = "cls-4",
            className = "Class IV",
            classSection = "A",
            academicYear = "2026-27",
            photoPath = null,
            photoUrl = null,
            isActive = true,
        )
        val detail = StudentDetailPayload(
            student = sample,
            guardians = listOf(
                GuardianLinkItem(
                    id = "sg-1",
                    studentId = "stu-1",
                    parentProfileId = "uid-parent-1",
                    parentName = "Subhash Mondal",
                    parentPhone = "9830011223",
                    relationship = "Father",
                    isPrimary = true,
                ),
            ),
            linkedProfile = LinkedAccountProfile("uid-student-1", "Aarav Mondal", "9830011224", "student", true),
        )

        composeRule.setContent {
            CompositionLocalProvider(
                LocalAppLanguage provides AppLanguage.BENGALI,
                LocalAppStrings provides stringsFor(AppLanguage.BENGALI),
            ) {
                ShubhadishaErpTheme(language = AppLanguage.BENGALI) {
                    StudentProfileContent(
                        session = sessionFor(UserRole.ADMIN),
                        student = sample,
                        detailState = LoadableState.Success(detail),
                        parentOptions = emptyList(),
                        showLinkGuardianDialog = false,
                        isMutatingGuardian = false,
                        actionError = null,
                        showTopBar = true,
                        onBack = {},
                        onRefresh = {},
                        onEdit = {},
                        onOpenLinkGuardian = {},
                        onDismissLinkGuardian = {},
                        onConfirmLinkGuardian = { _, _ -> },
                        onUnlinkGuardian = {},
                    )
                }
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithText("শিক্ষার্থী আইডি: stu-1").assertIsDisplayed()
        composeRule.onNodeWithText("ভর্তি নং: PMS-2026-014").assertIsDisplayed()
        composeRule.onNodeWithTag("student_profile_tab_2").performClick()
        composeRule.waitForIdle()
        composeRule.onNode(SemanticsMatcher.keyIsDefined(SemanticsProperties.VerticalScrollAxisRange))
            .performScrollToIndex(2)
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Subhash Mondal").assertIsDisplayed()
        composeRule.onNodeWithText("9830011223").assertIsDisplayed()
    }

    @Test
    fun `navigation routes route students and teachers live`() {
        assertEquals(AppRoutes.STUDENTS, AppRoutes.moduleRoute(ErpModule.STUDENTS))
        assertEquals(AppRoutes.TEACHERS, AppRoutes.moduleRoute(ErpModule.TEACHERS))
    }
}
