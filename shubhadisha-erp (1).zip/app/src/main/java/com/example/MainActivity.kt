package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.erp.core.di.AppContainer
import com.example.erp.core.i18n.LocalAppLanguage
import com.example.erp.core.i18n.LocalAppStrings
import com.example.erp.core.i18n.stringsFor
import com.example.erp.features.admission.AdmissionViewModel
import com.example.erp.features.auth.AuthViewModel
import com.example.erp.features.notices.NoticesHolidaysViewModel
import com.example.erp.features.students.StudentsViewModel
import com.example.erp.features.teachers.TeachersViewModel
import com.example.erp.ui.components.LocalAuthenticatedImageLoader
import com.example.erp.ui.navigation.ErpNavHost
import com.example.ui.theme.ShubhadishaErpTheme

class MainActivity : ComponentActivity() {
    private val appContainer by lazy { AppContainer(applicationContext) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val authViewModel: AuthViewModel = viewModel(
                factory = AuthViewModel.Factory(
                    supabaseConfig = appContainer.supabaseConfig,
                    sessionStore = appContainer.sessionStore,
                    authService = appContainer.authService,
                    onActiveTokenChanged = appContainer::updateActiveAccessToken,
                ),
            )
            val noticesHolidaysViewModel: NoticesHolidaysViewModel = viewModel(
                factory = NoticesHolidaysViewModel.Factory(
                    repository = appContainer.noticesHolidaysRepository,
                ),
            )
            val studentsViewModel: StudentsViewModel = viewModel(
                factory = StudentsViewModel.Factory(
                    repository = appContainer.studentsRepository,
                ),
            )
            val teachersViewModel: TeachersViewModel = viewModel(
                factory = TeachersViewModel.Factory(
                    repository = appContainer.teachersRepository,
                ),
            )
            val admissionViewModel: AdmissionViewModel = viewModel(
                factory = AdmissionViewModel.Factory(
                    repository = appContainer.admissionRepository,
                ),
            )

            val language by authViewModel.language.collectAsStateWithLifecycle()
            val authState by authViewModel.authState.collectAsStateWithLifecycle()
            val loginForm by authViewModel.loginForm.collectAsStateWithLifecycle()
            val noticesHolidaysState by noticesHolidaysViewModel.uiState.collectAsStateWithLifecycle()
            val studentsState by studentsViewModel.uiState.collectAsStateWithLifecycle()
            val teachersState by teachersViewModel.uiState.collectAsStateWithLifecycle()
            val admissionState by admissionViewModel.uiState.collectAsStateWithLifecycle()

            val strings = stringsFor(language)

            CompositionLocalProvider(
                LocalAppLanguage provides language,
                LocalAppStrings provides strings,
                LocalAuthenticatedImageLoader provides appContainer.authenticatedImageLoader,
            ) {
                ShubhadishaErpTheme(language = language) {
                    ErpNavHost(
                        authState = authState,
                        loginForm = loginForm,
                        isSupabaseConfigured = authViewModel.supabaseConfig.isConfigured,
                        noticesHolidaysState = noticesHolidaysState,
                        noticesHolidaysViewModel = noticesHolidaysViewModel,
                        studentsState = studentsState,
                        studentsViewModel = studentsViewModel,
                        teachersState = teachersState,
                        teachersViewModel = teachersViewModel,
                        admissionState = admissionState,
                        admissionViewModel = admissionViewModel,
                        onLanguageSelected = authViewModel::setLanguage,
                        onRoleSelected = authViewModel::selectRole,
                        onEmailChanged = authViewModel::updateEmail,
                        onPasswordChanged = authViewModel::updatePassword,
                        onTogglePasswordVisibility = authViewModel::togglePasswordVisibility,
                        onSignInClick = authViewModel::signIn,
                        onForgotPasswordClick = authViewModel::openResetDialog,
                        onDismissResetDialog = authViewModel::dismissResetDialog,
                        onResetEmailChanged = authViewModel::updateResetEmail,
                        onSubmitPasswordReset = authViewModel::submitPasswordReset,
                        onSyncProfile = authViewModel::syncProfileAndSnapshot,
                        onSignOut = {
                            noticesHolidaysViewModel.resetSessionState()
                            studentsViewModel.resetSessionState()
                            teachersViewModel.resetSessionState()
                            admissionViewModel.resetSessionState()
                            authViewModel.signOut()
                        },
                    )
                }
            }
        }
    }
}
