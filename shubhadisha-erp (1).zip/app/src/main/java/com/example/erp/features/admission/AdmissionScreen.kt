package com.example.erp.features.admission

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.HowToReg
import androidx.compose.material.icons.rounded.PersonSearch
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.erp.core.i18n.AppLanguage
import com.example.erp.core.i18n.AppStrings
import com.example.erp.core.i18n.LocalAppLanguage
import com.example.erp.core.i18n.LocalAppStrings
import com.example.erp.core.model.AdmissionEnquiryDraft
import com.example.erp.core.model.AdmissionEnquiryRecord
import com.example.erp.core.model.AdmissionEnrollDraft
import com.example.erp.core.model.AdmissionStatus
import com.example.erp.core.model.AdmissionStatusFilter
import com.example.erp.core.model.AuthSession
import com.example.erp.core.model.LoadableState
import com.example.erp.core.model.SchoolClassItem
import com.example.erp.ui.components.LanguageTogglePill
import com.example.erp.ui.components.roleAccentColor
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LocalExtendedColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdmissionScreen(
    session: AuthSession,
    uiState: AdmissionUiState,
    viewModel: AdmissionViewModel,
    onLanguageSelected: (AppLanguage) -> Unit,
    onBack: () -> Unit,
) {
    val strings = LocalAppStrings.current
    val language = LocalAppLanguage.current
    val accent = roleAccentColor(session.user.role)

    LaunchedEffect(session.user.userId) {
        viewModel.ensureLoaded(session)
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isTwoPane = maxWidth >= 840.dp
        val selected = uiState.selectedEnquiry

        if (!isTwoPane && selected != null) {
            BackHandler { viewModel.closeDetail() }
            AdmissionDetailPane(
                enquiry = selected,
                accent = accent,
                strings = strings,
                isMutating = uiState.isMutating,
                actionMessage = uiState.actionMessage,
                actionError = uiState.actionError,
                showTopBar = true,
                onBack = viewModel::closeDetail,
                onEdit = { viewModel.openEditDialog(session, selected) },
                onDelete = { viewModel.requestDelete(selected) },
                onStatusChange = { status -> viewModel.updateStatus(session, selected, status) },
                onEnroll = { viewModel.openEnrollDialog(session, selected) },
            )
        } else {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                contentWindowInsets = WindowInsets.navigationBars,
                topBar = {
                    TopAppBar(
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                        ),
                        title = {
                            Column {
                                Text(
                                    text = strings.modAdmission,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                )
                                Text(
                                    text = session.user.role.label(strings),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = accent,
                                )
                            }
                        },
                        navigationIcon = {
                            IconButton(
                                onClick = onBack,
                                modifier = Modifier.testTag("admission_back_button"),
                            ) {
                                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = strings.backToOverview)
                            }
                        },
                        actions = {
                            IconButton(
                                onClick = { viewModel.refreshAll(session) },
                                modifier = Modifier.testTag("admission_refresh_button"),
                            ) {
                                Icon(Icons.Rounded.Refresh, contentDescription = strings.refreshActionDesc)
                            }
                            LanguageTogglePill(
                                currentLanguage = language,
                                onLanguageSelected = onLanguageSelected,
                                modifier = Modifier.padding(end = 8.dp),
                            )
                        },
                    )
                },
                floatingActionButton = {
                    FloatingActionButton(
                        onClick = { viewModel.openCreateDialog(session) },
                        containerColor = accent,
                        contentColor = Color.White,
                        modifier = Modifier.testTag("new_enquiry_fab"),
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = strings.admission.newEnquiryButton)
                    }
                },
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                ) {
                    Box(
                        modifier = Modifier
                            .weight(if (isTwoPane && selected != null) 0.48f else 1f)
                            .fillMaxHeight(),
                        contentAlignment = Alignment.TopCenter,
                    ) {
                        Column(
                            modifier = Modifier
                                .widthIn(max = 900.dp)
                                .fillMaxSize(),
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                OutlinedTextField(
                                    value = uiState.searchQuery,
                                    onValueChange = { viewModel.updateSearchQuery(session, it) },
                                    placeholder = { Text(strings.admission.searchAdmissionHint) },
                                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                                    trailingIcon = {
                                        if (uiState.searchQuery.isNotEmpty()) {
                                            IconButton(onClick = { viewModel.updateSearchQuery(session, "") }) {
                                                Icon(Icons.Rounded.Close, contentDescription = strings.clearDate)
                                            }
                                        }
                                    },
                                    singleLine = true,
                                    shape = MaterialTheme.shapes.medium,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("admission_search_input"),
                                )

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    listOf(
                                        AdmissionStatusFilter.ALL to strings.filterAll,
                                        AdmissionStatusFilter.PENDING to strings.admission.statusPendingLabel,
                                        AdmissionStatusFilter.REVIEWED to strings.admission.statusReviewedLabel,
                                        AdmissionStatusFilter.APPROVED to strings.admission.statusApprovedLabel,
                                        AdmissionStatusFilter.ADMITTED to strings.admission.statusAdmittedLabel,
                                        AdmissionStatusFilter.REJECTED to strings.admission.statusRejectedLabel,
                                    ).forEach { (filter, label) ->
                                        FilterChip(
                                            selected = uiState.statusFilter == filter,
                                            onClick = { viewModel.selectStatusFilter(session, filter) },
                                            label = { Text(label) },
                                            modifier = Modifier.testTag("admission_filter_${filter.name.lowercase()}"),
                                        )
                                    }
                                }
                            }

                            when (val state = uiState.enquiriesState) {
                                LoadableState.Loading -> {
                                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        CircularProgressIndicator()
                                    }
                                }
                                is LoadableState.Error -> {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(24.dp),
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.spacedBy(12.dp),
                                        ) {
                                            Text(state.message, color = MaterialTheme.colorScheme.error)
                                            Button(onClick = { viewModel.loadEnquiries(session) }) {
                                                Text(strings.retryButton)
                                            }
                                        }
                                    }
                                }
                                is LoadableState.Success -> {
                                    if (state.items.isEmpty()) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .padding(24.dp),
                                            contentAlignment = Alignment.Center,
                                        ) {
                                            Column(
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Rounded.PersonSearch,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    modifier = Modifier.size(44.dp),
                                                )
                                                Text(
                                                    text = strings.admission.noEnquiriesFound,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                )
                                            }
                                        }
                                    } else {
                                        LazyColumn(
                                            modifier = Modifier.fillMaxSize(),
                                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 88.dp),
                                            verticalArrangement = Arrangement.spacedBy(12.dp),
                                        ) {
                                            items(state.items, key = { it.id }) { item ->
                                                EnquiryCard(
                                                    item = item,
                                                    isSelected = selected?.id == item.id,
                                                    accent = accent,
                                                    strings = strings,
                                                    onClick = { viewModel.openDetail(item) },
                                                    onEdit = { viewModel.openEditDialog(session, item) },
                                                    onDelete = { viewModel.requestDelete(item) },
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (isTwoPane && selected != null) {
                        VerticalDivider()
                        Box(
                            modifier = Modifier
                                .weight(0.52f)
                                .fillMaxHeight(),
                        ) {
                            AdmissionDetailPane(
                                enquiry = selected,
                                accent = accent,
                                strings = strings,
                                isMutating = uiState.isMutating,
                                actionMessage = uiState.actionMessage,
                                actionError = uiState.actionError,
                                showTopBar = false,
                                onBack = viewModel::closeDetail,
                                onEdit = { viewModel.openEditDialog(session, selected) },
                                onDelete = { viewModel.requestDelete(selected) },
                                onStatusChange = { status -> viewModel.updateStatus(session, selected, status) },
                                onEnroll = { viewModel.openEnrollDialog(session, selected) },
                            )
                        }
                    }
                }
            }
        }
    }

    uiState.editingDraft?.let { draft ->
        AdmissionEditorDialog(
            draft = draft,
            classes = uiState.classes,
            isSaving = uiState.isSaving,
            errorMessage = uiState.formError,
            onDraftChange = { updated -> viewModel.updateDraft { updated } },
            onDismiss = viewModel::dismissEditor,
            onSave = { viewModel.saveDraft(session, strings.studentNameRequiredError) },
        )
    }

    uiState.enrollDraft?.let { enroll ->
        EnrollStudentDialog(
            draft = enroll,
            classes = uiState.classes,
            isSaving = uiState.isSaving,
            errorMessage = uiState.formError,
            onDraftChange = { updated -> viewModel.updateEnrollDraft { updated } },
            onDismiss = viewModel::dismissEnrollDialog,
            onConfirm = { viewModel.confirmEnrollStudent(session, strings.admission.enrolledSuccessMessage) },
        )
    }

    uiState.pendingDelete?.let { target ->
        AlertDialog(
            onDismissRequest = viewModel::dismissDelete,
            title = { Text(strings.admission.deleteEnquiryTitle) },
            text = { Text("${target.studentName}\n\n${strings.admission.deleteEnquiryBody}") },
            confirmButton = {
                Button(onClick = { viewModel.confirmDelete(session) }, enabled = !uiState.isMutating) {
                    Text(strings.deleteButton)
                }
            },
            dismissButton = {
                TextButton(onClick = viewModel::dismissDelete, enabled = !uiState.isMutating) {
                    Text(strings.cancel)
                }
            },
        )
    }
}

@Composable
private fun EnquiryCard(
    item: AdmissionEnquiryRecord,
    isSelected: Boolean,
    accent: Color,
    strings: AppStrings,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = if (isSelected) accent.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(
            width = if (isSelected) 1.5.dp else 1.dp,
            color = if (isSelected) accent else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f),
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .testTag("enquiry_card_${item.id}"),
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        text = item.studentName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    AdmissionStatusBadge(status = item.status, strings = strings)
                }
                val sub = listOfNotNull(
                    item.appliedClass.takeIf { it.isNotBlank() },
                    item.guardianName.takeIf { it.isNotBlank() },
                ).joinToString(" • ")
                if (sub.isNotBlank()) {
                    Text(
                        text = sub,
                        style = MaterialTheme.typography.bodySmall,
                        color = accent,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
                Text(
                    text = listOfNotNull(
                        item.recordId,
                        item.phone.takeIf { it.isNotBlank() },
                        item.enquiryDate.takeIf { it.isNotBlank() },
                    ).joinToString("  •  "),
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            IconButton(onClick = onEdit, modifier = Modifier.testTag("edit_enquiry_${item.id}")) {
                Icon(Icons.Rounded.Edit, contentDescription = strings.editButton)
            }
            IconButton(onClick = onDelete, modifier = Modifier.testTag("delete_enquiry_${item.id}")) {
                Icon(Icons.Rounded.Delete, contentDescription = strings.deleteButton, tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun AdmissionDetailPane(
    enquiry: AdmissionEnquiryRecord,
    accent: Color,
    strings: AppStrings,
    isMutating: Boolean,
    actionMessage: String?,
    actionError: String?,
    showTopBar: Boolean,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onStatusChange: (AdmissionStatus) -> Unit,
    onEnroll: () -> Unit,
) {
    val extended = LocalExtendedColors.current
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets.navigationBars,
        topBar = {
            if (showTopBar) {
                TopAppBar(
                    title = { Text(enquiry.studentName, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = strings.backToOverview)
                        }
                    },
                    actions = {
                        IconButton(onClick = onEdit) {
                            Icon(Icons.Rounded.Edit, contentDescription = strings.editButton)
                        }
                        IconButton(onClick = onDelete) {
                            Icon(Icons.Rounded.Delete, contentDescription = strings.deleteButton, tint = MaterialTheme.colorScheme.error)
                        }
                    },
                )
            }
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (actionMessage != null) {
                Surface(shape = MaterialTheme.shapes.small, color = extended.successContainer) {
                    Text(
                        text = actionMessage,
                        color = extended.success,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(12.dp),
                    )
                }
            }
            if (actionError != null) {
                Surface(shape = MaterialTheme.shapes.small, color = MaterialTheme.colorScheme.errorContainer) {
                    Text(
                        text = actionError,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(12.dp),
                    )
                }
            }

            Surface(
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surfaceContainerLowest,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = enquiry.studentName,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                        )
                        AdmissionStatusBadge(status = enquiry.status, strings = strings)
                    }
                    AdmissionField(strings.admission.enquiryIdLabel, enquiry.recordId, mono = true)
                    AdmissionField(strings.admission.appliedClassLabel, enquiry.appliedClass.ifBlank { strings.notProvidedValue })
                    AdmissionField(strings.guardianNameLabel, enquiry.guardianName.ifBlank { strings.notProvidedValue })
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Rounded.Phone, contentDescription = null, modifier = Modifier.size(16.dp), tint = accent)
                        Text(
                            text = enquiry.phone.ifBlank { strings.notProvidedValue },
                            style = MaterialTheme.typography.bodyMedium.copy(fontFamily = JetBrainsMonoFamily),
                        )
                    }
                    AdmissionField(strings.admission.enquiryDateLabel, enquiry.enquiryDate.ifBlank { strings.notProvidedValue }, mono = true)
                    enquiry.dateOfBirth?.let { AdmissionField(strings.dateOfBirthLabel, it, mono = true) }
                    enquiry.previousSchool?.let { AdmissionField(strings.admission.previousSchoolLabel, it) }
                    enquiry.address?.let { AdmissionField(strings.addressLabel, it) }
                    enquiry.notes?.let { AdmissionField(strings.admission.notesLabel, it) }
                }
            }

            Surface(
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surfaceContainerLowest,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text(strings.statusLabel, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        AdmissionStatus.entries.forEach { st ->
                            FilterChip(
                                selected = enquiry.status == st,
                                onClick = { if (!isMutating) onStatusChange(st) },
                                label = { Text(statusLabel(st, strings)) },
                                modifier = Modifier.testTag("set_status_${st.raw}"),
                            )
                        }
                    }

                    if (enquiry.status != AdmissionStatus.ADMITTED) {
                        Button(
                            onClick = onEnroll,
                            enabled = !isMutating,
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 48.dp)
                                .testTag("enroll_student_button"),
                        ) {
                            Icon(Icons.Rounded.HowToReg, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(strings.admission.enrollStudentButton)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AdmissionEditorDialog(
    draft: AdmissionEnquiryDraft,
    classes: List<SchoolClassItem>,
    isSaving: Boolean,
    errorMessage: String?,
    onDraftChange: (AdmissionEnquiryDraft) -> Unit,
    onDismiss: () -> Unit,
    onSave: () -> Unit,
) {
    val strings = LocalAppStrings.current
    AlertDialog(
        onDismissRequest = { if (!isSaving) onDismiss() },
        title = { Text(if (draft.id == null) strings.admission.createEnquiryTitle else strings.admission.editEnquiryTitle) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                OutlinedTextField(
                    value = draft.studentName,
                    onValueChange = { onDraftChange(draft.copy(studentName = it)) },
                    label = { Text(strings.studentNameLabel) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("admission_editor_student_name"),
                )
                OutlinedTextField(
                    value = draft.guardianName,
                    onValueChange = { onDraftChange(draft.copy(guardianName = it)) },
                    label = { Text(strings.guardianNameLabel) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("admission_editor_guardian"),
                )
                OutlinedTextField(
                    value = draft.phone,
                    onValueChange = { onDraftChange(draft.copy(phone = it)) },
                    label = { Text(strings.phoneLabel) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("admission_editor_phone"),
                )
                if (classes.isNotEmpty()) {
                    Text(strings.admission.appliedClassLabel, style = MaterialTheme.typography.labelMedium)
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        classes.forEach { cls ->
                            FilterChip(
                                selected = draft.classId == cls.id || draft.appliedClass.equals(cls.className, true),
                                onClick = {
                                    onDraftChange(draft.copy(classId = cls.id, appliedClass = cls.className))
                                },
                                label = { Text(cls.displayLabel) },
                            )
                        }
                    }
                } else {
                    OutlinedTextField(
                        value = draft.appliedClass,
                        onValueChange = { onDraftChange(draft.copy(appliedClass = it)) },
                        label = { Text(strings.admission.appliedClassLabel) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                OutlinedTextField(
                    value = draft.enquiryDate,
                    onValueChange = { onDraftChange(draft.copy(enquiryDate = it)) },
                    label = { Text("${strings.admission.enquiryDateLabel} (YYYY-MM-DD)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = draft.previousSchool,
                    onValueChange = { onDraftChange(draft.copy(previousSchool = it)) },
                    label = { Text(strings.admission.previousSchoolLabel) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = draft.address,
                    onValueChange = { onDraftChange(draft.copy(address = it)) },
                    label = { Text(strings.addressLabel) },
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = draft.notes,
                    onValueChange = { onDraftChange(draft.copy(notes = it)) },
                    label = { Text(strings.admission.notesLabel) },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth(),
                )
                if (errorMessage != null) {
                    Text(errorMessage, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onSave,
                enabled = !isSaving,
                modifier = Modifier.testTag("save_enquiry_button"),
            ) {
                Text(strings.admission.saveEnquiryButton)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !isSaving) { Text(strings.cancel) }
        },
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun EnrollStudentDialog(
    draft: AdmissionEnrollDraft,
    classes: List<SchoolClassItem>,
    isSaving: Boolean,
    errorMessage: String?,
    onDraftChange: (AdmissionEnrollDraft) -> Unit,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
) {
    val strings = LocalAppStrings.current
    AlertDialog(
        onDismissRequest = { if (!isSaving) onDismiss() },
        title = { Text(strings.admission.enrollDialogTitle) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(draft.enquiry.studentName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = draft.admissionNo,
                    onValueChange = { onDraftChange(draft.copy(admissionNo = it)) },
                    label = { Text(strings.admissionNoLabel) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = draft.rollNo,
                    onValueChange = { onDraftChange(draft.copy(rollNo = it)) },
                    label = { Text(strings.rollNoLabel) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                if (classes.isNotEmpty()) {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        classes.forEach { cls ->
                            FilterChip(
                                selected = draft.classId == cls.id,
                                onClick = { onDraftChange(draft.copy(classId = cls.id)) },
                                label = { Text(cls.displayLabel) },
                            )
                        }
                    }
                }
                if (errorMessage != null) {
                    Text(errorMessage, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                enabled = !isSaving,
                modifier = Modifier.testTag("confirm_enroll_button"),
            ) {
                Text(strings.admission.enrollStudentButton)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !isSaving) { Text(strings.cancel) }
        },
    )
}

@Composable
private fun AdmissionStatusBadge(status: AdmissionStatus, strings: AppStrings) {
    val extended = LocalExtendedColors.current
    val (bg, fg) = when (status) {
        AdmissionStatus.ADMITTED -> extended.successContainer to extended.success
        AdmissionStatus.APPROVED -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.primary
        AdmissionStatus.REVIEWED -> extended.warningContainer to extended.warning
        AdmissionStatus.REJECTED -> MaterialTheme.colorScheme.errorContainer to MaterialTheme.colorScheme.error
        AdmissionStatus.PENDING -> MaterialTheme.colorScheme.surfaceContainerHigh to MaterialTheme.colorScheme.onSurfaceVariant
    }
    Surface(shape = RoundedCornerShape(50), color = bg) {
        Text(
            text = statusLabel(status, strings),
            style = MaterialTheme.typography.labelSmall,
            color = fg,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
        )
    }
}

private fun statusLabel(status: AdmissionStatus, strings: AppStrings): String = when (status) {
    AdmissionStatus.PENDING -> strings.admission.statusPendingLabel
    AdmissionStatus.REVIEWED -> strings.admission.statusReviewedLabel
    AdmissionStatus.APPROVED -> strings.admission.statusApprovedLabel
    AdmissionStatus.ADMITTED -> strings.admission.statusAdmittedLabel
    AdmissionStatus.REJECTED -> strings.admission.statusRejectedLabel
}

@Composable
private fun AdmissionField(label: String, value: String, mono: Boolean = false) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            text = value,
            style = if (mono) MaterialTheme.typography.bodyMedium.copy(fontFamily = JetBrainsMonoFamily) else MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
        )
    }
}
