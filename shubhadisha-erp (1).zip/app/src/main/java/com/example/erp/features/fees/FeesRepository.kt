package com.example.erp.features.fees

import com.example.erp.core.model.AuthSession
import com.example.erp.core.model.FeeDraft
import com.example.erp.core.model.FeePaymentStatus
import com.example.erp.core.model.FeeRecord
import com.example.erp.core.model.FeeStatusFilter
import com.example.erp.core.model.SchoolClassItem
import com.example.erp.core.model.StudentRecord
import com.example.erp.core.model.UserRole
import com.example.erp.core.network.SupabaseClient
import com.example.erp.features.students.StudentsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

class FeesRepository(
    private val client: SupabaseClient,
    private val studentsRepository: StudentsRepository = StudentsRepository(client),
) {
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun fetchClasses(session: AuthSession): Result<List<SchoolClassItem>> =
        withContext(Dispatchers.IO) {
            runCatching {
                requireFeesAccess(session)
                if (session.user.role != UserRole.ADMIN) return@runCatching emptyList()
                studentsRepository.fetchClasses(session).getOrThrow()
            }
        }

    suspend fun fetchSelectableStudents(session: AuthSession): Result<List<StudentRecord>> =
        withContext(Dispatchers.IO) {
            runCatching {
                require(session.user.role == UserRole.ADMIN) {
                    "Only Admin can browse all students for fee billing."
                }
                studentsRepository.fetchStudentsPage(
                    session = session,
                    offset = 0,
                    limit = 100,
                ).getOrThrow().items
            }
        }

    suspend fun fetchFees(
        session: AuthSession,
        classId: String? = null,
        studentFilterId: String? = null,
        statusFilter: FeeStatusFilter = FeeStatusFilter.ALL,
        query: String = "",
    ): Result<List<FeeRecord>> = withContext(Dispatchers.IO) {
        runCatching {
            requireFeesAccess(session)
            val role = session.user.role
            val params = mutableListOf(
                "select=*,students(id,student_name,admission_no,roll_no,class_id,classes(id,class_name))",
                "order=created_at.desc",
            )

            when (role) {
                UserRole.STUDENT -> {
                    val ownId = session.user.studentInfo?.studentId
                        ?: resolveStudentIdByProfile(session)
                        ?: return@runCatching emptyList()
                    params.add("student_id=eq.${encode(ownId)}")
                }
                UserRole.PARENT -> {
                    val wardIds = fetchWardIds(session)
                    if (wardIds.isEmpty()) return@runCatching emptyList()
                    val targetIds = if (!studentFilterId.isNullOrBlank() && studentFilterId in wardIds) {
                        setOf(studentFilterId)
                    } else {
                        wardIds
                    }
                    params.add("student_id=in.(${targetIds.joinToString(",") { encode(it) }})")
                }
                UserRole.ADMIN -> {
                    if (!studentFilterId.isNullOrBlank()) {
                        params.add("student_id=eq.${encode(studentFilterId)}")
                    }
                    when (statusFilter) {
                        FeeStatusFilter.ALL -> Unit
                        FeeStatusFilter.PENDING -> params.add("payment_status=eq.pending")
                        FeeStatusFilter.PARTIAL -> params.add("payment_status=eq.partial")
                        FeeStatusFilter.PAID -> params.add("payment_status=eq.paid")
                    }
                }
                UserRole.TEACHER -> error("Teachers do not have access to Fee Register.")
            }

            val request = client.authenticatedRequestBuilder(
                path = "/rest/v1/fees?${params.joinToString("&")}",
                accessToken = session.accessToken,
            )
                .get()
                .build()

            val records = client.httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    error(extractRestError(body, response.code))
                }
                parseFeeArray(JSONArray(body))
            }

            val cleanQuery = query.trim().lowercase()
            records.filter { fee ->
                val matchesClass = classId.isNullOrBlank() || fee.classId == classId
                val matchesStatus = when (statusFilter) {
                    FeeStatusFilter.ALL -> true
                    FeeStatusFilter.PENDING -> fee.paymentStatus == FeePaymentStatus.PENDING
                    FeeStatusFilter.PARTIAL -> fee.paymentStatus == FeePaymentStatus.PARTIAL
                    FeeStatusFilter.PAID -> fee.paymentStatus == FeePaymentStatus.PAID
                }
                val matchesSearch = cleanQuery.isEmpty() ||
                    fee.studentName.lowercase().contains(cleanQuery) ||
                    fee.feeName.lowercase().contains(cleanQuery) ||
                    fee.receiptNo.orEmpty().lowercase().contains(cleanQuery) ||
                    fee.admissionNo.orEmpty().lowercase().contains(cleanQuery)
                matchesClass && matchesStatus && matchesSearch
            }
        }
    }

    suspend fun createFee(
        session: AuthSession,
        draft: FeeDraft,
    ): Result<FeeRecord> = withContext(Dispatchers.IO) {
        runCatching {
            require(session.user.role == UserRole.ADMIN) {
                "Only Admin can create fee records."
            }
            val amount = draft.amount.trim().toDoubleOrNull()?.coerceAtLeast(0.0)
                ?: error("Enter a valid numeric fee amount.")
            val paid = draft.paidAmount.trim().toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
            val computedStatus = when {
                amount > 0.0 && paid >= amount -> FeePaymentStatus.PAID
                paid > 0.0 -> FeePaymentStatus.PARTIAL
                else -> FeePaymentStatus.PENDING
            }
            val payload = JSONObject().apply {
                put("student_id", draft.studentId.trim())
                put("fee_name", draft.feeName.trim())
                put("amount", amount)
                put("due_date", draft.dueDate.trim().ifEmpty { JSONObject.NULL })
                put("paid_amount", paid)
                put("payment_date", draft.paymentDate.trim().ifEmpty { JSONObject.NULL })
                put("payment_status", computedStatus.raw)
                put("receipt_no", draft.receiptNo.trim().ifEmpty { JSONObject.NULL })
            }.toString()

            val request = client.authenticatedRequestBuilder(
                path = "/rest/v1/fees?select=*,students(id,student_name,admission_no,roll_no,class_id,classes(id,class_name))",
                accessToken = session.accessToken,
            )
                .header("Prefer", "return=representation")
                .post(payload.toRequestBody(jsonMediaType))
                .build()

            client.httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) error(extractRestError(body, response.code))
                parseFeeArray(JSONArray(body)).firstOrNull()
                    ?: error("Fee saved but no row returned (check RLS).")
            }
        }
    }

    suspend fun updateFee(
        session: AuthSession,
        feeId: String,
        draft: FeeDraft,
    ): Result<FeeRecord> = withContext(Dispatchers.IO) {
        runCatching {
            require(session.user.role == UserRole.ADMIN) {
                "Only Admin can edit fee records."
            }
            val amount = draft.amount.trim().toDoubleOrNull()?.coerceAtLeast(0.0)
                ?: error("Enter a valid numeric fee amount.")
            val paid = draft.paidAmount.trim().toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
            val computedStatus = when {
                amount > 0.0 && paid >= amount -> FeePaymentStatus.PAID
                paid > 0.0 -> FeePaymentStatus.PARTIAL
                else -> FeePaymentStatus.PENDING
            }
            val payload = JSONObject().apply {
                put("student_id", draft.studentId.trim())
                put("fee_name", draft.feeName.trim())
                put("amount", amount)
                put("due_date", draft.dueDate.trim().ifEmpty { JSONObject.NULL })
                put("paid_amount", paid)
                put("payment_date", draft.paymentDate.trim().ifEmpty { JSONObject.NULL })
                put("payment_status", computedStatus.raw)
                put("receipt_no", draft.receiptNo.trim().ifEmpty { JSONObject.NULL })
            }.toString()

            val request = client.authenticatedRequestBuilder(
                path = "/rest/v1/fees?id=eq.${encode(feeId)}&select=*,students(id,student_name,admission_no,roll_no,class_id,classes(id,class_name))",
                accessToken = session.accessToken,
            )
                .header("Prefer", "return=representation")
                .patch(payload.toRequestBody(jsonMediaType))
                .build()

            client.httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) error(extractRestError(body, response.code))
                parseFeeArray(JSONArray(body)).firstOrNull()
                    ?: error("Fee updated but no row returned (check RLS).")
            }
        }
    }

    suspend fun recordPayment(
        session: AuthSession,
        fee: FeeRecord,
        additionalPayment: Double,
        paymentDate: String,
        receiptNo: String,
    ): Result<FeeRecord> = withContext(Dispatchers.IO) {
        runCatching {
            require(session.user.role == UserRole.ADMIN) {
                "Only Admin can collect fee payments."
            }
            require(additionalPayment > 0.0) { "Payment amount must be greater than zero." }
            val newPaid = (fee.paidAmount + additionalPayment).coerceAtMost(fee.amount.coerceAtLeast(fee.paidAmount + additionalPayment))
            val newStatus = if (fee.amount > 0.0 && newPaid >= fee.amount) {
                FeePaymentStatus.PAID
            } else {
                FeePaymentStatus.PARTIAL
            }
            val finalReceiptNo = receiptNo.trim().ifEmpty {
                fee.receiptNo?.takeIf { it.isNotBlank() } ?: "PMS-RCP-${System.currentTimeMillis().toString().takeLast(6)}"
            }
            val payload = JSONObject().apply {
                put("paid_amount", newPaid)
                put("payment_date", paymentDate.trim())
                put("payment_status", newStatus.raw)
                put("receipt_no", finalReceiptNo)
            }.toString()

            val request = client.authenticatedRequestBuilder(
                path = "/rest/v1/fees?id=eq.${encode(fee.id)}&select=*,students(id,student_name,admission_no,roll_no,class_id,classes(id,class_name))",
                accessToken = session.accessToken,
            )
                .header("Prefer", "return=representation")
                .patch(payload.toRequestBody(jsonMediaType))
                .build()

            client.httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) error(extractRestError(body, response.code))
                parseFeeArray(JSONArray(body)).firstOrNull()
                    ?: error("Payment recorded but no row returned (check RLS).")
            }
        }
    }

    suspend fun deleteFee(session: AuthSession, feeId: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                require(session.user.role == UserRole.ADMIN) {
                    "Only Admin can delete fee entries."
                }
                val request = client.authenticatedRequestBuilder(
                    path = "/rest/v1/fees?id=eq.${encode(feeId)}",
                    accessToken = session.accessToken,
                )
                    .delete()
                    .build()
                client.httpClient.newCall(request).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    if (!response.isSuccessful) error(extractRestError(body, response.code))
                }
            }
        }

    private fun requireFeesAccess(session: AuthSession) {
        require(session.user.role in setOf(UserRole.ADMIN, UserRole.STUDENT, UserRole.PARENT)) {
            "Teachers do not have access to Fees & Receipts."
        }
    }

    private fun resolveStudentIdByProfile(session: AuthSession): String? {
        val req = client.authenticatedRequestBuilder(
            path = "/rest/v1/students?profile_id=eq.${encode(session.user.userId)}&select=id&limit=1",
            accessToken = session.accessToken,
        ).get().build()
        return runCatching {
            client.httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@runCatching null
                val arr = JSONArray(resp.body?.string().orEmpty())
                if (arr.length() > 0) arr.getJSONObject(0).optNullableString("id") else null
            }
        }.getOrNull()
    }

    private fun fetchWardIds(session: AuthSession): Set<String> {
        val ids = linkedSetOf<String>()
        session.user.linkedWards.forEach { if (it.studentId.isNotBlank()) ids.add(it.studentId) }
        val req = client.authenticatedRequestBuilder(
            path = "/rest/v1/student_guardians?parent_profile_id=eq.${encode(session.user.userId)}&select=student_id",
            accessToken = session.accessToken,
        ).get().build()
        runCatching {
            client.httpClient.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    val arr = JSONArray(resp.body?.string().orEmpty())
                    for (i in 0 until arr.length()) {
                        arr.getJSONObject(i).optNullableString("student_id")?.let { ids.add(it) }
                    }
                }
            }
        }
        return ids
    }

    private fun parseFeeArray(array: JSONArray): List<FeeRecord> {
        val list = mutableListOf<FeeRecord>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val id = obj.optNullableString("id") ?: continue
            val stObj = obj.optJSONObject("students")
            val clsObj = stObj?.optJSONObject("classes")
            val amount = obj.optDouble("amount", 0.0).takeIf { !it.isNaN() } ?: 0.0
            val paidAmount = obj.optDouble("paid_amount", 0.0).takeIf { !it.isNaN() } ?: 0.0
            list.add(
                FeeRecord(
                    id = id,
                    studentId = obj.optString("student_id", ""),
                    studentName = stObj?.optNullableString("student_name") ?: "Student",
                    admissionNo = stObj?.optNullableString("admission_no"),
                    rollNo = stObj?.optNullableString("roll_no"),
                    classId = stObj?.optNullableString("class_id"),
                    className = clsObj?.optNullableString("class_name"),
                    feeName = obj.optString("fee_name", ""),
                    amount = amount,
                    dueDate = obj.optNullableString("due_date"),
                    paidAmount = paidAmount,
                    paymentDate = obj.optNullableString("payment_date"),
                    paymentStatus = FeePaymentStatus.fromRaw(
                        obj.optNullableString("payment_status"),
                        amount = amount,
                        paidAmount = paidAmount,
                    ),
                    receiptNo = obj.optNullableString("receipt_no"),
                    createdAt = obj.optString("created_at", ""),
                ),
            )
        }
        return list
    }

    private fun JSONObject.optNullableString(key: String): String? {
        if (!has(key) || isNull(key)) return null
        val value = optString(key).trim()
        return value.takeIf { it.isNotEmpty() && it != "null" }
    }

    private fun extractRestError(rawBody: String, statusCode: Int): String = runCatching {
        val json = JSONObject(rawBody)
        json.optString("message").takeIf { it.isNotBlank() }
            ?: json.optString("hint").takeIf { it.isNotBlank() }
            ?: json.optString("error").takeIf { it.isNotBlank() }
            ?: "Request failed (HTTP $statusCode)"
    }.getOrDefault("Request failed (HTTP $statusCode)")

    private fun encode(value: String): String = URLEncoder.encode(value, "UTF-8")
}
