package com.example.erp.core.model

import androidx.compose.runtime.Immutable

@Immutable
data class SchoolClassItem(
    val id: String,
    val className: String,
    val section: String? = null,
    val academicYear: String? = null,
) {
    val displayLabel: String
        get() = listOfNotNull(className.takeIf { it.isNotBlank() }, section?.takeIf { it.isNotBlank() })
            .joinToString(" • ")
}

@Immutable
data class GuardianLinkItem(
    val id: String?,
    val studentId: String,
    val parentProfileId: String?,
    val parentName: String?,
    val parentPhone: String?,
    val relationship: String?,
    val isPrimary: Boolean = false,
)

@Immutable
data class LinkedAccountProfile(
    val id: String,
    val fullName: String,
    val phone: String?,
    val role: String?,
    val isActive: Boolean,
)

@Immutable
data class StudentRecord(
    val id: String,
    val profileId: String?,
    val studentName: String,
    val admissionNo: String?,
    val rollNo: String?,
    val classId: String?,
    val className: String?,
    val classSection: String? = null,
    val academicYear: String? = null,
    val photoPath: String?,
    val photoUrl: String?,
    val isActive: Boolean,
    val dateOfBirth: String? = null,
    val gender: String? = null,
    val bloodGroup: String? = null,
    val phone: String? = null,
    val email: String? = null,
    val address: String? = null,
    val admissionDate: String? = null,
    val fatherName: String? = null,
    val motherName: String? = null,
    val guardianName: String? = null,
    val guardianPhone: String? = null,
    val createdAt: String = "",
    val extraFields: Map<String, String> = emptyMap(),
    val knownColumns: Set<String> = DEFAULT_CORE_COLUMNS,
) {
    companion object {
        val DEFAULT_CORE_COLUMNS = setOf(
            "id",
            "profile_id",
            "student_name",
            "admission_no",
            "roll_no",
            "class_id",
            "photo_url",
            "is_active",
        )
    }
}

@Immutable
data class StudentDraft(
    val id: String? = null,
    val studentName: String = "",
    val admissionNo: String = "",
    val rollNo: String = "",
    val classId: String = "",
    val photoPath: String = "",
    val photoPreviewUrl: String? = null,
    val isActive: Boolean = true,
    val dateOfBirth: String = "",
    val gender: String = "",
    val bloodGroup: String = "",
    val phone: String = "",
    val address: String = "",
    val guardianName: String = "",
    val guardianPhone: String = "",
)

@Immutable
data class ParentProfileOption(
    val id: String,
    val fullName: String,
    val phone: String?,
)

enum class StudentStatusFilter {
    ALL,
    ACTIVE,
    INACTIVE,
}
