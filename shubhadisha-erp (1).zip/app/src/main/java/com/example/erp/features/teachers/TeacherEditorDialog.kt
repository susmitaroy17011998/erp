package com.example.erp.features.teachers

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddAPhoto
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.School
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.erp.core.i18n.LocalAppStrings
import com.example.erp.core.model.StaffDraft
import com.example.erp.core.model.StaffProfileOption
import com.example.erp.core.util.ImageCompressionUtil
import com.example.erp.ui.components.AuthenticatedAvatar
import com.example.ui.theme.LocalExtendedColors
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TeacherEditorDialog(
    draft: StaffDraft,
    profileOptions: List<StaffProfileOption>,
    isSaving: Boolean,
    isUploadingPhoto: Boolean,
    photoUploadNotice: String?,
    errorMessage: String?,
    onDraftChange: (StaffDraft) -> Unit,
    onUploadPhotoBytes: (bytes: ByteArray, mimeType: String, extension: String) -> Unit,
    onDismiss: () -> Unit,
    onSave: () -> Unit,
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val busy = isSaving || isUploadingPhoto

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val prepared = ImageCompressionUtil.readAndCompressImage(context, uri)
                if (prepared != null) {
                    onUploadPhotoBytes(prepared.bytes, prepared.mimeType, prepared.extension)
                }
            }
        }
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = {
            Text(if (draft.id == null) strings.teachers.addStaffTitle else strings.teachers.editStaffTitle)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    AuthenticatedAvatar(
                        photoUrl = draft.photoPreviewUrl,
                        contentDescription = draft.staffName.ifBlank { strings.teachers.staffNameLabel },
                        accentColor = MaterialTheme.colorScheme.primary,
                        fallbackIcon = Icons.Rounded.School,
                        size = 64.dp,
                    )
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        OutlinedButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly),
                                )
                            },
                            enabled = !busy,
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 48.dp)
                                .testTag("upload_staff_photo_button"),
                        ) {
                            if (isUploadingPhoto) {
                                CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(strings.uploadingPhotoLabel)
                            } else {
                                Icon(Icons.Rounded.AddAPhoto, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(if (draft.photoPath.isBlank()) strings.uploadPhotoButton else strings.changePhotoButton)
                            }
                        }
                        if (photoUploadNotice != null) {
                            Surface(
                                shape = MaterialTheme.shapes.small,
                                color = LocalExtendedColors.current.successContainer,
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.CheckCircle,
                                        contentDescription = null,
                                        tint = LocalExtendedColors.current.success,
                                        modifier = Modifier.size(14.dp),
                                    )
                                    Text(
                                        text = photoUploadNotice,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = LocalExtendedColors.current.success,
                                    )
                                }
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = draft.staffName,
                    onValueChange = { onDraftChange(draft.copy(staffName = it)) },
                    label = { Text(strings.teachers.staffNameLabel) },
                    singleLine = true,
                    enabled = !busy,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("staff_editor_name"),
                )

                OutlinedTextField(
                    value = draft.designation,
                    onValueChange = { onDraftChange(draft.copy(designation = it)) },
                    label = { Text(strings.designationLabel) },
                    singleLine = true,
                    enabled = !busy,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("staff_editor_designation"),
                )

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    listOf("Principal", "Teacher", "Assistant Teacher", "Office Staff").forEach { preset ->
                        FilterChip(
                            selected = draft.designation.equals(preset, ignoreCase = true),
                            onClick = { onDraftChange(draft.copy(designation = preset)) },
                            label = { Text(preset) },
                        )
                    }
                }

                OutlinedTextField(
                    value = draft.phone,
                    onValueChange = { onDraftChange(draft.copy(phone = it)) },
                    label = { Text(strings.phoneLabel) },
                    singleLine = true,
                    enabled = !busy,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("staff_editor_phone"),
                )

                OutlinedTextField(
                    value = draft.joiningDate,
                    onValueChange = { onDraftChange(draft.copy(joiningDate = it)) },
                    label = { Text("${strings.teachers.joiningDateLabel} (YYYY-MM-DD)") },
                    singleLine = true,
                    enabled = !busy,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("staff_editor_joining_date"),
                )

                if (profileOptions.isNotEmpty()) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = strings.teachers.selectProfileOptionalLabel,
                            style = MaterialTheme.typography.labelMedium,
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            FilterChip(
                                selected = draft.profileId.isBlank(),
                                onClick = { onDraftChange(draft.copy(profileId = "")) },
                                label = { Text(strings.notProvidedValue) },
                            )
                            profileOptions.take(12).forEach { opt ->
                                FilterChip(
                                    selected = draft.profileId == opt.id,
                                    onClick = { onDraftChange(draft.copy(profileId = opt.id)) },
                                    label = { Text("${opt.fullName} (${opt.role})") },
                                )
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = strings.teachers.staffActiveSwitchLabel,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f),
                    )
                    Switch(
                        checked = draft.isActive,
                        onCheckedChange = { onDraftChange(draft.copy(isActive = it)) },
                        enabled = !busy,
                        modifier = Modifier.testTag("staff_editor_active_switch"),
                    )
                }

                if (errorMessage != null) {
                    Text(
                        text = errorMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onSave,
                enabled = !busy,
                modifier = Modifier.testTag("save_staff_button"),
            ) {
                if (isSaving) {
                    CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(16.dp))
                } else {
                    Text(strings.teachers.saveStaffButton)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !busy) {
                Text(strings.cancel)
            }
        },
    )
}
