package com.example.erp.features.students

import com.example.erp.core.model.AuthSession
import com.example.erp.core.model.GuardianLinkItem
import com.example.erp.core.model.LinkedAccountProfile
import com.example.erp.core.model.ParentProfileOption
import com.example.erp.core.model.SchoolClassItem
import com.example.erp.core.model.StudentDraft
import com.example.erp.core.model.StudentRecord
import com.example.erp.core.model.StudentStatusFilter
import com.example.erp.core.model.UserRole
import com.example.erp.core.network.SupabaseClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

data class StudentsPage(
    val items: List<StudentRecord>,
    val totalCount: Int?,
    val hasMore: Boolean,
    val detectedColumns: Set<String>,
)

data class StudentDetailPayload(
    val student: StudentRecord,
    val guardians: List<GuardianLinkItem>,
    val linkedProfile: LinkedAccountProfile?,
)

data class UploadedPhotoResult(
    val storagePath: String,
    val authenticatedUrl: String,
)

class StudentsRepository(
    private val client: SupabaseClient,
) {
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun fetchClasses(session: AuthSession): Result<List<SchoolClassItem>> =
        withContext(Dispatchers.IO) {
            runCatching {
                val request = client.authenticatedRequestBuilder(
                    path = "/rest/v1/classes?select=*&order=class_name.asc",
                    accessToken = session.accessToken,
                )
                    .get()
                    .build()

                client.httpClient.newCall(request).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        error(extractRestError(body, response.code))
                    }
                    parseClassArray(JSONArray(body))
                }
            }
        }

    suspend fun fetchStudentsPage(
        session: AuthSession,
        classId: String? = null,
        statusFilter: StudentStatusFilter = StudentStatusFilter.ALL,
        query: String = "",
        offset: Int = 0,
        limit: Int = DEFAULT_PAGE_SIZE,
        allowedClassIds: Set<String> = emptySet(),
    ): Result<StudentsPage> = withContext(Dispatchers.IO) {
        runCatching {
            val role = session.user.role
            val safeOffset = offset.coerceAtLeast(0)
            val safeLimit = limit.coerceIn(1, 100)
            val params = mutableListOf(
                "select=*,classes(*)",
                "order=student_name.asc,id.asc",
            )

            when (role) {
                UserRole.STUDENT -> {
                    val linkedId = session.user.studentInfo?.studentId
                    if (!linkedId.isNullOrBlank()) {
                        params.add("or=(profile_id.eq.${encode(session.user.userId)},id.eq.${encode(linkedId)})")
                    } else {
                        params.add("profile_id=eq.${encode(session.user.userId)}")
                    }
                }
                UserRole.PARENT -> {
                    val wardIds = fetchGuardianStudentIds(session)
                    if (wardIds.isEmpty()) {
                        return@runCatching StudentsPage(
                            items = emptyList(),
                            totalCount = 0,
                            hasMore = false,
                            detectedColumns = StudentRecord.DEFAULT_CORE_COLUMNS,
                        )
                    }
                    val joined = wardIds.joinToString(",") { encode(it) }
                    params.add("id=in.($joined)")
                    if (!classId.isNullOrBlank()) {
                        params.add("class_id=eq.${encode(classId)}")
                    }
                }
                UserRole.TEACHER -> {
                    params.add("is_active=eq.true")
                    if (allowedClassIds.isNotEmpty()) {
                        if (!classId.isNullOrBlank() && classId in allowedClassIds) {
                            params.add("class_id=eq.${encode(classId)}")
                        } else {
                            val joined = allowedClassIds.joinToString(",") { encode(it) }
                            params.add("class_id=in.($joined)")
                        }
                    } else if (!classId.isNullOrBlank()) {
                        params.add("class_id=eq.${encode(classId)}")
                    }
                }
                UserRole.ADMIN -> {
                    if (!classId.isNullOrBlank()) {
                        params.add("class_id=eq.${encode(classId)}")
                    }
                    when (statusFilter) {
                        StudentStatusFilter.ALL -> Unit
                        StudentStatusFilter.ACTIVE -> params.add("is_active=eq.true")
                        StudentStatusFilter.INACTIVE -> params.add("is_active=eq.false")
                    }
                }
            }

            val cleanQuery = sanitizeSearchQuery(query)
            if (cleanQuery.isNotEmpty() && role != UserRole.STUDENT) {
                val pattern = encode("*$cleanQuery*")
                params.add("or=(student_name.ilike.$pattern,admission_no.ilike.$pattern,roll_no.ilike.$pattern)")
            }

            val path = "/rest/v1/students?${params.joinToString("&")}"
            val rangeEnd = safeOffset + safeLimit - 1
            val request = client.authenticatedRequestBuilder(
                path = path,
                accessToken = session.accessToken,
            )
                .header("Prefer", "count=exact")
                .header("Range", "$safeOffset-$rangeEnd")
                .get()
                .build()

            client.httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    error(extractRestError(body, response.code))
                }
                val parsed = parseStudentArray(JSONArray(body))
                val totalCount = parseContentRangeTotal(response.header("Content-Range"))
                val hasMore = when {
                    totalCount != null -> (safeOffset + parsed.first.size) < totalCount
                    else -> parsed.first.size >= safeLimit
                }
                StudentsPage(
                    items = parsed.first,
                    totalCount = totalCount ?: (safeOffset + parsed.first.size),
                    hasMore = hasMore,
                    detectedColumns = parsed.second,
                )
            }
        }
    }

    suspend fun fetchStudentDetail(
        session: AuthSession,
        student: StudentRecord,
    ): Result<StudentDetailPayload> = withContext(Dispatchers.IO) {
        runCatching {
            val role = session.user.role
            if (role == UserRole.STUDENT) {
                val ownStudentId = session.user.studentInfo?.studentId
                val authorized = student.profileId == session.user.userId ||
                    (ownStudentId != null && student.id == ownStudentId)
                require(authorized) { "Students can only view their own profile." }
            } else if (role == UserRole.PARENT) {
                val wardIds = fetchGuardianStudentIds(session)
                require(student.id in wardIds) { "Parents can only view linked ward profiles." }
            }

            val freshStudent = fetchSingleStudent(session, student.id) ?: student
            if (role == UserRole.TEACHER) {
                require(freshStudent.isActive) { "Teachers can only view active student profiles." }
                val assigned = session.user.staffInfo?.assignedClasses.orEmpty()
                if (assigned.isNotEmpty()) {
                    val normalizedAssigned = assigned.map { it.trim().lowercase() }.toSet()
                    val studentClass = freshStudent.className?.trim()?.lowercase()
                    require(studentClass != null && studentClass in normalizedAssigned) {
                        "Teachers can only view students in their assigned classes."
                    }
                }
            }

            val guardianRows = getJsonArray(
                path = "/rest/v1/student_guardians?student_id=eq.${encode(student.id)}&select=*",
                accessToken = session.accessToken,
            ) ?: JSONArray()

            val profileIdsToLookup = linkedSetOf<String>()
            freshStudent.profileId?.takeIf { it.isNotBlank() }?.let { profileIdsToLookup.add(it) }
            for (i in 0 until guardianRows.length()) {
                val row = guardianRows.getJSONObject(i)
                row.optNullableString("parent_profile_id")?.let { profileIdsToLookup.add(it) }
            }

            val profileMap = fetchProfilesByIds(session.accessToken, profileIdsToLookup)
            val linkedProfile = freshStudent.profileId?.let { profileMap[it] }

            val guardians = mutableListOf<GuardianLinkItem>()
            for (i in 0 until guardianRows.length()) {
                val row = guardianRows.getJSONObject(i)
                val parentId = row.optNullableString("parent_profile_id")
                val parentProfile = parentId?.let { profileMap[it] }
                guardians.add(
                    GuardianLinkItem(
                        id = row.optNullableString("id"),
                        studentId = row.optNullableString("student_id") ?: student.id,
                        parentProfileId = parentId,
                        parentName = parentProfile?.fullName
                            ?: row.optNullableString("guardian_name")
                            ?: row.optNullableString("parent_name"),
                        parentPhone = parentProfile?.phone
                            ?: row.optNullableString("guardian_phone")
                            ?: row.optNullableString("phone"),
                        relationship = row.optNullableString("relationship"),
                        isPrimary = row.optBoolean("is_primary", false),
                    ),
                )
            }

            StudentDetailPayload(
                student = freshStudent,
                guardians = guardians,
                linkedProfile = linkedProfile,
            )
        }
    }

    suspend fun fetchParentProfileOptions(session: AuthSession): Result<List<ParentProfileOption>> =
        withContext(Dispatchers.IO) {
            runCatching {
                require(session.user.role == UserRole.ADMIN) {
                    "Only Admin can browse parent login profiles."
                }
                val rows = getJsonArray(
                    path = "/rest/v1/profiles?role=eq.parent&is_active=eq.true&select=id,full_name,phone&order=full_name.asc",
                    accessToken = session.accessToken,
                ) ?: JSONArray()

                buildList {
                    for (i in 0 until rows.length()) {
                        val obj = rows.getJSONObject(i)
                        val id = obj.optNullableString("id") ?: continue
                        val name = obj.optNullableString("full_name") ?: "Parent"
                        add(
                            ParentProfileOption(
                                id = id,
                                fullName = name,
                                phone = obj.optNullableString("phone"),
                            ),
                        )
                    }
                }
            }
        }

    suspend fun createStudent(
        session: AuthSession,
        draft: StudentDraft,
        knownColumns: Set<String> = StudentRecord.DEFAULT_CORE_COLUMNS,
    ): Result<StudentRecord> = withContext(Dispatchers.IO) {
        runCatching {
            require(session.user.role == UserRole.ADMIN) {
                "Only Admin can add student records."
            }
            val payload = studentPayload(draft, knownColumns)
            executeWriteWithSchemaFallback(
                method = "POST",
                path = "/rest/v1/students?select=*,classes(*)",
                accessToken = session.accessToken,
                payload = payload,
            )
        }
    }

    suspend fun updateStudent(
        session: AuthSession,
        studentId: String,
        draft: StudentDraft,
        knownColumns: Set<String> = StudentRecord.DEFAULT_CORE_COLUMNS,
    ): Result<StudentRecord> = withContext(Dispatchers.IO) {
        runCatching {
            require(session.user.role == UserRole.ADMIN) {
                "Only Admin can edit student records."
            }
            val payload = studentPayload(draft, knownColumns)
            executeWriteWithSchemaFallback(
                method = "PATCH",
                path = "/rest/v1/students?id=eq.${encode(studentId)}&select=*,classes(*)",
                accessToken = session.accessToken,
                payload = payload,
            )
        }
    }

    suspend fun uploadStudentPhoto(
        session: AuthSession,
        studentKey: String,
        imageBytes: ByteArray,
        mimeType: String = "image/jpeg",
        fileExtension: String = "jpg",
        timestampMillis: Long = System.currentTimeMillis(),
    ): Result<UploadedPhotoResult> = withContext(Dispatchers.IO) {
        runCatching {
            require(session.user.role == UserRole.ADMIN) {
                "Only Admin can upload student photos."
            }
            require(imageBytes.isNotEmpty()) { "Selected image file is empty." }

            val cleanKey = studentKey.trim()
                .replace(Regex("[^a-zA-Z0-9_-]"), "_")
                .ifBlank { "student" }
            val cleanExt = fileExtension.trim().lowercase()
                .replace(Regex("[^a-z0-9]"), "")
                .ifBlank { "jpg" }
            val storagePath = "students/${cleanKey}_$timestampMillis.$cleanExt"
            val requestBody = imageBytes.toRequestBody(mimeType.toMediaType())

            val request = client.authenticatedRequestBuilder(
                path = "/storage/v1/object/school-files/$storagePath",
                accessToken = session.accessToken,
            )
                .header("x-upsert", "true")
                .header("Content-Type", mimeType)
                .post(requestBody)
                .build()

            client.httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    error(extractRestError(body, response.code))
                }
            }

            val resolvedUrl = client.resolveStorageUrl(storagePath)
                ?: error("Could not resolve authenticated storage URL.")
            UploadedPhotoResult(
                storagePath = storagePath,
                authenticatedUrl = resolvedUrl,
            )
        }
    }

    suspend fun linkGuardian(
        session: AuthSession,
        studentId: String,
        parentProfileId: String,
        relationship: String,
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            require(session.user.role == UserRole.ADMIN) {
                "Only Admin can link student guardians."
            }
            val payload = JSONObject().apply {
                put("student_id", studentId)
                put("parent_profile_id", parentProfileId)
                put("relationship", relationship.trim().ifEmpty { "Guardian" })
            }.toString()

            val request = client.authenticatedRequestBuilder(
                path = "/rest/v1/student_guardians",
                accessToken = session.accessToken,
            )
                .header("Prefer", "return=representation")
                .post(payload.toRequestBody(jsonMediaType))
                .build()

            client.httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    error(extractRestError(body, response.code))
                }
            }
        }
    }

    suspend fun unlinkGuardian(
        session: AuthSession,
        link: GuardianLinkItem,
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            require(session.user.role == UserRole.ADMIN) {
                "Only Admin can unlink student guardians."
            }
            val path = when {
                !link.id.isNullOrBlank() ->
                    "/rest/v1/student_guardians?id=eq.${encode(link.id)}"
                !link.parentProfileId.isNullOrBlank() ->
                    "/rest/v1/student_guardians?student_id=eq.${encode(link.studentId)}&parent_profile_id=eq.${encode(link.parentProfileId)}"
                else -> error("Guardian link identifier missing.")
            }
            val request = client.authenticatedRequestBuilder(
                path = path,
                accessToken = session.accessToken,
            )
                .delete()
                .build()

            client.httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    error(extractRestError(body, response.code))
                }
            }
        }
    }

    private fun executeWriteWithSchemaFallback(
        method: String,
        path: String,
        accessToken: String,
        payload: JSONObject,
    ): StudentRecord {
        val workingPayload = JSONObject(payload.toString())
        repeat(4) {
            val builder = client.authenticatedRequestBuilder(
                path = path,
                accessToken = accessToken,
            )
                .header("Prefer", "return=representation")
            val bodyObj = workingPayload.toString().toRequestBody(jsonMediaType)
            val request = if (method == "POST") {
                builder.post(bodyObj).build()
            } else {
                builder.patch(bodyObj).build()
            }

            client.httpClient.newCall(request).execute().use { response ->
                val rawBody = response.body?.string().orEmpty()
                if (response.isSuccessful) {
                    val parsed = parseStudentArray(JSONArray(rawBody))
                    return parsed.first.firstOrNull()
                        ?: error("Operation completed but no student row was returned (check RLS).")
                }
                val missingCol = extractMissingColumnName(rawBody)
                if (missingCol != null && workingPayload.has(missingCol)) {
                    workingPayload.remove(missingCol)
                } else {
                    error(extractRestError(rawBody, response.code))
                }
            }
        }
        error("Failed to save student record after schema fallback.")
    }

    private fun fetchSingleStudent(session: AuthSession, studentId: String): StudentRecord? {
        val rows = getJsonArray(
            path = "/rest/v1/students?id=eq.${encode(studentId)}&select=*,classes(*)&limit=1",
            accessToken = session.accessToken,
        ) ?: return null
        return parseStudentArray(rows).first.firstOrNull()
    }

    private fun fetchGuardianStudentIds(session: AuthSession): Set<String> {
        val ids = linkedSetOf<String>()
        session.user.linkedWards.forEach { ward ->
            if (ward.studentId.isNotBlank()) ids.add(ward.studentId)
        }
        val rows = getJsonArray(
            path = "/rest/v1/student_guardians?parent_profile_id=eq.${encode(session.user.userId)}&select=student_id",
            accessToken = session.accessToken,
        )
        if (rows != null) {
            for (i in 0 until rows.length()) {
                rows.getJSONObject(i).optNullableString("student_id")?.let { ids.add(it) }
            }
        }
        return ids
    }

    private fun fetchProfilesByIds(
        accessToken: String,
        profileIds: Set<String>,
    ): Map<String, LinkedAccountProfile> {
        if (profileIds.isEmpty()) return emptyMap()
        val joined = profileIds.joinToString(",") { encode(it) }
        val rows = getJsonArray(
            path = "/rest/v1/profiles?id=in.($joined)&select=id,full_name,phone,role,is_active",
            accessToken = accessToken,
        ) ?: return emptyMap()

        val result = mutableMapOf<String, LinkedAccountProfile>()
        for (i in 0 until rows.length()) {
            val p = rows.getJSONObject(i)
            val id = p.optNullableString("id") ?: continue
            result[id] = LinkedAccountProfile(
                id = id,
                fullName = p.optNullableString("full_name") ?: "",
                phone = p.optNullableString("phone"),
                role = p.optNullableString("role"),
                isActive = p.optBoolean("is_active", true),
            )
        }
        return result
    }

    private fun studentPayload(
        draft: StudentDraft,
        knownColumns: Set<String>,
    ): JSONObject = JSONObject().apply {
        put("student_name", draft.studentName.trim())
        put("admission_no", draft.admissionNo.trim().ifEmpty { JSONObject.NULL })
        put("roll_no", draft.rollNo.trim().ifEmpty { JSONObject.NULL })
        put("class_id", draft.classId.trim().ifEmpty { JSONObject.NULL })
        put("photo_url", draft.photoPath.trim().ifEmpty { JSONObject.NULL })
        put("is_active", draft.isActive)

        if ("date_of_birth" in knownColumns) {
            put("date_of_birth", draft.dateOfBirth.trim().ifEmpty { JSONObject.NULL })
        } else if ("dob" in knownColumns) {
            put("dob", draft.dateOfBirth.trim().ifEmpty { JSONObject.NULL })
        }
        if ("gender" in knownColumns) {
            put("gender", draft.gender.trim().ifEmpty { JSONObject.NULL })
        }
        if ("blood_group" in knownColumns) {
            put("blood_group", draft.bloodGroup.trim().ifEmpty { JSONObject.NULL })
        }
        if ("phone" in knownColumns) {
            put("phone", draft.phone.trim().ifEmpty { JSONObject.NULL })
        }
        if ("address" in knownColumns) {
            put("address", draft.address.trim().ifEmpty { JSONObject.NULL })
        }
        if ("guardian_name" in knownColumns) {
            put("guardian_name", draft.guardianName.trim().ifEmpty { JSONObject.NULL })
        }
        if ("guardian_phone" in knownColumns) {
            put("guardian_phone", draft.guardianPhone.trim().ifEmpty { JSONObject.NULL })
        }
    }

    private fun parseClassArray(array: JSONArray): List<SchoolClassItem> {
        val list = mutableListOf<SchoolClassItem>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val id = obj.optNullableString("id") ?: continue
            val name = obj.optNullableString("class_name")
                ?: obj.optNullableString("name")
                ?: continue
            list.add(
                SchoolClassItem(
                    id = id,
                    className = name,
                    section = obj.optNullableString("section"),
                    academicYear = obj.optNullableString("academic_year"),
                ),
            )
        }
        return list
    }

    private fun parseStudentArray(array: JSONArray): Pair<List<StudentRecord>, Set<String>> {
        val list = mutableListOf<StudentRecord>()
        val columns = linkedSetOf<String>().apply { addAll(StudentRecord.DEFAULT_CORE_COLUMNS) }

        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val id = obj.optNullableString("id") ?: continue

            val keys = obj.keys()
            val extra = linkedMapOf<String, String>()
            while (keys.hasNext()) {
                val key = keys.next()
                if (key != "classes") {
                    columns.add(key)
                }
                if (key !in HANDLED_STUDENT_KEYS) {
                    val value = obj.optNullableString(key)
                    if (value != null) {
                        extra[key] = value
                    }
                }
            }

            val clsObj = obj.optJSONObject("classes")
            val rawPhoto = obj.optNullableString("photo_url")
            list.add(
                StudentRecord(
                    id = id,
                    profileId = obj.optNullableString("profile_id"),
                    studentName = obj.optNullableString("student_name") ?: "",
                    admissionNo = obj.optNullableString("admission_no"),
                    rollNo = obj.optNullableString("roll_no"),
                    classId = obj.optNullableString("class_id"),
                    className = clsObj?.optNullableString("class_name") ?: clsObj?.optNullableString("name"),
                    classSection = clsObj?.optNullableString("section") ?: obj.optNullableString("section"),
                    academicYear = clsObj?.optNullableString("academic_year") ?: obj.optNullableString("academic_year"),
                    photoPath = rawPhoto,
                    photoUrl = client.resolveStorageUrl(rawPhoto),
                    isActive = obj.optBoolean("is_active", true),
                    dateOfBirth = obj.optNullableString("date_of_birth") ?: obj.optNullableString("dob"),
                    gender = obj.optNullableString("gender"),
                    bloodGroup = obj.optNullableString("blood_group"),
                    phone = obj.optNullableString("phone") ?: obj.optNullableString("mobile"),
                    email = obj.optNullableString("email"),
                    address = obj.optNullableString("address"),
                    admissionDate = obj.optNullableString("admission_date"),
                    fatherName = obj.optNullableString("father_name"),
                    motherName = obj.optNullableString("mother_name"),
                    guardianName = obj.optNullableString("guardian_name"),
                    guardianPhone = obj.optNullableString("guardian_phone"),
                    createdAt = obj.optString("created_at", ""),
                    extraFields = extra,
                    knownColumns = columns.toSet(),
                ),
            )
        }
        return list to columns.toSet()
    }

    private fun getJsonArray(path: String, accessToken: String): JSONArray? {
        val request = client.authenticatedRequestBuilder(path = path, accessToken = accessToken)
            .get()
            .build()
        return runCatching {
            client.httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val body = response.body?.string().orEmpty()
                if (body.isBlank()) null else JSONArray(body)
            }
        }.getOrNull()
    }

    private fun parseContentRangeTotal(contentRange: String?): Int? {
        if (contentRange.isNullOrBlank()) return null
        val totalPart = contentRange.substringAfter("/", "").trim()
        return if (totalPart == "*" || totalPart.isEmpty()) null else totalPart.toIntOrNull()
    }

    private fun sanitizeSearchQuery(raw: String): String =
        raw.trim().replace(Regex("[,()*\\\\]"), " ").trim()

    private fun extractMissingColumnName(rawBody: String): String? {
        return runCatching {
            val json = JSONObject(rawBody)
            val code = json.optString("code")
            val message = json.optString("message")
            if (code == "PGRST204" || message.contains("Could not find the", ignoreCase = true)) {
                Regex("'([^']+)' column").find(message)?.groupValues?.getOrNull(1)
            } else {
                null
            }
        }.getOrNull()
    }

    private fun JSONObject.optNullableString(key: String): String? {
        if (!has(key) || isNull(key)) return null
        val value = optString(key).trim()
        return value.takeIf { it.isNotEmpty() && it != "null" }
    }

    private fun extractRestError(rawBody: String, statusCode: Int): String {
        return runCatching {
            val json = JSONObject(rawBody)
            json.optString("message").takeIf { it.isNotBlank() }
                ?: json.optString("hint").takeIf { it.isNotBlank() }
                ?: json.optString("error").takeIf { it.isNotBlank() }
                ?: "Request failed (HTTP $statusCode)"
        }.getOrDefault("Request failed (HTTP $statusCode)")
    }

    private fun encode(value: String): String = URLEncoder.encode(value, "UTF-8")

    companion object {
        const val DEFAULT_PAGE_SIZE = 20

        private val HANDLED_STUDENT_KEYS = setOf(
            "id",
            "profile_id",
            "student_name",
            "admission_no",
            "roll_no",
            "class_id",
            "classes",
            "section",
            "academic_year",
            "photo_url",
            "is_active",
            "date_of_birth",
            "dob",
            "gender",
            "blood_group",
            "phone",
            "mobile",
            "email",
            "address",
            "admission_date",
            "father_name",
            "mother_name",
            "guardian_name",
            "guardian_phone",
            "created_at",
            "updated_at",
        )
    }
}
