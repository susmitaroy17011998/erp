package com.example.erp.core.model

data class LinkedStaffInfo(
    val staffId: String,
    val staffName: String,
    val designation: String,
    val phone: String?,
    val joiningDate: String?,
    val photoUrl: String?,
    val assignedClasses: List<String> = emptyList(),
)

data class LinkedStudentInfo(
    val studentId: String,
    val studentName: String,
    val admissionNo: String?,
    val rollNo: String?,
    val classId: String?,
    val className: String?,
    val photoUrl: String?,
    val relationship: String? = null,
)

data class DashboardSnapshot(
    val studentCount: Int? = null,
    val staffCount: Int? = null,
    val publishedNoticeCount: Int? = null,
    val holidayCount: Int? = null,
)

data class UserProfile(
    val userId: String,
    val email: String,
    val fullName: String,
    val role: UserRole,
    val phone: String? = null,
    val isActive: Boolean = true,
    val profileVerified: Boolean = false,
    val staffInfo: LinkedStaffInfo? = null,
    val studentInfo: LinkedStudentInfo? = null,
    val linkedWards: List<LinkedStudentInfo> = emptyList(),
)

data class AuthSession(
    val accessToken: String,
    val refreshToken: String,
    val expiresAtEpochSeconds: Long,
    val user: UserProfile,
)

sealed interface AuthUiState {
    data object Restoring : AuthUiState
    data object Unauthenticated : AuthUiState
    data object Loading : AuthUiState
    data class Authenticated(
        val session: AuthSession,
        val roleNotice: String? = null,
        val snapshot: DashboardSnapshot = DashboardSnapshot(),
        val isSyncingProfile: Boolean = false,
    ) : AuthUiState
}
