package com.example.erp.features.auth

import android.util.Patterns
import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.erp.core.config.SupabaseConfig
import com.example.erp.core.i18n.AppLanguage
import com.example.erp.core.i18n.stringsFor
import com.example.erp.core.model.AuthSession
import com.example.erp.core.model.AuthUiState
import com.example.erp.core.model.UserRole
import com.example.erp.core.network.InactiveAccountException
import com.example.erp.core.network.ProfileMissingException
import com.example.erp.core.network.SupabaseAuthService
import com.example.erp.core.security.SecureSessionStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

@Immutable
data class LoginFormState(
    val selectedRole: UserRole = UserRole.ADMIN,
    val email: String = "",
    val password: String = "",
    val passwordVisible: Boolean = false,
    val emailError: String? = null,
    val passwordError: String? = null,
    val authError: String? = null,
    val showResetDialog: Boolean = false,
    val resetEmail: String = "",
    val resetInProgress: Boolean = false,
    val resetFeedback: String? = null,
)

class AuthViewModel(
    val supabaseConfig: SupabaseConfig,
    private val sessionStore: SecureSessionStore,
    private val authService: SupabaseAuthService,
    private val onActiveTokenChanged: (String?) -> Unit,
) : ViewModel() {

    val language: StateFlow<AppLanguage> = sessionStore.languageFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = AppLanguage.ENGLISH,
    )

    private val _authState = MutableStateFlow<AuthUiState>(AuthUiState.Restoring)
    val authState: StateFlow<AuthUiState> = _authState.asStateFlow()

    private val _loginForm = MutableStateFlow(LoginFormState())
    val loginForm: StateFlow<LoginFormState> = _loginForm.asStateFlow()

    init {
        restoreSavedSession()
    }

    private fun restoreSavedSession() {
        viewModelScope.launch {
            val saved = sessionStore.readSession()
            if (saved == null) {
                onActiveTokenChanged(null)
                _authState.value = AuthUiState.Unauthenticated
                return@launch
            }

            val nowSeconds = System.currentTimeMillis() / 1000L
            if (saved.expiresAtEpochSeconds > nowSeconds + 60L) {
                onActiveTokenChanged(saved.accessToken)
                val hydrated = runCatching { authService.hydrateProfileAndRoleLinks(saved) }
                    .getOrElse { err ->
                        when (err) {
                            is InactiveAccountException -> {
                                onActiveTokenChanged(null)
                                sessionStore.clearSession()
                                _loginForm.update {
                                    it.copy(authError = stringsFor(language.value).accountInactiveError)
                                }
                                _authState.value = AuthUiState.Unauthenticated
                                return@launch
                            }
                            is ProfileMissingException -> {
                                onActiveTokenChanged(null)
                                sessionStore.clearSession()
                                _loginForm.update {
                                    it.copy(authError = stringsFor(language.value).profileMissingError)
                                }
                                _authState.value = AuthUiState.Unauthenticated
                                return@launch
                            }
                            else -> saved
                        }
                    }
                sessionStore.saveSession(hydrated)
                val snapshot = authService.fetchDashboardSnapshot(hydrated)
                _authState.value = AuthUiState.Authenticated(
                    session = hydrated,
                    snapshot = snapshot,
                )
                return@launch
            }

            if (saved.refreshToken.isNotBlank() && supabaseConfig.isConfigured) {
                val refreshed = authService.refreshSession(
                    refreshToken = saved.refreshToken,
                    fallbackRole = saved.user.role,
                )
                refreshed.fold(
                    onSuccess = { newSession ->
                        onActiveTokenChanged(newSession.accessToken)
                        sessionStore.saveSession(newSession)
                        val snapshot = authService.fetchDashboardSnapshot(newSession)
                        _authState.value = AuthUiState.Authenticated(
                            session = newSession,
                            snapshot = snapshot,
                        )
                    },
                    onFailure = { err ->
                        onActiveTokenChanged(null)
                        sessionStore.clearSession()
                        if (err is InactiveAccountException) {
                            _loginForm.update {
                                it.copy(authError = stringsFor(language.value).accountInactiveError)
                            }
                        }
                        _authState.value = AuthUiState.Unauthenticated
                    },
                )
            } else {
                onActiveTokenChanged(null)
                sessionStore.clearSession()
                _authState.value = AuthUiState.Unauthenticated
            }
        }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch {
            sessionStore.setLanguage(language)
        }
    }

    fun selectRole(role: UserRole) {
        _loginForm.update { it.copy(selectedRole = role, authError = null) }
    }

    fun updateEmail(email: String) {
        _loginForm.update { it.copy(email = email, emailError = null, authError = null) }
    }

    fun updatePassword(password: String) {
        _loginForm.update { it.copy(password = password, passwordError = null, authError = null) }
    }

    fun togglePasswordVisibility() {
        _loginForm.update { it.copy(passwordVisible = !it.passwordVisible) }
    }

    fun openResetDialog() {
        _loginForm.update {
            it.copy(
                showResetDialog = true,
                resetEmail = it.email,
                resetFeedback = null,
            )
        }
    }

    fun dismissResetDialog() {
        _loginForm.update {
            it.copy(
                showResetDialog = false,
                resetInProgress = false,
                resetFeedback = null,
            )
        }
    }

    fun updateResetEmail(email: String) {
        _loginForm.update { it.copy(resetEmail = email, resetFeedback = null) }
    }

    fun submitPasswordReset() {
        val strings = stringsFor(language.value)
        val email = _loginForm.value.resetEmail.trim()
        if (email.isEmpty()) {
            _loginForm.update { it.copy(resetFeedback = strings.validationEmailRequired) }
            return
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            _loginForm.update { it.copy(resetFeedback = strings.validationEmailInvalid) }
            return
        }

        viewModelScope.launch {
            _loginForm.update { it.copy(resetInProgress = true, resetFeedback = null) }
            val result = authService.sendPasswordReset(email)
            _loginForm.update {
                it.copy(
                    resetInProgress = false,
                    resetFeedback = result.fold(
                        onSuccess = { strings.resetLinkSent },
                        onFailure = { err -> err.message ?: "Unable to send recovery email." },
                    ),
                )
            }
        }
    }

    fun signIn() {
        val form = _loginForm.value
        val strings = stringsFor(language.value)

        val cleanEmail = form.email.trim()
        val emailError = when {
            cleanEmail.isEmpty() -> strings.validationEmailRequired
            !Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches() -> strings.validationEmailInvalid
            else -> null
        }
        val passwordError = when {
            form.password.isEmpty() -> strings.validationPasswordRequired
            form.password.length < 6 -> strings.validationPasswordShort
            else -> null
        }

        if (emailError != null || passwordError != null) {
            _loginForm.update {
                it.copy(emailError = emailError, passwordError = passwordError)
            }
            return
        }

        viewModelScope.launch {
            _authState.value = AuthUiState.Loading
            _loginForm.update { it.copy(authError = null) }

            val result = authService.signInWithPassword(
                email = cleanEmail,
                password = form.password,
                selectedRoleHint = form.selectedRole,
            )

            result.fold(
                onSuccess = { session ->
                    onActiveTokenChanged(session.accessToken)
                    sessionStore.saveSession(session)
                    val snapshot = authService.fetchDashboardSnapshot(session)
                    val mismatchNotice = if (session.user.role != form.selectedRole) {
                        strings.roleMismatchWarning.format(session.user.role.label(strings))
                    } else {
                        null
                    }
                    _loginForm.update { it.copy(password = "", authError = null) }
                    _authState.value = AuthUiState.Authenticated(
                        session = session,
                        roleNotice = mismatchNotice,
                        snapshot = snapshot,
                    )
                },
                onFailure = { error ->
                    onActiveTokenChanged(null)
                    val message = when (error) {
                        is InactiveAccountException -> strings.accountInactiveError
                        is ProfileMissingException -> strings.profileMissingError
                        else -> error.message ?: "Sign in failed."
                    }
                    _authState.value = AuthUiState.Unauthenticated
                    _loginForm.update { it.copy(authError = message) }
                },
            )
        }
    }

    fun syncProfileAndSnapshot() {
        val current = _authState.value as? AuthUiState.Authenticated ?: return
        viewModelScope.launch {
            _authState.value = current.copy(isSyncingProfile = true)
            val refreshedSession: AuthSession = runCatching {
                authService.hydrateProfileAndRoleLinks(current.session)
            }.getOrElse { err ->
                if (err is InactiveAccountException) {
                    onActiveTokenChanged(null)
                    sessionStore.clearSession()
                    _loginForm.update {
                        it.copy(authError = stringsFor(language.value).accountInactiveError)
                    }
                    _authState.value = AuthUiState.Unauthenticated
                    return@launch
                }
                current.session
            }

            sessionStore.saveSession(refreshedSession)
            val snapshot = authService.fetchDashboardSnapshot(refreshedSession)
            _authState.value = current.copy(
                session = refreshedSession,
                snapshot = snapshot,
                isSyncingProfile = false,
            )
        }
    }

    fun signOut() {
        val currentToken = (_authState.value as? AuthUiState.Authenticated)?.session?.accessToken
        viewModelScope.launch {
            if (!currentToken.isNullOrBlank()) {
                authService.signOut(currentToken)
            }
            onActiveTokenChanged(null)
            sessionStore.clearSession()
            _authState.value = AuthUiState.Unauthenticated
        }
    }

    class Factory(
        private val supabaseConfig: SupabaseConfig,
        private val sessionStore: SecureSessionStore,
        private val authService: SupabaseAuthService,
        private val onActiveTokenChanged: (String?) -> Unit,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return AuthViewModel(
                supabaseConfig = supabaseConfig,
                sessionStore = sessionStore,
                authService = authService,
                onActiveTokenChanged = onActiveTokenChanged,
            ) as T
        }
    }
}
