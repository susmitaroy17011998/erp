package com.example.erp.features.notices

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Campaign
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.EventAvailable
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.PublicOff
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import com.example.erp.core.i18n.AppLanguage
import com.example.erp.core.i18n.AppStrings
import com.example.erp.core.i18n.LocalAppLanguage
import com.example.erp.core.i18n.LocalAppStrings
import com.example.erp.core.model.AuthSession
import com.example.erp.core.model.HolidayDraft
import com.example.erp.core.model.HolidayItem
import com.example.erp.core.model.LoadableState
import com.example.erp.core.model.NoticeDraft
import com.example.erp.core.model.NoticeItem
import com.example.erp.core.model.NoticeStatusFilter
import com.example.erp.core.model.UserRole
import com.example.erp.ui.components.LanguageTogglePill
import com.example.erp.ui.components.LocalAuthenticatedImageLoader
import com.example.erp.ui.components.roleAccentColor
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LocalExtendedColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

private val DefaultNoticeCategories = listOf(
    "General",
    "Academic",
    "Exam",
    "Urgent",
    "Event",
    "Holiday",
)

private val DefaultHolidayTypes = listOf(
    "School Holiday",
    "Festival",
    "Vacation",
    "Exam Break",
)

@Composable
private fun localizedNoticeCategory(raw: String, strings: AppStrings): String =
    when (raw.trim().lowercase()) {
        "general" -> strings.catGeneral
        "academic" -> strings.catAcademic
        "exam" -> strings.catExam
        "urgent" -> strings.catUrgent
        "event" -> strings.catEvent
        "holiday" -> strings.catHoliday
        else -> raw
    }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoticesScreen(
    session: AuthSession,
    uiState: NoticesHolidaysUiState,
    viewModel: NoticesHolidaysViewModel,
    onLanguageSelected: (AppLanguage) -> Unit,
    onOpenHolidays: () -> Unit,
    onBack: () -> Unit,
) {
    val strings = LocalAppStrings.current
    val language = LocalAppLanguage.current
    val isAdmin = session.user.role == UserRole.ADMIN
    val accent = roleAccentColor(session.user.role)

    LaunchedEffect(session.user.userId) {
        viewModel.ensureLoaded(session)
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets.navigationBars,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                ),
                title = {
                    Column {
                        Text(
                            text = strings.modNotices,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            text = session.user.role.label(strings),
                            style = MaterialTheme.typography.labelSmall,
                            color = accent,
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("notices_back_button"),
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = strings.backToOverview,
                        )
                    }
                },
                actions = {
                    TextButton(
                        onClick = onOpenHolidays,
                        modifier = Modifier.testTag("switch_to_holidays_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.EventAvailable,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(strings.viewHolidaysAction)
                    }
                    IconButton(
                        onClick = { viewModel.refreshNotices(session) },
                        modifier = Modifier.testTag("notices_refresh_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = strings.refreshActionDesc,
                        )
                    }
                    LanguageTogglePill(
                        currentLanguage = language,
                        onLanguageSelected = onLanguageSelected,
                        modifier = Modifier.padding(end = 8.dp),
                    )
                },
            )
        },
        floatingActionButton = {
            if (isAdmin) {
                FloatingActionButton(
                    onClick = { viewModel.openCreateNotice(session) },
                    containerColor = accent,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("new_notice_fab"),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Add,
                        contentDescription = strings.newNoticeButton,
                    )
                }
            }
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter,
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 900.dp)
                    .fillMaxSize(),
            ) {
                // Search & Filters
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    OutlinedTextField(
                        value = uiState.noticeSearchQuery,
                        onValueChange = viewModel::updateNoticeSearch,
                        placeholder = { Text(strings.searchNoticesHint) },
                        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                        trailingIcon = {
                            if (uiState.noticeSearchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.updateNoticeSearch("") }) {
                                    Icon(Icons.Rounded.Close, contentDescription = strings.clearDate)
                                }
                            }
                        },
                        singleLine = true,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("notices_search_input"),
                    )

                    val categoriesFromData = (uiState.noticesState as? LoadableState.Success)
                        ?.items
                        ?.map { it.noticeType }
                        ?.distinct()
                        .orEmpty()
                    val allCategories = (DefaultNoticeCategories + categoriesFromData)
                        .distinctBy { it.lowercase() }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        FilterChip(
                            selected = uiState.selectedCategory == null,
                            onClick = { viewModel.selectCategory(null) },
                            label = { Text(strings.filterAll) },
                            modifier = Modifier.testTag("notice_cat_all"),
                        )
                        allCategories.forEach { cat ->
                            FilterChip(
                                selected = uiState.selectedCategory.equals(cat, ignoreCase = true),
                                onClick = {
                                    viewModel.selectCategory(
                                        if (uiState.selectedCategory.equals(cat, ignoreCase = true)) null else cat,
                                    )
                                },
                                label = { Text(localizedNoticeCategory(cat, strings)) },
                                modifier = Modifier.testTag("notice_cat_${cat.lowercase()}"),
                            )
                        }
                    }

                    if (isAdmin) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            listOf(
                                NoticeStatusFilter.ALL to strings.filterAll,
                                NoticeStatusFilter.PUBLISHED to strings.filterPublished,
                                NoticeStatusFilter.DRAFT to strings.filterDraft,
                                NoticeStatusFilter.EXPIRED to strings.filterExpired,
                            ).forEach { (status, label) ->
                                FilterChip(
                                    selected = uiState.selectedStatusFilter == status,
                                    onClick = { viewModel.selectStatusFilter(status) },
                                    label = { Text(label) },
                                    modifier = Modifier.testTag("notice_status_${status.name.lowercase()}"),
                                )
                            }
                        }
                    }

                    if (uiState.actionError != null) {
                        Surface(
                            shape = MaterialTheme.shapes.small,
                            color = MaterialTheme.colorScheme.errorContainer,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(
                                text = uiState.actionError,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.padding(12.dp),
                            )
                        }
                    }
                }

                when (val state = uiState.noticesState) {
                    LoadableState.Loading -> {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center,
                        ) {
                            CircularProgressIndicator()
                        }
                    }
                    is LoadableState.Error -> {
                        ErrorRetryBox(
                            message = state.message,
                            onRetry = { viewModel.refreshNotices(session) },
                        )
                    }
                    is LoadableState.Success -> {
                        val filtered = viewModel.filterNotices(
                            notices = state.items,
                            role = session.user.role,
                            query = uiState.noticeSearchQuery,
                            category = uiState.selectedCategory,
                            statusFilter = uiState.selectedStatusFilter,
                        )
                        if (filtered.isEmpty()) {
                            EmptyModuleState(
                                icon = Icons.Rounded.Campaign,
                                message = strings.noNoticesFound,
                            )
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                contentPadding = PaddingValues(
                                    start = 16.dp,
                                    end = 16.dp,
                                    bottom = if (isAdmin) 88.dp else 20.dp,
                                ),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                items(filtered, key = { it.id }) { notice ->
                                    NoticeCard(
                                        notice = notice,
                                        isExpired = viewModel.isNoticeExpired(notice),
                                        isAdmin = isAdmin,
                                        accent = accent,
                                        onClick = { viewModel.openNoticeDetail(notice) },
                                        onTogglePublish = { viewModel.toggleNoticePublish(session, notice) },
                                        onEdit = { viewModel.openEditNotice(session, notice) },
                                        onDelete = { viewModel.requestDeleteNotice(session, notice) },
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    uiState.selectedNoticeDetail?.let { detail ->
        NoticeDetailBottomSheet(
            notice = detail,
            isExpired = viewModel.isNoticeExpired(detail),
            isAdmin = isAdmin,
            isSaving = uiState.isSaving,
            accent = accent,
            onDismiss = viewModel::closeNoticeDetail,
            onTogglePublish = { viewModel.toggleNoticePublish(session, detail) },
            onEdit = { viewModel.openEditNotice(session, detail) },
            onDelete = { viewModel.requestDeleteNotice(session, detail) },
        )
    }

    uiState.editingNoticeDraft?.let { draft ->
        NoticeEditorDialog(
            draft = draft,
            isSaving = uiState.isSaving,
            errorMessage = uiState.formError,
            onDraftChange = { updated -> viewModel.updateNoticeDraft { updated } },
            onDismiss = viewModel::dismissNoticeEditor,
            onSave = { viewModel.saveNoticeDraft(session, strings.titleRequiredError) },
        )
    }

    uiState.pendingDeleteNotice?.let { target ->
        AlertDialog(
            onDismissRequest = { if (!uiState.isSaving) viewModel.dismissDeleteNotice() },
            title = { Text(strings.deleteNoticeConfirmTitle) },
            text = { Text("${target.title}\n\n${strings.deleteNoticeConfirmBody}") },
            confirmButton = {
                Button(
                    onClick = { viewModel.confirmDeleteNotice(session) },
                    enabled = !uiState.isSaving,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                    ),
                ) {
                    Text(strings.deleteButton)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = viewModel::dismissDeleteNotice,
                    enabled = !uiState.isSaving,
                ) {
                    Text(strings.cancel)
                }
            },
        )
    }
}

@Composable
private fun NoticeCard(
    notice: NoticeItem,
    isExpired: Boolean,
    isAdmin: Boolean,
    accent: Color,
    onClick: () -> Unit,
    onTogglePublish: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    val strings = LocalAppStrings.current
    val extended = LocalExtendedColors.current
    val imageLoader = LocalAuthenticatedImageLoader.current

    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)),
        tonalElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .testTag("notice_card_${notice.id}"),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = accent.copy(alpha = 0.14f),
                ) {
                    Text(
                        text = localizedNoticeCategory(notice.noticeType, strings),
                        style = MaterialTheme.typography.labelSmall,
                        color = accent,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    )
                }

                if (isAdmin) {
                    val (statusText, statusBg, statusFg) = when {
                        isExpired -> Triple(
                            strings.statusExpiredBadge,
                            extended.warningContainer,
                            extended.warning,
                        )
                        notice.isPublished -> Triple(
                            strings.statusPublishedBadge,
                            extended.successContainer,
                            extended.success,
                        )
                        else -> Triple(
                            strings.statusDraftBadge,
                            MaterialTheme.colorScheme.surfaceContainerHigh,
                            MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Surface(shape = RoundedCornerShape(50), color = statusBg) {
                        Text(
                            text = statusText,
                            style = MaterialTheme.typography.labelSmall,
                            color = statusFg,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        )
                    }
                }
            }

            if (!notice.thumbnailUrl.isNullOrBlank() && imageLoader != null) {
                SubcomposeAsyncImage(
                    model = notice.thumbnailUrl,
                    imageLoader = imageLoader,
                    contentDescription = notice.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clip(MaterialTheme.shapes.small),
                )
            }

            Text(
                text = notice.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
            )

            if (!notice.body.isNullOrBlank()) {
                Text(
                    text = notice.body,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                notice.publishDate?.let { pub ->
                    Text(
                        text = "${strings.publishedOnLabel}: $pub",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                notice.expiryDate?.let { exp ->
                    Text(
                        text = "${strings.expiresOnLabel}: $exp",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                        color = if (isExpired) extended.warning else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            if (isAdmin) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    TextButton(
                        onClick = onTogglePublish,
                        modifier = Modifier.testTag("toggle_publish_${notice.id}"),
                    ) {
                        Icon(
                            imageVector = if (notice.isPublished) Icons.Rounded.PublicOff else Icons.Rounded.Public,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (notice.isPublished) strings.unpublishButton else strings.publishButton)
                    }
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.testTag("edit_notice_${notice.id}"),
                    ) {
                        Icon(Icons.Rounded.Edit, contentDescription = strings.editButton)
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.testTag("delete_notice_${notice.id}"),
                    ) {
                        Icon(
                            Icons.Rounded.Delete,
                            contentDescription = strings.deleteButton,
                            tint = MaterialTheme.colorScheme.error,
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NoticeDetailBottomSheet(
    notice: NoticeItem,
    isExpired: Boolean,
    isAdmin: Boolean,
    isSaving: Boolean,
    accent: Color,
    onDismiss: () -> Unit,
    onTogglePublish: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    val strings = LocalAppStrings.current
    val imageLoader = LocalAuthenticatedImageLoader.current
    val extended = LocalExtendedColors.current

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Surface(shape = RoundedCornerShape(50), color = accent.copy(alpha = 0.14f)) {
                    Text(
                        text = localizedNoticeCategory(notice.noticeType, strings),
                        style = MaterialTheme.typography.labelMedium,
                        color = accent,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                    )
                }
                if (isExpired) {
                    Surface(shape = RoundedCornerShape(50), color = extended.warningContainer) {
                        Text(
                            text = strings.statusExpiredBadge,
                            style = MaterialTheme.typography.labelMedium,
                            color = extended.warning,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                        )
                    }
                }
            }

            Text(
                text = notice.title,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
            )

            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                notice.publishDate?.let {
                    Text(
                        text = "${strings.publishedOnLabel}: $it",
                        style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFamily),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                notice.expiryDate?.let {
                    Text(
                        text = "${strings.expiresOnLabel}: $it",
                        style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFamily),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            if (!notice.thumbnailUrl.isNullOrBlank() && imageLoader != null) {
                SubcomposeAsyncImage(
                    model = notice.thumbnailUrl,
                    imageLoader = imageLoader,
                    contentDescription = notice.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(190.dp)
                        .clip(MaterialTheme.shapes.medium),
                )
            }

            if (!notice.body.isNullOrBlank()) {
                Text(
                    text = notice.body,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                )
            }

            if (isAdmin) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    OutlinedButton(
                        onClick = onTogglePublish,
                        enabled = !isSaving,
                        modifier = Modifier.weight(1f),
                    ) {
                        Text(if (notice.isPublished) strings.unpublishButton else strings.publishButton)
                    }
                    Button(
                        onClick = onEdit,
                        enabled = !isSaving,
                        modifier = Modifier.weight(1f),
                    ) {
                        Text(strings.editButton)
                    }
                }
                TextButton(
                    onClick = onDelete,
                    enabled = !isSaving,
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.align(Alignment.End),
                ) {
                    Icon(Icons.Rounded.Delete, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(strings.deleteButton)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun NoticeEditorDialog(
    draft: NoticeDraft,
    isSaving: Boolean,
    errorMessage: String?,
    onDraftChange: (NoticeDraft) -> Unit,
    onDismiss: () -> Unit,
    onSave: () -> Unit,
) {
    val strings = LocalAppStrings.current
    var pickingPublishDate by remember { mutableStateOf(false) }
    var pickingExpiryDate by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = { if (!isSaving) onDismiss() },
        title = {
            Text(if (draft.id == null) strings.createNoticeTitle else strings.editNoticeTitle)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                OutlinedTextField(
                    value = draft.title,
                    onValueChange = { onDraftChange(draft.copy(title = it)) },
                    label = { Text(strings.noticeTitleLabel) },
                    singleLine = true,
                    enabled = !isSaving,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("notice_editor_title"),
                )

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = strings.noticeCategoryLabel,
                        style = MaterialTheme.typography.labelMedium,
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        DefaultNoticeCategories.forEach { cat ->
                            FilterChip(
                                selected = draft.noticeType.equals(cat, ignoreCase = true),
                                onClick = { onDraftChange(draft.copy(noticeType = cat)) },
                                label = { Text(localizedNoticeCategory(cat, strings)) },
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = draft.body,
                    onValueChange = { onDraftChange(draft.copy(body = it)) },
                    label = { Text(strings.noticeBodyLabel) },
                    minLines = 3,
                    maxLines = 6,
                    enabled = !isSaving,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("notice_editor_body"),
                )

                DateFieldRow(
                    label = strings.publishDateLabel,
                    value = draft.publishDate,
                    onPickClick = { pickingPublishDate = true },
                    onClearClick = { onDraftChange(draft.copy(publishDate = "")) },
                )

                DateFieldRow(
                    label = strings.expiryDateLabel,
                    value = draft.expiryDate,
                    onPickClick = { pickingExpiryDate = true },
                    onClearClick = { onDraftChange(draft.copy(expiryDate = "")) },
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = strings.publishImmediatelyLabel,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f),
                    )
                    Switch(
                        checked = draft.isPublished,
                        onCheckedChange = { onDraftChange(draft.copy(isPublished = it)) },
                        enabled = !isSaving,
                        modifier = Modifier.testTag("notice_editor_publish_switch"),
                    )
                }

                if (errorMessage != null) {
                    Text(
                        text = errorMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onSave,
                enabled = !isSaving,
                modifier = Modifier.testTag("save_notice_button"),
            ) {
                if (isSaving) {
                    CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(16.dp))
                } else {
                    Text(strings.saveNoticeButton)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !isSaving) {
                Text(strings.cancel)
            }
        },
    )

    if (pickingPublishDate) {
        IsoDatePickerDialog(
            onDateSelected = { iso ->
                onDraftChange(draft.copy(publishDate = iso))
                pickingPublishDate = false
            },
            onDismiss = { pickingPublishDate = false },
        )
    }

    if (pickingExpiryDate) {
        IsoDatePickerDialog(
            onDateSelected = { iso ->
                onDraftChange(draft.copy(expiryDate = iso))
                pickingExpiryDate = false
            },
            onDismiss = { pickingExpiryDate = false },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HolidaysScreen(
    session: AuthSession,
    uiState: NoticesHolidaysUiState,
    viewModel: NoticesHolidaysViewModel,
    onLanguageSelected: (AppLanguage) -> Unit,
    onOpenNotices: () -> Unit,
    onBack: () -> Unit,
) {
    val strings = LocalAppStrings.current
    val language = LocalAppLanguage.current
    val isAdmin = session.user.role == UserRole.ADMIN
    val accent = roleAccentColor(session.user.role)

    LaunchedEffect(session.user.userId) {
        viewModel.ensureLoaded(session)
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets.navigationBars,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                ),
                title = {
                    Column {
                        Text(
                            text = strings.modHolidays,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            text = session.user.role.label(strings),
                            style = MaterialTheme.typography.labelSmall,
                            color = accent,
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("holidays_back_button"),
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = strings.backToOverview,
                        )
                    }
                },
                actions = {
                    TextButton(
                        onClick = onOpenNotices,
                        modifier = Modifier.testTag("switch_to_notices_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Campaign,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(strings.viewNoticesAction)
                    }
                    IconButton(
                        onClick = { viewModel.refreshHolidays(session) },
                        modifier = Modifier.testTag("holidays_refresh_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = strings.refreshActionDesc,
                        )
                    }
                    LanguageTogglePill(
                        currentLanguage = language,
                        onLanguageSelected = onLanguageSelected,
                        modifier = Modifier.padding(end = 8.dp),
                    )
                },
            )
        },
        floatingActionButton = {
            if (isAdmin) {
                FloatingActionButton(
                    onClick = { viewModel.openCreateHoliday(session) },
                    containerColor = accent,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("new_holiday_fab"),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Add,
                        contentDescription = strings.newHolidayButton,
                    )
                }
            }
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter,
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 900.dp)
                    .fillMaxSize(),
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    OutlinedTextField(
                        value = uiState.holidaySearchQuery,
                        onValueChange = viewModel::updateHolidaySearch,
                        placeholder = { Text(strings.searchHolidaysHint) },
                        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                        trailingIcon = {
                            if (uiState.holidaySearchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.updateHolidaySearch("") }) {
                                    Icon(Icons.Rounded.Close, contentDescription = strings.clearDate)
                                }
                            }
                        },
                        singleLine = true,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("holidays_search_input"),
                    )

                    val typesFromData = (uiState.holidaysState as? LoadableState.Success)
                        ?.items
                        ?.map { it.holidayType }
                        ?.distinct()
                        .orEmpty()
                    val allTypes = (DefaultHolidayTypes + typesFromData).distinctBy { it.lowercase() }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        FilterChip(
                            selected = uiState.selectedHolidayType == null,
                            onClick = { viewModel.selectHolidayType(null) },
                            label = { Text(strings.filterAll) },
                        )
                        allTypes.forEach { type ->
                            FilterChip(
                                selected = uiState.selectedHolidayType.equals(type, ignoreCase = true),
                                onClick = {
                                    viewModel.selectHolidayType(
                                        if (uiState.selectedHolidayType.equals(type, ignoreCase = true)) null else type,
                                    )
                                },
                                label = { Text(type) },
                            )
                        }
                    }

                    if (uiState.actionError != null) {
                        Surface(
                            shape = MaterialTheme.shapes.small,
                            color = MaterialTheme.colorScheme.errorContainer,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(
                                text = uiState.actionError,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.padding(12.dp),
                            )
                        }
                    }
                }

                when (val state = uiState.holidaysState) {
                    LoadableState.Loading -> {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center,
                        ) {
                            CircularProgressIndicator()
                        }
                    }
                    is LoadableState.Error -> {
                        ErrorRetryBox(
                            message = state.message,
                            onRetry = { viewModel.refreshHolidays(session) },
                        )
                    }
                    is LoadableState.Success -> {
                        val filtered = viewModel.filterHolidays(
                            holidays = state.items,
                            query = uiState.holidaySearchQuery,
                            holidayType = uiState.selectedHolidayType,
                        )
                        if (filtered.isEmpty()) {
                            EmptyModuleState(
                                icon = Icons.Rounded.EventAvailable,
                                message = strings.noHolidaysFound,
                            )
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                contentPadding = PaddingValues(
                                    start = 16.dp,
                                    end = 16.dp,
                                    bottom = if (isAdmin) 88.dp else 20.dp,
                                ),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                items(filtered, key = { it.id }) { holiday ->
                                    HolidayCard(
                                        holiday = holiday,
                                        isAdmin = isAdmin,
                                        accent = accent,
                                        onEdit = { viewModel.openEditHoliday(session, holiday) },
                                        onDelete = { viewModel.requestDeleteHoliday(session, holiday) },
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    uiState.editingHolidayDraft?.let { draft ->
        HolidayEditorDialog(
            draft = draft,
            isSaving = uiState.isSaving,
            errorMessage = uiState.formError,
            onDraftChange = { updated -> viewModel.updateHolidayDraft { updated } },
            onDismiss = viewModel::dismissHolidayEditor,
            onSave = {
                viewModel.saveHolidayDraft(
                    session = session,
                    nameRequiredMsg = strings.titleRequiredError,
                    dateRequiredMsg = strings.dateRequiredError,
                )
            },
        )
    }

    uiState.pendingDeleteHoliday?.let { target ->
        AlertDialog(
            onDismissRequest = { if (!uiState.isSaving) viewModel.dismissDeleteHoliday() },
            title = { Text(strings.deleteHolidayConfirmTitle) },
            text = { Text("${target.holidayName}\n\n${strings.deleteHolidayConfirmBody}") },
            confirmButton = {
                Button(
                    onClick = { viewModel.confirmDeleteHoliday(session) },
                    enabled = !uiState.isSaving,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                ) {
                    Text(strings.deleteButton)
                }
            },
            dismissButton = {
                TextButton(onClick = viewModel::dismissDeleteHoliday, enabled = !uiState.isSaving) {
                    Text(strings.cancel)
                }
            },
        )
    }
}

@Composable
private fun HolidayCard(
    holiday: HolidayItem,
    isAdmin: Boolean,
    accent: Color,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    val strings = LocalAppStrings.current
    val extended = LocalExtendedColors.current
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)),
        tonalElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("holiday_card_${holiday.id}"),
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Surface(
                shape = MaterialTheme.shapes.small,
                color = accent.copy(alpha = 0.13f),
                modifier = Modifier.size(58.dp),
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.CalendarMonth,
                        contentDescription = null,
                        tint = accent,
                        modifier = Modifier.size(18.dp),
                    )
                    Text(
                        text = holiday.holidayDate.takeLast(5),
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                        color = accent,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = holiday.holidayName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f),
                    )
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    ) {
                        Text(
                            text = holiday.holidayType,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        )
                    }
                }

                val dateRange = if (!holiday.endDate.isNullOrBlank() && holiday.endDate != holiday.holidayDate) {
                    "${holiday.holidayDate} → ${holiday.endDate}"
                } else {
                    holiday.holidayDate
                }
                Text(
                    text = dateRange,
                    style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFamily),
                    color = accent,
                )

                if (!holiday.description.isNullOrBlank()) {
                    Text(
                        text = holiday.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }

                holiday.schoolReopenDate?.let { reopen ->
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = extended.successContainer,
                    ) {
                        Text(
                            text = "${strings.reopenPrefix}: $reopen",
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                            color = extended.success,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        )
                    }
                }

                if (isAdmin) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                    ) {
                        IconButton(onClick = onEdit, modifier = Modifier.testTag("edit_holiday_${holiday.id}")) {
                            Icon(Icons.Rounded.Edit, contentDescription = strings.editButton)
                        }
                        IconButton(onClick = onDelete, modifier = Modifier.testTag("delete_holiday_${holiday.id}")) {
                            Icon(
                                Icons.Rounded.Delete,
                                contentDescription = strings.deleteButton,
                                tint = MaterialTheme.colorScheme.error,
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun HolidayEditorDialog(
    draft: HolidayDraft,
    isSaving: Boolean,
    errorMessage: String?,
    onDraftChange: (HolidayDraft) -> Unit,
    onDismiss: () -> Unit,
    onSave: () -> Unit,
) {
    val strings = LocalAppStrings.current
    var pickingStart by remember { mutableStateOf(false) }
    var pickingEnd by remember { mutableStateOf(false) }
    var pickingReopen by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = { if (!isSaving) onDismiss() },
        title = {
            Text(if (draft.id == null) strings.createHolidayTitle else strings.editHolidayTitle)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                OutlinedTextField(
                    value = draft.holidayName,
                    onValueChange = { onDraftChange(draft.copy(holidayName = it)) },
                    label = { Text(strings.holidayNameLabel) },
                    singleLine = true,
                    enabled = !isSaving,
                    modifier = Modifier.fillMaxWidth(),
                )

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text = strings.holidayTypeLabel, style = MaterialTheme.typography.labelMedium)
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        DefaultHolidayTypes.forEach { type ->
                            FilterChip(
                                selected = draft.holidayType.equals(type, ignoreCase = true),
                                onClick = { onDraftChange(draft.copy(holidayType = type)) },
                                label = { Text(type) },
                            )
                        }
                    }
                }

                DateFieldRow(
                    label = strings.holidayStartDateLabel,
                    value = draft.holidayDate,
                    onPickClick = { pickingStart = true },
                    onClearClick = { onDraftChange(draft.copy(holidayDate = "")) },
                )

                DateFieldRow(
                    label = strings.holidayEndDateLabel,
                    value = draft.endDate,
                    onPickClick = { pickingEnd = true },
                    onClearClick = { onDraftChange(draft.copy(endDate = "")) },
                )

                DateFieldRow(
                    label = strings.schoolReopenDateLabel,
                    value = draft.schoolReopenDate,
                    onPickClick = { pickingReopen = true },
                    onClearClick = { onDraftChange(draft.copy(schoolReopenDate = "")) },
                )

                OutlinedTextField(
                    value = draft.description,
                    onValueChange = { onDraftChange(draft.copy(description = it)) },
                    label = { Text(strings.holidayDescriptionLabel) },
                    minLines = 2,
                    maxLines = 4,
                    enabled = !isSaving,
                    modifier = Modifier.fillMaxWidth(),
                )

                if (errorMessage != null) {
                    Text(
                        text = errorMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = onSave, enabled = !isSaving) {
                if (isSaving) {
                    CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(16.dp))
                } else {
                    Text(strings.saveHolidayButton)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !isSaving) {
                Text(strings.cancel)
            }
        },
    )

    if (pickingStart) {
        IsoDatePickerDialog(
            onDateSelected = {
                onDraftChange(draft.copy(holidayDate = it))
                pickingStart = false
            },
            onDismiss = { pickingStart = false },
        )
    }
    if (pickingEnd) {
        IsoDatePickerDialog(
            onDateSelected = {
                onDraftChange(draft.copy(endDate = it))
                pickingEnd = false
            },
            onDismiss = { pickingEnd = false },
        )
    }
    if (pickingReopen) {
        IsoDatePickerDialog(
            onDateSelected = {
                onDraftChange(draft.copy(schoolReopenDate = it))
                pickingReopen = false
            },
            onDismiss = { pickingReopen = false },
        )
    }
}

@Composable
private fun DateFieldRow(
    label: String,
    value: String,
    onPickClick: () -> Unit,
    onClearClick: () -> Unit,
) {
    val strings = LocalAppStrings.current
    Surface(
        shape = MaterialTheme.shapes.small,
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .defaultMinSize(minHeight = 48.dp)
                .clickable(onClick = onPickClick)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    text = value.ifBlank { strings.pickDate },
                    style = MaterialTheme.typography.bodyMedium.copy(fontFamily = JetBrainsMonoFamily),
                    color = if (value.isBlank()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                )
            }
            if (value.isNotBlank()) {
                IconButton(onClick = onClearClick) {
                    Icon(Icons.Rounded.Close, contentDescription = strings.clearDate)
                }
            } else {
                Icon(Icons.Rounded.CalendarMonth, contentDescription = strings.pickDate, tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun IsoDatePickerDialog(
    onDateSelected: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val strings = LocalAppStrings.current
    val pickerState = rememberDatePickerState()
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(
                onClick = {
                    val millis = pickerState.selectedDateMillis
                    if (millis != null) {
                        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
                            timeZone = TimeZone.getTimeZone("UTC")
                        }
                        onDateSelected(fmt.format(Date(millis)))
                    } else {
                        onDismiss()
                    }
                },
            ) {
                Text(strings.pickDate)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(strings.cancel)
            }
        },
    ) {
        DatePicker(state = pickerState)
    }
}

@Composable
private fun ErrorRetryBox(
    message: String,
    onRetry: () -> Unit,
) {
    val strings = LocalAppStrings.current
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.error,
            )
            Button(onClick = onRetry) {
                Text(strings.retryButton)
            }
        }
    }
}

@Composable
private fun EmptyModuleState(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    message: String,
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(44.dp),
            )
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
