package com.example.erp.features.students

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Badge
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FamilyRestroom
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.erp.core.i18n.AppStrings
import com.example.erp.core.i18n.LocalAppStrings
import com.example.erp.core.model.AuthSession
import com.example.erp.core.model.GuardianLinkItem
import com.example.erp.core.model.LinkedAccountProfile
import com.example.erp.core.model.LoadableState
import com.example.erp.core.model.ParentProfileOption
import com.example.erp.core.model.StudentRecord
import com.example.erp.core.model.UserRole
import com.example.erp.ui.components.AuthenticatedAvatar
import com.example.erp.ui.components.roleAccentColor
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LocalExtendedColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentProfileContent(
    session: AuthSession,
    student: StudentRecord,
    detailState: LoadableState<StudentDetailPayload>?,
    parentOptions: List<ParentProfileOption>,
    showLinkGuardianDialog: Boolean,
    isMutatingGuardian: Boolean,
    actionError: String?,
    showTopBar: Boolean,
    onBack: () -> Unit,
    onRefresh: () -> Unit,
    onEdit: () -> Unit,
    onOpenLinkGuardian: () -> Unit,
    onDismissLinkGuardian: () -> Unit,
    onConfirmLinkGuardian: (parentProfileId: String, relationship: String) -> Unit,
    onUnlinkGuardian: (GuardianLinkItem) -> Unit,
) {
    val strings = LocalAppStrings.current
    val isAdmin = session.user.role == UserRole.ADMIN
    val accent = roleAccentColor(session.user.role)
    var selectedSectionTab by rememberSaveable(student.id) { mutableIntStateOf(0) }

    val resolvedPayload = (detailState as? LoadableState.Success)?.items
    val displayStudent = resolvedPayload?.student ?: student
    val guardians = resolvedPayload?.guardians.orEmpty()
    val linkedProfile = resolvedPayload?.linkedProfile

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets.navigationBars,
        topBar = {
            if (showTopBar) {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                    ),
                    title = {
                        Column {
                            Text(
                                text = displayStudent.studentName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                text = displayStudent.admissionNo ?: displayStudent.id.take(8),
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                                color = accent,
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.testTag("student_profile_back_button"),
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = strings.backToOverview,
                            )
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = onRefresh,
                            modifier = Modifier.testTag("student_profile_refresh_button"),
                        ) {
                            Icon(Icons.Rounded.Refresh, contentDescription = strings.refreshActionDesc)
                        }
                        if (isAdmin) {
                            IconButton(
                                onClick = onEdit,
                                modifier = Modifier.testTag("student_profile_edit_button"),
                            ) {
                                Icon(Icons.Rounded.Edit, contentDescription = strings.editButton)
                            }
                        }
                    },
                )
            }
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter,
        ) {
            LazyColumn(
                modifier = Modifier
                    .widthIn(max = 820.dp)
                    .fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                item {
                    StudentHeroCard(
                        student = displayStudent,
                        accent = accent,
                        isAdmin = isAdmin,
                        onEdit = onEdit,
                    )
                }

                if (actionError != null) {
                    item {
                        Surface(
                            shape = MaterialTheme.shapes.small,
                            color = MaterialTheme.colorScheme.errorContainer,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(
                                text = actionError,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.padding(12.dp),
                            )
                        }
                    }
                }

                item {
                    val tabs = listOf(
                        strings.personalDetailsTab,
                        strings.academicDetailsTab,
                        strings.guardianDetailsTab,
                    )
                    PrimaryTabRow(selectedTabIndex = selectedSectionTab) {
                        tabs.forEachIndexed { index, title ->
                            Tab(
                                selected = selectedSectionTab == index,
                                onClick = { selectedSectionTab = index },
                                text = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                modifier = Modifier.testTag("student_profile_tab_$index"),
                            )
                        }
                    }
                }

                if (detailState is LoadableState.Loading) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        }
                    }
                } else if (detailState is LoadableState.Error) {
                    item {
                        Surface(
                            shape = MaterialTheme.shapes.small,
                            color = MaterialTheme.colorScheme.errorContainer,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Text(
                                    text = detailState.message,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    modifier = Modifier.weight(1f),
                                )
                                TextButton(onClick = onRefresh) {
                                    Text(strings.retryButton)
                                }
                            }
                        }
                    }
                }

                when (selectedSectionTab) {
                    0 -> item {
                        PersonalDetailsCard(
                            student = displayStudent,
                            linkedProfile = linkedProfile,
                            strings = strings,
                        )
                    }
                    1 -> item {
                        AcademicDetailsCard(
                            student = displayStudent,
                            strings = strings,
                        )
                    }
                    else -> item {
                        GuardianDetailsCard(
                            student = displayStudent,
                            guardians = guardians,
                            isAdmin = isAdmin,
                            isMutating = isMutatingGuardian,
                            accent = accent,
                            strings = strings,
                            onOpenLinkGuardian = onOpenLinkGuardian,
                            onUnlinkGuardian = onUnlinkGuardian,
                        )
                    }
                }
            }
        }
    }

    if (showLinkGuardianDialog && isAdmin) {
        LinkGuardianDialog(
            parentOptions = parentOptions,
            isSaving = isMutatingGuardian,
            onDismiss = onDismissLinkGuardian,
            onLink = onConfirmLinkGuardian,
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun StudentHeroCard(
    student: StudentRecord,
    accent: Color,
    isAdmin: Boolean,
    onEdit: () -> Unit,
) {
    val strings = LocalAppStrings.current
    val extended = LocalExtendedColors.current

    Surface(
        shape = MaterialTheme.shapes.large,
        color = Color.Transparent,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Box(
            modifier = Modifier
                .background(
                    Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.82f))),
                    shape = MaterialTheme.shapes.large,
                )
                .padding(18.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    AuthenticatedAvatar(
                        photoUrl = student.photoUrl,
                        contentDescription = student.studentName,
                        accentColor = Color.White,
                        fallbackIcon = Icons.Rounded.Person,
                        size = 68.dp,
                    )
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Text(
                            text = student.studentName,
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                        )
                        val classLine = listOfNotNull(
                            student.className,
                            student.classSection?.let { "${strings.sectionLabel}: $it" },
                        ).joinToString(" • ")
                        if (classLine.isNotBlank()) {
                            Text(
                                text = classLine,
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White.copy(alpha = 0.92f),
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = if (student.isActive) {
                                extended.successContainer.copy(alpha = 0.95f)
                            } else {
                                MaterialTheme.colorScheme.errorContainer
                            },
                        ) {
                            Text(
                                text = if (student.isActive) strings.statusActiveBadge else strings.statusInactiveBadge,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (student.isActive) extended.success else MaterialTheme.colorScheme.error,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                            )
                        }
                    }
                    if (isAdmin) {
                        IconButton(
                            onClick = onEdit,
                            modifier = Modifier.testTag("hero_edit_student_button"),
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Edit,
                                contentDescription = strings.editButton,
                                tint = Color.White,
                            )
                        }
                    }
                }

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    IdPillBadge(
                        label = strings.studentIdLabel,
                        value = student.id,
                    )
                    IdPillBadge(
                        label = strings.admissionNoLabel,
                        value = student.admissionNo ?: strings.notProvidedValue,
                    )
                    IdPillBadge(
                        label = strings.rollNoLabel,
                        value = student.rollNo ?: strings.notProvidedValue,
                    )
                }
            }
        }
    }
}

@Composable
private fun IdPillBadge(label: String, value: String) {
    Surface(
        shape = RoundedCornerShape(50),
        color = Color.White.copy(alpha = 0.18f),
    ) {
        Text(
            text = "$label: $value",
            style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
        )
    }
}

@Composable
private fun PersonalDetailsCard(
    student: StudentRecord,
    linkedProfile: LinkedAccountProfile?,
    strings: AppStrings,
) {
    val extended = LocalExtendedColors.current
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SectionTitle(icon = Icons.Rounded.Person, title = strings.personalDetailsTab)

            DetailFieldRow(strings.studentNameLabel, student.studentName)
            DetailFieldRow(strings.dateOfBirthLabel, student.dateOfBirth ?: strings.notProvidedValue, mono = true)
            DetailFieldRow(strings.genderLabel, student.gender ?: strings.notProvidedValue)
            DetailFieldRow(strings.bloodGroupLabel, student.bloodGroup ?: strings.notProvidedValue)
            DetailFieldRow(strings.phoneLabel, student.phone ?: linkedProfile?.phone ?: strings.notProvidedValue, mono = true)
            DetailFieldRow(strings.addressLabel, student.address ?: strings.notProvidedValue)

            Surface(
                shape = MaterialTheme.shapes.small,
                color = if (linkedProfile != null || !student.profileId.isNullOrBlank()) {
                    extended.successContainer.copy(alpha = 0.55f)
                } else {
                    MaterialTheme.colorScheme.surfaceContainerLow
                },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.VerifiedUser,
                        contentDescription = null,
                        tint = if (linkedProfile != null || !student.profileId.isNullOrBlank()) {
                            extended.success
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                    )
                    Column {
                        Text(
                            text = strings.linkedAccountLabel,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                        )
                        Text(
                            text = when {
                                linkedProfile != null -> "${linkedProfile.fullName} (${linkedProfile.id.take(8)}…)"
                                !student.profileId.isNullOrBlank() -> "${strings.accountLinkedBadge} (${student.profileId.take(8)}…)"
                                else -> strings.accountNotLinkedLabel
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            if (student.extraFields.isNotEmpty()) {
                student.extraFields.forEach { (key, value) ->
                    DetailFieldRow(
                        label = key.replace('_', ' ').replaceFirstChar { it.uppercase() },
                        value = value,
                    )
                }
            }
        }
    }
}

@Composable
private fun AcademicDetailsCard(
    student: StudentRecord,
    strings: AppStrings,
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SectionTitle(icon = Icons.Rounded.School, title = strings.academicDetailsTab)

            DetailFieldRow(strings.studentIdLabel, student.id, mono = true)
            DetailFieldRow(strings.admissionNoLabel, student.admissionNo ?: strings.notProvidedValue, mono = true)
            DetailFieldRow(strings.rollNoLabel, student.rollNo ?: strings.notProvidedValue, mono = true)
            DetailFieldRow(strings.classLabel, student.className ?: strings.notProvidedValue)
            student.classSection?.let { DetailFieldRow(strings.sectionLabel, it) }
            student.academicYear?.let { DetailFieldRow(strings.academicYearLabel, it, mono = true) }
            student.admissionDate?.let { DetailFieldRow(strings.admissionDateLabel, it, mono = true) }
            DetailFieldRow(
                label = strings.statusLabel,
                value = if (student.isActive) strings.statusActiveBadge else strings.statusInactiveBadge,
            )
        }
    }
}

@Composable
private fun GuardianDetailsCard(
    student: StudentRecord,
    guardians: List<GuardianLinkItem>,
    isAdmin: Boolean,
    isMutating: Boolean,
    accent: Color,
    strings: AppStrings,
    onOpenLinkGuardian: () -> Unit,
    onUnlinkGuardian: (GuardianLinkItem) -> Unit,
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                SectionTitle(icon = Icons.Rounded.FamilyRestroom, title = strings.guardianDetailsTab)
                if (isAdmin) {
                    OutlinedButton(
                        onClick = onOpenLinkGuardian,
                        enabled = !isMutating,
                        modifier = Modifier
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("link_guardian_button"),
                    ) {
                        Icon(Icons.Rounded.PersonAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(strings.linkGuardianButton)
                    }
                }
            }

            if (!student.fatherName.isNullOrBlank()) {
                DetailFieldRow(strings.fatherNameLabel, student.fatherName)
            }
            if (!student.motherName.isNullOrBlank()) {
                DetailFieldRow(strings.motherNameLabel, student.motherName)
            }
            if (!student.guardianName.isNullOrBlank()) {
                DetailFieldRow(strings.guardianNameLabel, student.guardianName)
            }
            if (!student.guardianPhone.isNullOrBlank()) {
                DetailFieldRow(strings.guardianPhoneLabel, student.guardianPhone, mono = true)
            }

            if (guardians.isEmpty()) {
                Text(
                    text = strings.noGuardiansFound,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                guardians.forEach { link ->
                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = MaterialTheme.colorScheme.surfaceContainerLow,
                        border = BorderStroke(1.dp, accent.copy(alpha = 0.25f)),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            Icon(Icons.Rounded.Badge, contentDescription = null, tint = accent)
                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(
                                    text = link.parentName ?: link.parentProfileId ?: strings.roleParent,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    link.relationship?.let { rel ->
                                        Text(
                                            text = rel,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = accent,
                                        )
                                    }
                                    if (link.isPrimary) {
                                        Text(
                                            text = "• ${strings.primaryGuardianBadge}",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = LocalExtendedColors.current.success,
                                        )
                                    }
                                }
                                link.parentPhone?.let { phone ->
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Rounded.Phone,
                                            contentDescription = null,
                                            modifier = Modifier.size(14.dp),
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = phone,
                                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily),
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                }
                            }
                            if (isAdmin) {
                                IconButton(
                                    onClick = { onUnlinkGuardian(link) },
                                    enabled = !isMutating,
                                    modifier = Modifier.testTag("unlink_guardian_${link.id ?: link.parentProfileId}"),
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Delete,
                                        contentDescription = strings.unlinkGuardianConfirm,
                                        tint = MaterialTheme.colorScheme.error,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun LinkGuardianDialog(
    parentOptions: List<ParentProfileOption>,
    isSaving: Boolean,
    onDismiss: () -> Unit,
    onLink: (parentProfileId: String, relationship: String) -> Unit,
) {
    val strings = LocalAppStrings.current
    var selectedParentId by remember { mutableStateOf(parentOptions.firstOrNull()?.id.orEmpty()) }
    var relationship by remember { mutableStateOf("Father") }
    var manualProfileId by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = { if (!isSaving) onDismiss() },
        title = { Text(strings.linkGuardianButton) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = strings.selectParentLabel,
                    style = MaterialTheme.typography.labelMedium,
                )
                if (parentOptions.isNotEmpty()) {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        parentOptions.take(12).forEach { opt ->
                            FilterChip(
                                selected = selectedParentId == opt.id,
                                onClick = { selectedParentId = opt.id },
                                label = { Text(opt.fullName) },
                            )
                        }
                    }
                } else {
                    OutlinedTextField(
                        value = manualProfileId,
                        onValueChange = { manualProfileId = it },
                        label = { Text("Parent Profile UUID") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }

                OutlinedTextField(
                    value = relationship,
                    onValueChange = { relationship = it },
                    label = { Text(strings.relationshipLabel) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            val targetId = selectedParentId.ifBlank { manualProfileId.trim() }
            Button(
                onClick = { onLink(targetId, relationship) },
                enabled = !isSaving && targetId.isNotBlank(),
            ) {
                Text(strings.linkGuardianButton)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !isSaving) {
                Text(strings.cancel)
            }
        },
    )
}

@Composable
private fun SectionTitle(icon: ImageVector, title: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp),
        )
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
        )
    }
}

@Composable
private fun DetailFieldRow(
    label: String,
    value: String,
    mono: Boolean = false,
) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            text = value,
            style = if (mono) {
                MaterialTheme.typography.bodyMedium.copy(fontFamily = JetBrainsMonoFamily)
            } else {
                MaterialTheme.typography.bodyMedium
            },
            fontWeight = FontWeight.Medium,
        )
    }
}
