package com.example.erp.core.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

object PdfDocumentHelper {
    private const val PAGE_WIDTH = 595
    private const val PAGE_HEIGHT = 842

    fun createAndShareDocumentPdf(
        context: Context,
        fileName: String,
        title: String,
        subtitle: String,
        lines: List<Pair<String, String>>,
        footerNote: String,
    ): File {
        val pdfDir = File(context.cacheDir, "pdfs").apply { mkdirs() }
        val cleanName = fileName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
        val file = File(pdfDir, if (cleanName.endsWith(".pdf")) cleanName else "$cleanName.pdf")

        val doc = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
        val page = doc.startPage(pageInfo)
        drawStructuredDocument(page.canvas, title, subtitle, lines, footerNote)
        doc.finishPage(page)

        FileOutputStream(file).use { out ->
            doc.writeTo(out)
        }
        doc.close()

        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(shareIntent, title).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
        return file
    }

    fun printDocumentPdf(
        context: Context,
        jobName: String,
        title: String,
        subtitle: String,
        lines: List<Pair<String, String>>,
        footerNote: String,
    ) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        val adapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback,
                extras: android.os.Bundle?,
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback.onLayoutCancelled()
                    return
                }
                val info = PrintDocumentInfo.Builder("$jobName.pdf")
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(1)
                    .build()
                callback.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback,
            ) {
                val doc = PdfDocument()
                val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
                val page = doc.startPage(pageInfo)
                drawStructuredDocument(page.canvas, title, subtitle, lines, footerNote)
                doc.finishPage(page)

                try {
                    FileOutputStream(destination.fileDescriptor).use { out ->
                        doc.writeTo(out)
                    }
                    callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback.onWriteFailed(e.message)
                } finally {
                    doc.close()
                }
            }
        }
        printManager.print(jobName, adapter, PrintAttributes.Builder().build())
    }

    private fun drawStructuredDocument(
        canvas: Canvas,
        title: String,
        subtitle: String,
        lines: List<Pair<String, String>>,
        footerNote: String,
    ) {
        val headerBg = Paint().apply {
            color = Color.rgb(15, 74, 92)
            style = Paint.Style.FILL
        }
        val borderPaint = Paint().apply {
            color = Color.rgb(190, 205, 212)
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
        }
        val schoolPaint = Paint().apply {
            color = Color.WHITE
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val subSchoolPaint = Paint().apply {
            color = Color.rgb(225, 240, 244)
            textSize = 12f
            isAntiAlias = true
        }
        val titlePaint = Paint().apply {
            color = Color.rgb(15, 74, 92)
            textSize = 17f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val labelPaint = Paint().apply {
            color = Color.rgb(90, 102, 110)
            textSize = 12f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val valuePaint = Paint().apply {
            color = Color.rgb(25, 32, 38)
            textSize = 13f
            isAntiAlias = true
        }
        val footerPaint = Paint().apply {
            color = Color.rgb(90, 102, 110)
            textSize = 10.5f
            isAntiAlias = true
        }

        canvas.drawRect(28f, 28f, PAGE_WIDTH - 28f, 110f, headerBg)
        canvas.drawRect(28f, 28f, PAGE_WIDTH - 28f, PAGE_HEIGHT - 28f, borderPaint)
        canvas.drawText("Paschim Mallickpara Shubhadisha Child Academy", 44f, 64f, schoolPaint)
        canvas.drawText(subtitle, 44f, 88f, subSchoolPaint)

        var y = 148f
        canvas.drawText(title, 44f, y, titlePaint)
        y += 14f
        canvas.drawLine(44f, y, PAGE_WIDTH - 44f, y, borderPaint)
        y += 26f

        for ((label, value) in lines) {
            if (y > PAGE_HEIGHT - 96f) break
            canvas.drawText(label, 44f, y, labelPaint)
            canvas.drawText(value.take(54), 220f, y, valuePaint)
            y += 10f
            canvas.drawLine(44f, y, PAGE_WIDTH - 44f, y, borderPaint)
            y += 22f
        }

        canvas.drawText(footerNote, 44f, PAGE_HEIGHT - 54f, footerPaint)
    }
}
