package com.example.erp.features.notices

import com.example.erp.core.model.AuthSession
import com.example.erp.core.model.HolidayDraft
import com.example.erp.core.model.HolidayItem
import com.example.erp.core.model.NoticeDraft
import com.example.erp.core.model.NoticeItem
import com.example.erp.core.model.UserRole
import com.example.erp.core.network.SupabaseClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

class NoticesHolidaysRepository(
    private val client: SupabaseClient,
) {
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun fetchNotices(session: AuthSession): Result<List<NoticeItem>> =
        withContext(Dispatchers.IO) {
            runCatching {
                val isAdmin = session.user.role == UserRole.ADMIN
                val path = if (isAdmin) {
                    "/rest/v1/notices?select=*&order=publish_date.desc.nullslast,created_at.desc"
                } else {
                    "/rest/v1/notices?is_published=eq.true&select=*&order=publish_date.desc.nullslast,created_at.desc"
                }

                val request = client.authenticatedRequestBuilder(
                    path = path,
                    accessToken = session.accessToken,
                )
                    .get()
                    .build()

                client.httpClient.newCall(request).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        error(extractRestError(body, response.code))
                    }
                    parseNoticeArray(JSONArray(body))
                }
            }
        }

    suspend fun createNotice(
        session: AuthSession,
        draft: NoticeDraft,
    ): Result<NoticeItem> = withContext(Dispatchers.IO) {
        runCatching {
            require(session.user.role == UserRole.ADMIN) {
                "Only Admin can create notices."
            }
            val payload = noticePayload(draft, createdBy = session.user.userId).toString()
            val request = client.authenticatedRequestBuilder(
                path = "/rest/v1/notices",
                accessToken = session.accessToken,
            )
                .header("Prefer", "return=representation")
                .post(payload.toRequestBody(jsonMediaType))
                .build()

            client.httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    error(extractRestError(body, response.code))
                }
                val rows = parseNoticeArray(JSONArray(body))
                rows.firstOrNull() ?: error("Notice created but no row returned.")
            }
        }
    }

    suspend fun updateNotice(
        session: AuthSession,
        noticeId: String,
        draft: NoticeDraft,
    ): Result<NoticeItem> = withContext(Dispatchers.IO) {
        runCatching {
            require(session.user.role == UserRole.ADMIN) {
                "Only Admin can edit notices."
            }
            val payload = noticePayload(draft, createdBy = null).toString()
            val encodedId = URLEncoder.encode(noticeId, "UTF-8")
            val request = client.authenticatedRequestBuilder(
                path = "/rest/v1/notices?id=eq.$encodedId",
                accessToken = session.accessToken,
            )
                .header("Prefer", "return=representation")
                .patch(payload.toRequestBody(jsonMediaType))
                .build()

            client.httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    error(extractRestError(body, response.code))
                }
                val rows = parseNoticeArray(JSONArray(body))
                rows.firstOrNull() ?: error("Notice update returned no row (check RLS permissions).")
            }
        }
    }

    suspend fun setNoticePublished(
        session: AuthSession,
        noticeId: String,
        isPublished: Boolean,
    ): Result<NoticeItem> = withContext(Dispatchers.IO) {
        runCatching {
            require(session.user.role == UserRole.ADMIN) {
                "Only Admin can publish or unpublish notices."
            }
            val payload = JSONObject().apply {
                put("is_published", isPublished)
            }.toString()
            val encodedId = URLEncoder.encode(noticeId, "UTF-8")
            val request = client.authenticatedRequestBuilder(
                path = "/rest/v1/notices?id=eq.$encodedId",
                accessToken = session.accessToken,
            )
                .header("Prefer", "return=representation")
                .patch(payload.toRequestBody(jsonMediaType))
                .build()

            client.httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    error(extractRestError(body, response.code))
                }
                val rows = parseNoticeArray(JSONArray(body))
                rows.firstOrNull() ?: error("Publish update returned no row (check RLS permissions).")
            }
        }
    }

    suspend fun deleteNotice(
        session: AuthSession,
        noticeId: String,
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            require(session.user.role == UserRole.ADMIN) {
                "Only Admin can delete notices."
            }
            val encodedId = URLEncoder.encode(noticeId, "UTF-8")
            val request = client.authenticatedRequestBuilder(
                path = "/rest/v1/notices?id=eq.$encodedId",
                accessToken = session.accessToken,
            )
                .delete()
                .build()

            client.httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    error(extractRestError(body, response.code))
                }
            }
        }
    }

    suspend fun fetchHolidays(session: AuthSession): Result<List<HolidayItem>> =
        withContext(Dispatchers.IO) {
            runCatching {
                val request = client.authenticatedRequestBuilder(
                    path = "/rest/v1/holidays?select=*&order=holiday_date.asc",
                    accessToken = session.accessToken,
                )
                    .get()
                    .build()

                client.httpClient.newCall(request).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        error(extractRestError(body, response.code))
                    }
                    parseHolidayArray(JSONArray(body))
                }
            }
        }

    suspend fun createHoliday(
        session: AuthSession,
        draft: HolidayDraft,
    ): Result<HolidayItem> = withContext(Dispatchers.IO) {
        runCatching {
            require(session.user.role == UserRole.ADMIN) {
                "Only Admin can create holidays."
            }
            val payload = holidayPayload(draft).toString()
            val request = client.authenticatedRequestBuilder(
                path = "/rest/v1/holidays",
                accessToken = session.accessToken,
            )
                .header("Prefer", "return=representation")
                .post(payload.toRequestBody(jsonMediaType))
                .build()

            client.httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    error(extractRestError(body, response.code))
                }
                val rows = parseHolidayArray(JSONArray(body))
                rows.firstOrNull() ?: error("Holiday created but no row returned.")
            }
        }
    }

    suspend fun updateHoliday(
        session: AuthSession,
        holidayId: String,
        draft: HolidayDraft,
    ): Result<HolidayItem> = withContext(Dispatchers.IO) {
        runCatching {
            require(session.user.role == UserRole.ADMIN) {
                "Only Admin can edit holidays."
            }
            val payload = holidayPayload(draft).toString()
            val encodedId = URLEncoder.encode(holidayId, "UTF-8")
            val request = client.authenticatedRequestBuilder(
                path = "/rest/v1/holidays?id=eq.$encodedId",
                accessToken = session.accessToken,
            )
                .header("Prefer", "return=representation")
                .patch(payload.toRequestBody(jsonMediaType))
                .build()

            client.httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    error(extractRestError(body, response.code))
                }
                val rows = parseHolidayArray(JSONArray(body))
                rows.firstOrNull() ?: error("Holiday update returned no row (check RLS permissions).")
            }
        }
    }

    suspend fun deleteHoliday(
        session: AuthSession,
        holidayId: String,
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            require(session.user.role == UserRole.ADMIN) {
                "Only Admin can delete holidays."
            }
            val encodedId = URLEncoder.encode(holidayId, "UTF-8")
            val request = client.authenticatedRequestBuilder(
                path = "/rest/v1/holidays?id=eq.$encodedId",
                accessToken = session.accessToken,
            )
                .delete()
                .build()

            client.httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    error(extractRestError(body, response.code))
                }
            }
        }
    }

    private fun noticePayload(draft: NoticeDraft, createdBy: String?): JSONObject =
        JSONObject().apply {
            put("title", draft.title.trim())
            put("body", draft.body.trim().ifEmpty { JSONObject.NULL })
            put("notice_type", draft.noticeType.trim().ifEmpty { "General" })
            put("publish_date", draft.publishDate.trim().ifEmpty { JSONObject.NULL })
            put("expiry_date", draft.expiryDate.trim().ifEmpty { JSONObject.NULL })
            put("is_published", draft.isPublished)
            if (draft.thumbnailUrl.isNotBlank()) {
                put("thumbnail_url", draft.thumbnailUrl.trim())
            }
            if (createdBy != null) {
                put("created_by", createdBy)
            }
        }

    private fun holidayPayload(draft: HolidayDraft): JSONObject =
        JSONObject().apply {
            put("holiday_name", draft.holidayName.trim())
            put("holiday_date", draft.holidayDate.trim())
            put("end_date", draft.endDate.trim().ifEmpty { JSONObject.NULL })
            put("holiday_type", draft.holidayType.trim().ifEmpty { "School Holiday" })
            put("description", draft.description.trim().ifEmpty { JSONObject.NULL })
            put("school_reopen_date", draft.schoolReopenDate.trim().ifEmpty { JSONObject.NULL })
        }

    private fun parseNoticeArray(array: JSONArray): List<NoticeItem> {
        val result = mutableListOf<NoticeItem>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            result.add(
                NoticeItem(
                    id = obj.getString("id"),
                    title = obj.optString("title", ""),
                    body = obj.optNullableString("body"),
                    noticeType = obj.optNullableString("notice_type") ?: "General",
                    publishDate = obj.optNullableString("publish_date"),
                    expiryDate = obj.optNullableString("expiry_date"),
                    isPublished = obj.optBoolean("is_published", false),
                    createdBy = obj.optNullableString("created_by"),
                    createdAt = obj.optString("created_at", ""),
                    thumbnailUrl = client.resolveStorageUrl(obj.optNullableString("thumbnail_url")),
                ),
            )
        }
        return result
    }

    private fun parseHolidayArray(array: JSONArray): List<HolidayItem> {
        val result = mutableListOf<HolidayItem>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            result.add(
                HolidayItem(
                    id = obj.getString("id"),
                    holidayName = obj.optString("holiday_name", ""),
                    holidayDate = obj.optString("holiday_date", ""),
                    endDate = obj.optNullableString("end_date"),
                    holidayType = obj.optNullableString("holiday_type") ?: "School Holiday",
                    description = obj.optNullableString("description"),
                    schoolReopenDate = obj.optNullableString("school_reopen_date"),
                    createdAt = obj.optString("created_at", ""),
                ),
            )
        }
        return result
    }

    private fun JSONObject.optNullableString(key: String): String? {
        if (!has(key) || isNull(key)) return null
        return optString(key).takeIf { it.isNotBlank() && it != "null" }
    }

    private fun extractRestError(rawBody: String, statusCode: Int): String {
        return runCatching {
            val json = JSONObject(rawBody)
            json.optString("message").takeIf { it.isNotBlank() }
                ?: json.optString("hint").takeIf { it.isNotBlank() }
                ?: json.optString("error").takeIf { it.isNotBlank() }
                ?: "Request failed (HTTP $statusCode)"
        }.getOrDefault("Request failed (HTTP $statusCode)")
    }
}
