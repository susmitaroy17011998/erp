package com.example.erp.features.students

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.erp.core.i18n.AppLanguage
import com.example.erp.core.i18n.LocalAppLanguage
import com.example.erp.core.i18n.LocalAppStrings
import com.example.erp.core.model.AuthSession
import com.example.erp.core.model.LoadableState
import com.example.erp.core.model.StudentRecord
import com.example.erp.core.model.StudentStatusFilter
import com.example.erp.core.model.UserRole
import com.example.erp.ui.components.AuthenticatedAvatar
import com.example.erp.ui.components.LanguageTogglePill
import com.example.erp.ui.components.roleAccentColor
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LocalExtendedColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentsScreen(
    session: AuthSession,
    uiState: StudentsUiState,
    viewModel: StudentsViewModel,
    onLanguageSelected: (AppLanguage) -> Unit,
    onBack: () -> Unit,
) {
    val strings = LocalAppStrings.current
    val language = LocalAppLanguage.current
    val role = session.user.role
    val isAdmin = role == UserRole.ADMIN
    val accent = roleAccentColor(role)

    LaunchedEffect(session.user.userId) {
        viewModel.ensureLoaded(session)
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isTwoPane = maxWidth >= 840.dp
        val activeStudent = uiState.activeDetailStudent

        if (!isTwoPane && activeStudent != null) {
            BackHandler {
                if (role == UserRole.STUDENT) {
                    viewModel.closeStudentProfile()
                    onBack()
                } else {
                    viewModel.closeStudentProfile()
                }
            }
            StudentProfileContent(
                session = session,
                student = activeStudent,
                detailState = uiState.detailState,
                parentOptions = uiState.parentOptions,
                showLinkGuardianDialog = uiState.showLinkGuardianDialog,
                isMutatingGuardian = uiState.isMutatingGuardian,
                actionError = uiState.actionError,
                showTopBar = true,
                onBack = {
                    if (role == UserRole.STUDENT) {
                        viewModel.closeStudentProfile()
                        onBack()
                    } else {
                        viewModel.closeStudentProfile()
                    }
                },
                onRefresh = { viewModel.openStudentProfile(session, activeStudent) },
                onEdit = { viewModel.openEditStudent(session, activeStudent) },
                onOpenLinkGuardian = { viewModel.openLinkGuardianDialog(session) },
                onDismissLinkGuardian = viewModel::dismissLinkGuardianDialog,
                onConfirmLinkGuardian = { parentId, rel ->
                    viewModel.linkGuardian(session, activeStudent, parentId, rel)
                },
                onUnlinkGuardian = { link -> viewModel.unlinkGuardian(session, activeStudent, link) },
            )
        } else {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                contentWindowInsets = WindowInsets.navigationBars,
                topBar = {
                    TopAppBar(
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                        ),
                        title = {
                            Column {
                                Text(
                                    text = strings.modStudents,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                )
                                Text(
                                    text = role.label(strings),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = accent,
                                )
                            }
                        },
                        navigationIcon = {
                            IconButton(
                                onClick = onBack,
                                modifier = Modifier.testTag("students_back_button"),
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                    contentDescription = strings.backToOverview,
                                )
                            }
                        },
                        actions = {
                            IconButton(
                                onClick = { viewModel.refreshAll(session) },
                                modifier = Modifier.testTag("students_refresh_button"),
                            ) {
                                Icon(Icons.Rounded.Refresh, contentDescription = strings.refreshActionDesc)
                            }
                            LanguageTogglePill(
                                currentLanguage = language,
                                onLanguageSelected = onLanguageSelected,
                                modifier = Modifier.padding(end = 8.dp),
                            )
                        },
                    )
                },
                floatingActionButton = {
                    if (isAdmin) {
                        FloatingActionButton(
                            onClick = { viewModel.openAddStudent(session) },
                            containerColor = accent,
                            contentColor = Color.White,
                            modifier = Modifier.testTag("add_student_fab"),
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = strings.addStudentButton)
                        }
                    }
                },
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                ) {
                    Box(
                        modifier = Modifier
                            .weight(if (isTwoPane && activeStudent != null) 0.45f else 1f)
                            .fillMaxHeight(),
                        contentAlignment = Alignment.TopCenter,
                    ) {
                        StudentsDirectoryPane(
                            session = session,
                            uiState = uiState,
                            viewModel = viewModel,
                            accent = accent,
                        )
                    }

                    if (isTwoPane && activeStudent != null) {
                        VerticalDivider()
                        Box(
                            modifier = Modifier
                                .weight(0.55f)
                                .fillMaxHeight(),
                        ) {
                            StudentProfileContent(
                                session = session,
                                student = activeStudent,
                                detailState = uiState.detailState,
                                parentOptions = uiState.parentOptions,
                                showLinkGuardianDialog = uiState.showLinkGuardianDialog,
                                isMutatingGuardian = uiState.isMutatingGuardian,
                                actionError = uiState.actionError,
                                showTopBar = false,
                                onBack = viewModel::closeStudentProfile,
                                onRefresh = { viewModel.openStudentProfile(session, activeStudent) },
                                onEdit = { viewModel.openEditStudent(session, activeStudent) },
                                onOpenLinkGuardian = { viewModel.openLinkGuardianDialog(session) },
                                onDismissLinkGuardian = viewModel::dismissLinkGuardianDialog,
                                onConfirmLinkGuardian = { parentId, rel ->
                                    viewModel.linkGuardian(session, activeStudent, parentId, rel)
                                },
                                onUnlinkGuardian = { link -> viewModel.unlinkGuardian(session, activeStudent, link) },
                            )
                        }
                    }
                }
            }
        }
    }

    uiState.editingDraft?.let { draft ->
        StudentEditorDialog(
            draft = draft,
            classes = uiState.classes,
            knownColumns = uiState.knownColumns,
            isSaving = uiState.isSaving,
            isUploadingPhoto = uiState.isUploadingPhoto,
            photoUploadNotice = uiState.photoUploadNotice,
            errorMessage = uiState.formError,
            onDraftChange = { updated -> viewModel.updateDraft { updated } },
            onUploadPhotoBytes = { bytes, mime, ext ->
                viewModel.uploadDraftPhoto(
                    session = session,
                    imageBytes = bytes,
                    mimeType = mime,
                    extension = ext,
                    successNotice = strings.photoUploadedNotice,
                )
            },
            onDismiss = viewModel::dismissEditor,
            onSave = { viewModel.saveDraft(session, strings.studentNameRequiredError) },
        )
    }
}

@Composable
private fun StudentsDirectoryPane(
    session: AuthSession,
    uiState: StudentsUiState,
    viewModel: StudentsViewModel,
    accent: Color,
) {
    val strings = LocalAppStrings.current
    val role = session.user.role
    val isAdmin = role == UserRole.ADMIN
    val showDirectoryFilters = role == UserRole.ADMIN || role == UserRole.TEACHER
    val listState = rememberLazyListState()

    val shouldTriggerLoadMore by remember(uiState.hasMore, uiState.isLoadingMore) {
        derivedStateOf {
            val totalItems = listState.layoutInfo.totalItemsCount
            val lastVisible = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            uiState.hasMore && !uiState.isLoadingMore && totalItems > 0 && lastVisible >= totalItems - 3
        }
    }

    LaunchedEffect(shouldTriggerLoadMore) {
        if (shouldTriggerLoadMore) {
            viewModel.loadNextPage(session)
        }
    }

    Column(
        modifier = Modifier
            .widthIn(max = 900.dp)
            .fillMaxSize(),
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            val roleBannerText = when (role) {
                UserRole.STUDENT -> strings.studentSelfPortalBanner
                UserRole.PARENT -> strings.parentWardsPortalBanner
                UserRole.TEACHER -> if (session.user.staffInfo?.assignedClasses?.isNotEmpty() == true) {
                    "${strings.teacherScopedClassesBanner} (${strings.readOnlyRoleBanner})"
                } else {
                    strings.readOnlyRoleBanner
                }
                UserRole.ADMIN -> null
            }

            if (roleBannerText != null) {
                Surface(
                    shape = MaterialTheme.shapes.small,
                    color = accent.copy(alpha = 0.1f),
                    border = BorderStroke(1.dp, accent.copy(alpha = 0.25f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("students_role_banner"),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Info,
                            contentDescription = null,
                            tint = accent,
                            modifier = Modifier.size(16.dp),
                        )
                        Text(
                            text = roleBannerText,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                    }
                }
            }

            if (showDirectoryFilters) {
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = { viewModel.updateSearchQuery(session, it) },
                    placeholder = { Text(strings.searchStudentsHint) },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                    trailingIcon = {
                        if (uiState.searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.updateSearchQuery(session, "") }) {
                                Icon(Icons.Rounded.Close, contentDescription = strings.clearDate)
                            }
                        }
                    },
                    singleLine = true,
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("students_search_input"),
                )

                if (uiState.classes.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        FilterChip(
                            selected = uiState.selectedClassId == null,
                            onClick = { viewModel.selectClassFilter(session, null) },
                            label = { Text(strings.allClassesFilter) },
                            modifier = Modifier.testTag("class_filter_all"),
                        )
                        uiState.classes.forEach { cls ->
                            FilterChip(
                                selected = uiState.selectedClassId == cls.id,
                                onClick = {
                                    viewModel.selectClassFilter(
                                        session = session,
                                        classId = if (uiState.selectedClassId == cls.id) null else cls.id,
                                    )
                                },
                                label = { Text(cls.displayLabel) },
                                modifier = Modifier.testTag("class_filter_${cls.id}"),
                            )
                        }
                    }
                }

                if (isAdmin) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        listOf(
                            StudentStatusFilter.ALL to strings.filterAll,
                            StudentStatusFilter.ACTIVE to strings.statusActiveBadge,
                            StudentStatusFilter.INACTIVE to strings.statusInactiveBadge,
                        ).forEach { (status, label) ->
                            FilterChip(
                                selected = uiState.selectedStatusFilter == status,
                                onClick = { viewModel.selectStatusFilter(session, status) },
                                label = { Text(label) },
                                modifier = Modifier.testTag("student_status_filter_${status.name.lowercase()}"),
                            )
                        }
                    }
                }
            }
        }

        when (val state = uiState.studentsState) {
            LoadableState.Loading -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(modifier = Modifier.testTag("students_loading_indicator"))
                }
            }
            is LoadableState.Error -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Text(
                            text = state.message,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.error,
                        )
                        Button(onClick = { viewModel.refreshList(session) }) {
                            Text(strings.retryButton)
                        }
                    }
                }
            }
            is LoadableState.Success -> {
                val students = state.items
                if (students.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Groups,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(44.dp),
                            )
                            Text(
                                text = strings.noStudentsFound,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(
                            start = 16.dp,
                            end = 16.dp,
                            bottom = if (isAdmin) 88.dp else 20.dp,
                        ),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        uiState.totalCount?.let { total ->
                            item(key = "pagination_header") {
                                Text(
                                    text = String.format(strings.paginationSummaryFormat, students.size, total),
                                    style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFamily),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.testTag("students_pagination_summary"),
                                )
                            }
                        }

                        items(students, key = { it.id }) { student ->
                            StudentListCard(
                                student = student,
                                isSelected = uiState.activeDetailStudent?.id == student.id,
                                isAdmin = isAdmin,
                                accent = accent,
                                onClick = { viewModel.openStudentProfile(session, student) },
                                onEdit = { viewModel.openEditStudent(session, student) },
                            )
                        }

                        if (uiState.hasMore || uiState.isLoadingMore || uiState.loadMoreError != null) {
                            item(key = "pagination_footer") {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    if (uiState.loadMoreError != null) {
                                        Text(
                                            text = uiState.loadMoreError,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.error,
                                        )
                                    }
                                    if (uiState.isLoadingMore) {
                                        CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                                    } else if (uiState.hasMore) {
                                        OutlinedButton(
                                            onClick = { viewModel.loadNextPage(session) },
                                            modifier = Modifier
                                                .defaultMinSize(minHeight = 48.dp)
                                                .testTag("load_more_students_button"),
                                        ) {
                                            Text(strings.loadMoreStudentsButton)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StudentListCard(
    student: StudentRecord,
    isSelected: Boolean,
    isAdmin: Boolean,
    accent: Color,
    onClick: () -> Unit,
    onEdit: () -> Unit,
) {
    val strings = LocalAppStrings.current
    val extended = LocalExtendedColors.current

    Surface(
        shape = MaterialTheme.shapes.medium,
        color = if (isSelected) {
            accent.copy(alpha = 0.08f)
        } else {
            MaterialTheme.colorScheme.surfaceContainerLowest
        },
        border = BorderStroke(
            width = if (isSelected) 1.5.dp else 1.dp,
            color = if (isSelected) accent else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f),
        ),
        tonalElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .testTag("student_card_${student.id}"),
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            AuthenticatedAvatar(
                photoUrl = student.photoUrl,
                contentDescription = student.studentName,
                accentColor = accent,
                fallbackIcon = Icons.Rounded.Person,
                size = 52.dp,
            )

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        text = student.studentName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = if (student.isActive) {
                            extended.successContainer
                        } else {
                            MaterialTheme.colorScheme.errorContainer
                        },
                    ) {
                        Text(
                            text = if (student.isActive) strings.statusActiveBadge else strings.statusInactiveBadge,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (student.isActive) extended.success else MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                        )
                    }
                }

                val classRoll = listOfNotNull(
                    student.className,
                    student.rollNo?.let { "${strings.rollNoLabel}: $it" },
                ).joinToString(" • ")
                if (classRoll.isNotBlank()) {
                    Text(
                        text = classRoll,
                        style = MaterialTheme.typography.bodySmall,
                        color = accent,
                        fontWeight = FontWeight.SemiBold,
                    )
                }

                val idLine = buildString {
                    append("${strings.studentIdLabel}: ${student.id.take(8)}")
                    student.admissionNo?.let {
                        append("  •  ${strings.admissionNoLabel}: $it")
                    }
                }
                Text(
                    text = idLine,
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            if (isAdmin) {
                IconButton(
                    onClick = onEdit,
                    modifier = Modifier.testTag("edit_student_${student.id}"),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Edit,
                        contentDescription = strings.editButton,
                    )
                }
            }
        }
    }
}
