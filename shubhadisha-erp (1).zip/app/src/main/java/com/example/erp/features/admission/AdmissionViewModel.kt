package com.example.erp.features.admission

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.erp.core.model.AdmissionEnquiryDraft
import com.example.erp.core.model.AdmissionEnquiryRecord
import com.example.erp.core.model.AdmissionEnrollDraft
import com.example.erp.core.model.AdmissionStatus
import com.example.erp.core.model.AdmissionStatusFilter
import com.example.erp.core.model.AuthSession
import com.example.erp.core.model.LoadableState
import com.example.erp.core.model.SchoolClassItem
import com.example.erp.core.model.UserRole
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Immutable
data class AdmissionUiState(
    val classes: List<SchoolClassItem> = emptyList(),
    val enquiriesState: LoadableState<List<AdmissionEnquiryRecord>> = LoadableState.Loading,
    val statusFilter: AdmissionStatusFilter = AdmissionStatusFilter.ALL,
    val searchQuery: String = "",
    val selectedEnquiry: AdmissionEnquiryRecord? = null,
    val editingDraft: AdmissionEnquiryDraft? = null,
    val enrollDraft: AdmissionEnrollDraft? = null,
    val pendingDelete: AdmissionEnquiryRecord? = null,
    val isSaving: Boolean = false,
    val isMutating: Boolean = false,
    val formError: String? = null,
    val actionMessage: String? = null,
    val actionError: String? = null,
)

class AdmissionViewModel(
    private val repository: AdmissionRepository,
    private val todayProvider: () -> String = {
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    },
) : ViewModel() {

    private val _uiState = MutableStateFlow(AdmissionUiState())
    val uiState: StateFlow<AdmissionUiState> = _uiState.asStateFlow()

    private var lastLoadedUserId: String? = null
    private var searchJob: Job? = null

    fun ensureLoaded(session: AuthSession) {
        val existing = (_uiState.value.enquiriesState as? LoadableState.Success)?.items
        if (lastLoadedUserId == session.user.userId && existing != null) return
        lastLoadedUserId = session.user.userId
        refreshAll(session)
    }

    fun refreshAll(session: AuthSession) {
        if (session.user.role != UserRole.ADMIN) return
        viewModelScope.launch {
            repository.fetchClasses(session).onSuccess { list ->
                _uiState.update { it.copy(classes = list) }
            }
            loadEnquiries(session)
        }
    }

    fun selectStatusFilter(session: AuthSession, filter: AdmissionStatusFilter) {
        _uiState.update { it.copy(statusFilter = filter) }
        loadEnquiries(session)
    }

    fun updateSearchQuery(session: AuthSession, query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            delay(250L)
            loadEnquiries(session)
        }
    }

    fun loadEnquiries(session: AuthSession) {
        viewModelScope.launch {
            _uiState.update { it.copy(enquiriesState = LoadableState.Loading, actionError = null) }
            val current = _uiState.value
            repository.fetchEnquiries(
                session = session,
                statusFilter = current.statusFilter,
                query = current.searchQuery,
            ).fold(
                onSuccess = { items ->
                    _uiState.update { it.copy(enquiriesState = LoadableState.Success(items)) }
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(enquiriesState = LoadableState.Error(err.message ?: "Failed to load enquiries."))
                    }
                },
            )
        }
    }

    fun openDetail(enquiry: AdmissionEnquiryRecord) {
        _uiState.update { it.copy(selectedEnquiry = enquiry, actionError = null, actionMessage = null) }
    }

    fun closeDetail() {
        _uiState.update { it.copy(selectedEnquiry = null) }
    }

    fun openCreateDialog(session: AuthSession) {
        if (session.user.role != UserRole.ADMIN) return
        val firstClass = _uiState.value.classes.firstOrNull()
        _uiState.update {
            it.copy(
                editingDraft = AdmissionEnquiryDraft(
                    appliedClass = firstClass?.className.orEmpty(),
                    classId = firstClass?.id.orEmpty(),
                    enquiryDate = todayProvider(),
                    status = AdmissionStatus.PENDING,
                ),
                formError = null,
            )
        }
    }

    fun openEditDialog(session: AuthSession, record: AdmissionEnquiryRecord) {
        if (session.user.role != UserRole.ADMIN) return
        _uiState.update {
            it.copy(
                editingDraft = AdmissionEnquiryDraft(
                    id = record.id,
                    recordId = record.recordId,
                    studentName = record.studentName,
                    guardianName = record.guardianName,
                    phone = record.phone,
                    email = record.email.orEmpty(),
                    appliedClass = record.appliedClass,
                    classId = record.classId.orEmpty(),
                    enquiryDate = record.enquiryDate,
                    dateOfBirth = record.dateOfBirth.orEmpty(),
                    gender = record.gender.orEmpty(),
                    previousSchool = record.previousSchool.orEmpty(),
                    address = record.address.orEmpty(),
                    status = record.status,
                    notes = record.notes.orEmpty(),
                    enrolledStudentId = record.enrolledStudentId,
                    rawRecordDataJson = record.rawRecordDataJson,
                ),
                formError = null,
            )
        }
    }

    fun updateDraft(transform: (AdmissionEnquiryDraft) -> AdmissionEnquiryDraft) {
        _uiState.update { state ->
            val current = state.editingDraft ?: return@update state
            state.copy(editingDraft = transform(current), formError = null)
        }
    }

    fun dismissEditor() {
        _uiState.update { it.copy(editingDraft = null, formError = null) }
    }

    fun saveDraft(session: AuthSession, nameRequiredError: String) {
        if (session.user.role != UserRole.ADMIN) return
        val draft = _uiState.value.editingDraft ?: return
        if (draft.studentName.trim().isEmpty()) {
            _uiState.update { it.copy(formError = nameRequiredError) }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true, formError = null, actionError = null) }
            val result = if (draft.id == null) {
                repository.createEnquiry(session, draft, todayProvider())
            } else {
                repository.updateEnquiry(session, draft.id, draft, todayProvider())
            }
            result.fold(
                onSuccess = { saved ->
                    _uiState.update { state ->
                        state.copy(
                            editingDraft = null,
                            isSaving = false,
                            selectedEnquiry = if (state.selectedEnquiry?.id == saved.id) saved else state.selectedEnquiry,
                        )
                    }
                    loadEnquiries(session)
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(isSaving = false, formError = err.message ?: "Failed to save enquiry.")
                    }
                },
            )
        }
    }

    fun updateStatus(session: AuthSession, record: AdmissionEnquiryRecord, newStatus: AdmissionStatus) {
        if (session.user.role != UserRole.ADMIN) return
        val draft = AdmissionEnquiryDraft(
            id = record.id,
            recordId = record.recordId,
            studentName = record.studentName,
            guardianName = record.guardianName,
            phone = record.phone,
            email = record.email.orEmpty(),
            appliedClass = record.appliedClass,
            classId = record.classId.orEmpty(),
            enquiryDate = record.enquiryDate,
            dateOfBirth = record.dateOfBirth.orEmpty(),
            gender = record.gender.orEmpty(),
            previousSchool = record.previousSchool.orEmpty(),
            address = record.address.orEmpty(),
            status = newStatus,
            notes = record.notes.orEmpty(),
            enrolledStudentId = record.enrolledStudentId,
            rawRecordDataJson = record.rawRecordDataJson,
        )
        viewModelScope.launch {
            _uiState.update { it.copy(isMutating = true, actionError = null) }
            repository.updateEnquiry(session, record.id, draft, todayProvider()).fold(
                onSuccess = { saved ->
                    _uiState.update { state ->
                        state.copy(
                            isMutating = false,
                            selectedEnquiry = if (state.selectedEnquiry?.id == saved.id) saved else state.selectedEnquiry,
                        )
                    }
                    loadEnquiries(session)
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(isMutating = false, actionError = err.message ?: "Failed to update status.")
                    }
                },
            )
        }
    }

    fun openEnrollDialog(session: AuthSession, enquiry: AdmissionEnquiryRecord) {
        if (session.user.role != UserRole.ADMIN) return
        val matchedClass = _uiState.value.classes.firstOrNull {
            it.id == enquiry.classId || it.className.equals(enquiry.appliedClass, ignoreCase = true)
        } ?: _uiState.value.classes.firstOrNull()
        _uiState.update {
            it.copy(
                enrollDraft = AdmissionEnrollDraft(
                    enquiry = enquiry,
                    admissionNo = enquiry.recordId,
                    rollNo = "",
                    classId = matchedClass?.id.orEmpty(),
                ),
                formError = null,
            )
        }
    }

    fun updateEnrollDraft(transform: (AdmissionEnrollDraft) -> AdmissionEnrollDraft) {
        _uiState.update { state ->
            val current = state.enrollDraft ?: return@update state
            state.copy(enrollDraft = transform(current), formError = null)
        }
    }

    fun dismissEnrollDialog() {
        _uiState.update { it.copy(enrollDraft = null, formError = null) }
    }

    fun confirmEnrollStudent(session: AuthSession, successMessage: String) {
        if (session.user.role != UserRole.ADMIN) return
        val enroll = _uiState.value.enrollDraft ?: return
        val clsName = _uiState.value.classes.firstOrNull { it.id == enroll.classId }?.className
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true, formError = null, actionError = null) }
            repository.enrollEnquiryAsStudent(
                session = session,
                enquiry = enroll.enquiry,
                admissionNo = enroll.admissionNo,
                rollNo = enroll.rollNo,
                classId = enroll.classId,
                className = clsName,
                todayIso = todayProvider(),
            ).fold(
                onSuccess = { (updatedEnquiry, _) ->
                    _uiState.update { state ->
                        state.copy(
                            isSaving = false,
                            enrollDraft = null,
                            selectedEnquiry = updatedEnquiry,
                            actionMessage = successMessage,
                        )
                    }
                    loadEnquiries(session)
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(isSaving = false, formError = err.message ?: "Failed to enroll student.")
                    }
                },
            )
        }
    }

    fun requestDelete(record: AdmissionEnquiryRecord) {
        _uiState.update { it.copy(pendingDelete = record) }
    }

    fun dismissDelete() {
        _uiState.update { it.copy(pendingDelete = null) }
    }

    fun confirmDelete(session: AuthSession) {
        if (session.user.role != UserRole.ADMIN) return
        val target = _uiState.value.pendingDelete ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isMutating = true, actionError = null) }
            repository.deleteEnquiry(session, target.id).fold(
                onSuccess = {
                    _uiState.update { state ->
                        state.copy(
                            pendingDelete = null,
                            isMutating = false,
                            selectedEnquiry = if (state.selectedEnquiry?.id == target.id) null else state.selectedEnquiry,
                        )
                    }
                    loadEnquiries(session)
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            pendingDelete = null,
                            isMutating = false,
                            actionError = err.message ?: "Failed to delete enquiry.",
                        )
                    }
                },
            )
        }
    }

    fun resetSessionState() {
        searchJob?.cancel()
        lastLoadedUserId = null
        _uiState.value = AdmissionUiState()
    }

    class Factory(
        private val repository: AdmissionRepository,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return AdmissionViewModel(repository = repository) as T
        }
    }
}
