package com.example.erp.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.erp.core.i18n.AppLanguage
import com.example.erp.core.i18n.LocalAppStrings
import com.example.erp.core.model.AuthUiState
import com.example.erp.core.model.ErpModule
import com.example.erp.core.model.UserRole
import com.example.erp.features.admission.AdmissionScreen
import com.example.erp.features.admission.AdmissionUiState
import com.example.erp.features.admission.AdmissionViewModel
import com.example.erp.features.auth.LoginFormState
import com.example.erp.features.auth.LoginScreen
import com.example.erp.features.dashboard.AdminShellScreen
import com.example.erp.features.dashboard.ModuleArchitecturePreviewScreen
import com.example.erp.features.dashboard.ParentShellScreen
import com.example.erp.features.dashboard.StudentShellScreen
import com.example.erp.features.dashboard.TeacherShellScreen
import com.example.erp.features.notices.HolidaysScreen
import com.example.erp.features.notices.NoticesHolidaysUiState
import com.example.erp.features.notices.NoticesHolidaysViewModel
import com.example.erp.features.notices.NoticesScreen
import com.example.erp.features.students.StudentsScreen
import com.example.erp.features.students.StudentsUiState
import com.example.erp.features.students.StudentsViewModel
import com.example.erp.features.teachers.TeachersScreen
import com.example.erp.features.teachers.TeachersUiState
import com.example.erp.features.teachers.TeachersViewModel

@Composable
fun ErpNavHost(
    authState: AuthUiState,
    loginForm: LoginFormState,
    isSupabaseConfigured: Boolean,
    noticesHolidaysState: NoticesHolidaysUiState,
    noticesHolidaysViewModel: NoticesHolidaysViewModel,
    studentsState: StudentsUiState,
    studentsViewModel: StudentsViewModel,
    teachersState: TeachersUiState,
    teachersViewModel: TeachersViewModel,
    admissionState: AdmissionUiState,
    admissionViewModel: AdmissionViewModel,
    onLanguageSelected: (AppLanguage) -> Unit,
    onRoleSelected: (UserRole) -> Unit,
    onEmailChanged: (String) -> Unit,
    onPasswordChanged: (String) -> Unit,
    onTogglePasswordVisibility: () -> Unit,
    onSignInClick: () -> Unit,
    onForgotPasswordClick: () -> Unit,
    onDismissResetDialog: () -> Unit,
    onResetEmailChanged: (String) -> Unit,
    onSubmitPasswordReset: () -> Unit,
    onSyncProfile: () -> Unit,
    onSignOut: () -> Unit,
    navController: NavHostController = rememberNavController(),
) {
    val strings = LocalAppStrings.current

    if (authState is AuthUiState.Restoring) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                CircularProgressIndicator()
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = strings.sessionRestoring,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        return
    }

    LaunchedEffect(authState) {
        when (authState) {
            is AuthUiState.Authenticated -> {
                val target = AppRoutes.shellForRole(authState.session.user.role)
                if (navController.currentDestination?.route != target) {
                    navController.navigate(target) {
                        popUpTo(0) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            }
            AuthUiState.Unauthenticated -> {
                if (navController.currentDestination?.route != AppRoutes.LOGIN) {
                    navController.navigate(AppRoutes.LOGIN) {
                        popUpTo(0) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            }
            else -> Unit
        }
    }

    val startDestination = when (authState) {
        is AuthUiState.Authenticated -> AppRoutes.shellForRole(authState.session.user.role)
        else -> AppRoutes.LOGIN
    }

    NavHost(
        navController = navController,
        startDestination = startDestination,
    ) {
        composable(AppRoutes.LOGIN) {
            LoginScreen(
                formState = loginForm,
                isLoading = authState is AuthUiState.Loading,
                isSupabaseConfigured = isSupabaseConfigured,
                onLanguageSelected = onLanguageSelected,
                onRoleSelected = onRoleSelected,
                onEmailChanged = onEmailChanged,
                onPasswordChanged = onPasswordChanged,
                onTogglePasswordVisibility = onTogglePasswordVisibility,
                onSignInClick = onSignInClick,
                onForgotPasswordClick = onForgotPasswordClick,
                onDismissResetDialog = onDismissResetDialog,
                onResetEmailChanged = onResetEmailChanged,
                onSubmitPasswordReset = onSubmitPasswordReset,
            )
        }

        composable(AppRoutes.ADMIN_SHELL) {
            val auth = authState as? AuthUiState.Authenticated ?: return@composable
            if (auth.session.user.role != UserRole.ADMIN) return@composable
            AdminShellScreen(
                session = auth.session,
                roleNotice = auth.roleNotice,
                snapshot = auth.snapshot,
                isSyncingProfile = auth.isSyncingProfile,
                onLanguageSelected = onLanguageSelected,
                onSyncProfile = onSyncProfile,
                onOpenModule = { module -> navController.navigate(AppRoutes.moduleRoute(module)) },
                onSignOut = onSignOut,
            )
        }

        composable(AppRoutes.TEACHER_SHELL) {
            val auth = authState as? AuthUiState.Authenticated ?: return@composable
            if (auth.session.user.role != UserRole.TEACHER) return@composable
            TeacherShellScreen(
                session = auth.session,
                roleNotice = auth.roleNotice,
                snapshot = auth.snapshot,
                isSyncingProfile = auth.isSyncingProfile,
                onLanguageSelected = onLanguageSelected,
                onSyncProfile = onSyncProfile,
                onOpenModule = { module -> navController.navigate(AppRoutes.moduleRoute(module)) },
                onSignOut = onSignOut,
            )
        }

        composable(AppRoutes.STUDENT_SHELL) {
            val auth = authState as? AuthUiState.Authenticated ?: return@composable
            if (auth.session.user.role != UserRole.STUDENT) return@composable
            StudentShellScreen(
                session = auth.session,
                roleNotice = auth.roleNotice,
                snapshot = auth.snapshot,
                isSyncingProfile = auth.isSyncingProfile,
                onLanguageSelected = onLanguageSelected,
                onSyncProfile = onSyncProfile,
                onOpenModule = { module -> navController.navigate(AppRoutes.moduleRoute(module)) },
                onOpenStudentProfile = { studentId ->
                    studentsViewModel.ensureLoaded(auth.session, focusStudentId = studentId)
                    navController.navigate(AppRoutes.STUDENTS) { launchSingleTop = true }
                },
                onSignOut = onSignOut,
            )
        }

        composable(AppRoutes.PARENT_SHELL) {
            val auth = authState as? AuthUiState.Authenticated ?: return@composable
            if (auth.session.user.role != UserRole.PARENT) return@composable
            ParentShellScreen(
                session = auth.session,
                roleNotice = auth.roleNotice,
                snapshot = auth.snapshot,
                isSyncingProfile = auth.isSyncingProfile,
                onLanguageSelected = onLanguageSelected,
                onSyncProfile = onSyncProfile,
                onOpenModule = { module -> navController.navigate(AppRoutes.moduleRoute(module)) },
                onOpenStudentProfile = { studentId ->
                    studentsViewModel.ensureLoaded(auth.session, focusStudentId = studentId)
                    navController.navigate(AppRoutes.STUDENTS) { launchSingleTop = true }
                },
                onSignOut = onSignOut,
            )
        }

        composable(
            route = AppRoutes.MODULE_ROUTE_PATTERN,
            arguments = listOf(navArgument("moduleId") { type = NavType.StringType }),
        ) { backStackEntry ->
            val auth = authState as? AuthUiState.Authenticated ?: return@composable
            val module = ErpModule.fromRouteId(backStackEntry.arguments?.getString("moduleId"))
                ?: return@composable
            if (auth.session.user.role !in module.allowedRoles) return@composable
            ModuleArchitecturePreviewScreen(
                module = module,
                role = auth.session.user.role,
                onBack = { navController.popBackStack() },
            )
        }

        composable(AppRoutes.NOTICES) {
            val auth = authState as? AuthUiState.Authenticated ?: return@composable
            if (auth.session.user.role !in ErpModule.NOTICES.allowedRoles) return@composable
            NoticesScreen(
                session = auth.session,
                uiState = noticesHolidaysState,
                viewModel = noticesHolidaysViewModel,
                onLanguageSelected = onLanguageSelected,
                onOpenHolidays = {
                    navController.navigate(AppRoutes.HOLIDAYS) {
                        launchSingleTop = true
                    }
                },
                onBack = { navController.popBackStack() },
            )
        }

        composable(AppRoutes.HOLIDAYS) {
            val auth = authState as? AuthUiState.Authenticated ?: return@composable
            if (auth.session.user.role !in ErpModule.HOLIDAYS.allowedRoles) return@composable
            HolidaysScreen(
                session = auth.session,
                uiState = noticesHolidaysState,
                viewModel = noticesHolidaysViewModel,
                onLanguageSelected = onLanguageSelected,
                onOpenNotices = {
                    navController.navigate(AppRoutes.NOTICES) {
                        launchSingleTop = true
                    }
                },
                onBack = { navController.popBackStack() },
            )
        }

        composable(AppRoutes.STUDENTS) {
            val auth = authState as? AuthUiState.Authenticated ?: return@composable
            StudentsScreen(
                session = auth.session,
                uiState = studentsState,
                viewModel = studentsViewModel,
                onLanguageSelected = onLanguageSelected,
                onBack = { navController.popBackStack() },
            )
        }

        composable(AppRoutes.TEACHERS) {
            val auth = authState as? AuthUiState.Authenticated ?: return@composable
            if (auth.session.user.role !in ErpModule.TEACHERS.allowedRoles) return@composable
            TeachersScreen(
                session = auth.session,
                uiState = teachersState,
                viewModel = teachersViewModel,
                onLanguageSelected = onLanguageSelected,
                onBack = { navController.popBackStack() },
            )
        }

        composable(AppRoutes.ADMISSION) {
            val auth = authState as? AuthUiState.Authenticated ?: return@composable
            if (auth.session.user.role !in ErpModule.ADMISSION.allowedRoles) return@composable
            AdmissionScreen(
                session = auth.session,
                uiState = admissionState,
                viewModel = admissionViewModel,
                onLanguageSelected = onLanguageSelected,
                onBack = { navController.popBackStack() },
            )
        }
    }
}
