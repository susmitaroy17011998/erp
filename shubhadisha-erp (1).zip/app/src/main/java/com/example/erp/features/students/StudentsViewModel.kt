package com.example.erp.features.students

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.erp.core.model.AuthSession
import com.example.erp.core.model.GuardianLinkItem
import com.example.erp.core.model.LoadableState
import com.example.erp.core.model.ParentProfileOption
import com.example.erp.core.model.SchoolClassItem
import com.example.erp.core.model.StudentDraft
import com.example.erp.core.model.StudentRecord
import com.example.erp.core.model.StudentStatusFilter
import com.example.erp.core.model.UserRole
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

@Immutable
data class StudentsUiState(
    val classes: List<SchoolClassItem> = emptyList(),
    val studentsState: LoadableState<List<StudentRecord>> = LoadableState.Loading,
    val totalCount: Int? = null,
    val hasMore: Boolean = false,
    val isLoadingMore: Boolean = false,
    val loadMoreError: String? = null,
    val searchQuery: String = "",
    val selectedClassId: String? = null,
    val selectedStatusFilter: StudentStatusFilter = StudentStatusFilter.ALL,
    val knownColumns: Set<String> = StudentRecord.DEFAULT_CORE_COLUMNS,
    val activeDetailStudent: StudentRecord? = null,
    val detailState: LoadableState<StudentDetailPayload>? = null,
    val parentOptions: List<ParentProfileOption> = emptyList(),
    val showLinkGuardianDialog: Boolean = false,
    val isMutatingGuardian: Boolean = false,
    val editingDraft: StudentDraft? = null,
    val isSaving: Boolean = false,
    val isUploadingPhoto: Boolean = false,
    val photoUploadNotice: String? = null,
    val formError: String? = null,
    val actionError: String? = null,
)

class StudentsViewModel(
    private val repository: StudentsRepository,
    private val pageSize: Int = StudentsRepository.DEFAULT_PAGE_SIZE,
) : ViewModel() {

    private val _uiState = MutableStateFlow(StudentsUiState())
    val uiState: StateFlow<StudentsUiState> = _uiState.asStateFlow()

    private var lastLoadedUserId: String? = null
    private var searchDebounceJob: Job? = null
    private var activeLoadJob: Job? = null

    private var pendingFocusStudentId: String? = null

    fun ensureLoaded(session: AuthSession, focusStudentId: String? = null) {
        if (!focusStudentId.isNullOrBlank()) {
            pendingFocusStudentId = focusStudentId
        }
        val existingList = (_uiState.value.studentsState as? LoadableState.Success)?.items
        if (lastLoadedUserId == session.user.userId && existingList != null) {
            val targetId = pendingFocusStudentId
            if (targetId != null) {
                pendingFocusStudentId = null
                existingList.firstOrNull { it.id == targetId }?.let { openStudentProfile(session, it) }
            }
            return
        }
        lastLoadedUserId = session.user.userId
        refreshAll(session)
    }

    fun refreshAll(session: AuthSession) {
        viewModelScope.launch {
            val classResult = repository.fetchClasses(session)
            val assigned = session.user.staffInfo?.assignedClasses.orEmpty()
            if (session.user.role == UserRole.TEACHER && assigned.isNotEmpty() && classResult.isFailure) {
                _uiState.update {
                    it.copy(
                        studentsState = LoadableState.Error(
                            classResult.exceptionOrNull()?.message ?: "Failed to verify assigned classes.",
                        ),
                    )
                }
                return@launch
            }
            val allClasses = classResult.getOrDefault(emptyList())
            val visibleClasses = scopeClassesForRole(session, allClasses)
            _uiState.update { it.copy(classes = visibleClasses) }
            if (session.user.role == UserRole.TEACHER && assigned.isNotEmpty() && visibleClasses.isEmpty()) {
                _uiState.update {
                    it.copy(
                        studentsState = LoadableState.Success(emptyList()),
                        totalCount = 0,
                        hasMore = false,
                    )
                }
                return@launch
            }
            loadFirstPage(session, visibleClasses)
        }
    }

    fun refreshList(session: AuthSession) {
        loadFirstPage(session, _uiState.value.classes)
    }

    fun updateSearchQuery(session: AuthSession, query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        searchDebounceJob?.cancel()
        searchDebounceJob = viewModelScope.launch {
            delay(280L)
            loadFirstPage(session, _uiState.value.classes)
        }
    }

    fun selectClassFilter(session: AuthSession, classId: String?) {
        _uiState.update { it.copy(selectedClassId = classId) }
        loadFirstPage(session, _uiState.value.classes)
    }

    fun selectStatusFilter(session: AuthSession, filter: StudentStatusFilter) {
        if (session.user.role != UserRole.ADMIN) return
        _uiState.update { it.copy(selectedStatusFilter = filter) }
        loadFirstPage(session, _uiState.value.classes)
    }

    private fun loadFirstPage(
        session: AuthSession,
        visibleClasses: List<SchoolClassItem>,
    ) {
        activeLoadJob?.cancel()
        activeLoadJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    studentsState = LoadableState.Loading,
                    loadMoreError = null,
                    isLoadingMore = false,
                    actionError = null,
                )
            }
            val current = _uiState.value
            val allowedIds = teacherAllowedClassIds(session, visibleClasses)
            val result = repository.fetchStudentsPage(
                session = session,
                classId = current.selectedClassId,
                statusFilter = current.selectedStatusFilter,
                query = current.searchQuery,
                offset = 0,
                limit = pageSize,
                allowedClassIds = allowedIds,
            )
            result.fold(
                onSuccess = { page ->
                    _uiState.update { state ->
                        state.copy(
                            studentsState = LoadableState.Success(page.items),
                            totalCount = page.totalCount,
                            hasMore = page.hasMore,
                            knownColumns = state.knownColumns + page.detectedColumns,
                        )
                    }
                    val targetId = pendingFocusStudentId
                    pendingFocusStudentId = null
                    val focusMatch = if (!targetId.isNullOrBlank()) {
                        page.items.firstOrNull { it.id == targetId }
                    } else if (session.user.role == UserRole.STUDENT && page.items.size == 1 && _uiState.value.activeDetailStudent == null) {
                        page.items.first()
                    } else {
                        null
                    }
                    if (focusMatch != null) {
                        openStudentProfile(session, focusMatch)
                    }
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            studentsState = LoadableState.Error(err.message ?: "Failed to load students."),
                        )
                    }
                },
            )
        }
    }

    fun loadNextPage(session: AuthSession) {
        val state = _uiState.value
        val existing = (state.studentsState as? LoadableState.Success)?.items ?: return
        if (!state.hasMore || state.isLoadingMore) return

        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingMore = true, loadMoreError = null) }
            val allowedIds = teacherAllowedClassIds(session, state.classes)
            val result = repository.fetchStudentsPage(
                session = session,
                classId = state.selectedClassId,
                statusFilter = state.selectedStatusFilter,
                query = state.searchQuery,
                offset = existing.size,
                limit = pageSize,
                allowedClassIds = allowedIds,
            )
            result.fold(
                onSuccess = { page ->
                    _uiState.update { latest ->
                        val base = (latest.studentsState as? LoadableState.Success)?.items.orEmpty()
                        val merged = (base + page.items).distinctBy { it.id }
                        latest.copy(
                            studentsState = LoadableState.Success(merged),
                            totalCount = page.totalCount ?: latest.totalCount,
                            hasMore = page.hasMore,
                            isLoadingMore = false,
                            knownColumns = latest.knownColumns + page.detectedColumns,
                        )
                    }
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            isLoadingMore = false,
                            loadMoreError = err.message ?: "Failed to load more students.",
                        )
                    }
                },
            )
        }
    }

    fun openStudentProfile(session: AuthSession, student: StudentRecord) {
        _uiState.update {
            it.copy(
                activeDetailStudent = student,
                detailState = LoadableState.Loading,
                actionError = null,
            )
        }
        viewModelScope.launch {
            val result = repository.fetchStudentDetail(session, student)
            _uiState.update { state ->
                state.copy(
                    activeDetailStudent = result.getOrNull()?.student ?: state.activeDetailStudent,
                    detailState = result.fold(
                        onSuccess = { LoadableState.Success(it) },
                        onFailure = { LoadableState.Error(it.message ?: "Failed to load student details.") },
                    ),
                )
            }
        }
    }

    fun closeStudentProfile() {
        _uiState.update {
            it.copy(
                activeDetailStudent = null,
                detailState = null,
                showLinkGuardianDialog = false,
            )
        }
    }

    fun openAddStudent(session: AuthSession) {
        if (session.user.role != UserRole.ADMIN) return
        val defaultClassId = _uiState.value.selectedClassId
            ?: _uiState.value.classes.firstOrNull()?.id.orEmpty()
        _uiState.update {
            it.copy(
                editingDraft = StudentDraft(
                    classId = defaultClassId,
                    isActive = true,
                ),
                formError = null,
                photoUploadNotice = null,
            )
        }
    }

    fun openEditStudent(session: AuthSession, student: StudentRecord) {
        if (session.user.role != UserRole.ADMIN) return
        _uiState.update {
            it.copy(
                editingDraft = StudentDraft(
                    id = student.id,
                    studentName = student.studentName,
                    admissionNo = student.admissionNo.orEmpty(),
                    rollNo = student.rollNo.orEmpty(),
                    classId = student.classId.orEmpty(),
                    photoPath = student.photoPath.orEmpty(),
                    photoPreviewUrl = student.photoUrl,
                    isActive = student.isActive,
                    dateOfBirth = student.dateOfBirth.orEmpty(),
                    gender = student.gender.orEmpty(),
                    bloodGroup = student.bloodGroup.orEmpty(),
                    phone = student.phone.orEmpty(),
                    address = student.address.orEmpty(),
                    guardianName = student.guardianName.orEmpty(),
                    guardianPhone = student.guardianPhone.orEmpty(),
                ),
                formError = null,
                photoUploadNotice = null,
            )
        }
    }

    fun updateDraft(transform: (StudentDraft) -> StudentDraft) {
        _uiState.update { state ->
            val current = state.editingDraft ?: return@update state
            state.copy(editingDraft = transform(current), formError = null)
        }
    }

    fun dismissEditor() {
        _uiState.update {
            it.copy(
                editingDraft = null,
                formError = null,
                photoUploadNotice = null,
            )
        }
    }

    fun uploadDraftPhoto(
        session: AuthSession,
        imageBytes: ByteArray,
        mimeType: String,
        extension: String,
        successNotice: String,
    ) {
        if (session.user.role != UserRole.ADMIN) return
        val draft = _uiState.value.editingDraft ?: return
        val studentKey = draft.id ?: draft.admissionNo.ifBlank { draft.studentName.ifBlank { "student" } }

        viewModelScope.launch {
            _uiState.update { it.copy(isUploadingPhoto = true, formError = null, photoUploadNotice = null) }
            val result = repository.uploadStudentPhoto(
                session = session,
                studentKey = studentKey,
                imageBytes = imageBytes,
                mimeType = mimeType,
                fileExtension = extension,
            )
            result.fold(
                onSuccess = { uploaded ->
                    _uiState.update { state ->
                        state.copy(
                            isUploadingPhoto = false,
                            editingDraft = state.editingDraft?.copy(
                                photoPath = uploaded.storagePath,
                                photoPreviewUrl = uploaded.authenticatedUrl,
                            ),
                            photoUploadNotice = successNotice,
                        )
                    }
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            isUploadingPhoto = false,
                            formError = err.message ?: "Failed to upload student photo.",
                        )
                    }
                },
            )
        }
    }

    fun saveDraft(session: AuthSession, nameRequiredError: String) {
        if (session.user.role != UserRole.ADMIN) return
        val state = _uiState.value
        val draft = state.editingDraft ?: return
        if (draft.studentName.trim().isEmpty()) {
            _uiState.update { it.copy(formError = nameRequiredError) }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true, formError = null, actionError = null) }
            val result = if (draft.id == null) {
                repository.createStudent(session, draft, state.knownColumns)
            } else {
                repository.updateStudent(session, draft.id, draft, state.knownColumns)
            }
            result.fold(
                onSuccess = { saved ->
                    _uiState.update { latest ->
                        val currentList = (latest.studentsState as? LoadableState.Success)?.items.orEmpty()
                        val updatedList = if (draft.id == null) {
                            (listOf(saved) + currentList).distinctBy { it.id }
                        } else {
                            currentList.map { if (it.id == saved.id) saved else it }
                        }
                        val updatedDetail = if (latest.activeDetailStudent?.id == saved.id) {
                            val prevPayload = (latest.detailState as? LoadableState.Success)?.items
                            prevPayload?.copy(student = saved)?.let { LoadableState.Success(it) } ?: latest.detailState
                        } else {
                            latest.detailState
                        }
                        latest.copy(
                            studentsState = LoadableState.Success(updatedList),
                            totalCount = if (draft.id == null) (latest.totalCount ?: 0) + 1 else latest.totalCount,
                            activeDetailStudent = if (latest.activeDetailStudent?.id == saved.id) saved else latest.activeDetailStudent,
                            detailState = updatedDetail,
                            editingDraft = null,
                            isSaving = false,
                            photoUploadNotice = null,
                        )
                    }
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            isSaving = false,
                            formError = err.message ?: "Failed to save student record.",
                        )
                    }
                },
            )
        }
    }

    fun openLinkGuardianDialog(session: AuthSession) {
        if (session.user.role != UserRole.ADMIN) return
        _uiState.update { it.copy(showLinkGuardianDialog = true) }
        if (_uiState.value.parentOptions.isEmpty()) {
            viewModelScope.launch {
                val result = repository.fetchParentProfileOptions(session)
                result.onSuccess { options ->
                    _uiState.update { it.copy(parentOptions = options) }
                }
            }
        }
    }

    fun dismissLinkGuardianDialog() {
        _uiState.update { it.copy(showLinkGuardianDialog = false) }
    }

    fun linkGuardian(
        session: AuthSession,
        student: StudentRecord,
        parentProfileId: String,
        relationship: String,
    ) {
        if (session.user.role != UserRole.ADMIN) return
        viewModelScope.launch {
            _uiState.update { it.copy(isMutatingGuardian = true, actionError = null) }
            val result = repository.linkGuardian(session, student.id, parentProfileId, relationship)
            result.fold(
                onSuccess = {
                    _uiState.update { it.copy(isMutatingGuardian = false, showLinkGuardianDialog = false) }
                    openStudentProfile(session, student)
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            isMutatingGuardian = false,
                            actionError = err.message ?: "Failed to link guardian.",
                        )
                    }
                },
            )
        }
    }

    fun unlinkGuardian(session: AuthSession, student: StudentRecord, link: GuardianLinkItem) {
        if (session.user.role != UserRole.ADMIN) return
        viewModelScope.launch {
            _uiState.update { it.copy(isMutatingGuardian = true, actionError = null) }
            val result = repository.unlinkGuardian(session, link)
            result.fold(
                onSuccess = {
                    _uiState.update { it.copy(isMutatingGuardian = false) }
                    openStudentProfile(session, student)
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            isMutatingGuardian = false,
                            actionError = err.message ?: "Failed to remove guardian link.",
                        )
                    }
                },
            )
        }
    }

    fun resetSessionState() {
        searchDebounceJob?.cancel()
        activeLoadJob?.cancel()
        lastLoadedUserId = null
        _uiState.value = StudentsUiState()
    }

    private fun scopeClassesForRole(
        session: AuthSession,
        allClasses: List<SchoolClassItem>,
    ): List<SchoolClassItem> {
        if (session.user.role != UserRole.TEACHER) return allClasses
        val assigned = session.user.staffInfo?.assignedClasses.orEmpty()
        if (assigned.isEmpty()) return allClasses
        val normalizedAssigned = assigned.map { it.trim().lowercase() }.toSet()
        return allClasses.filter { it.className.trim().lowercase() in normalizedAssigned }
    }

    private fun teacherAllowedClassIds(
        session: AuthSession,
        visibleClasses: List<SchoolClassItem>,
    ): Set<String> {
        if (session.user.role != UserRole.TEACHER) return emptySet()
        val assigned = session.user.staffInfo?.assignedClasses.orEmpty()
        if (assigned.isEmpty()) return emptySet()
        val normalizedAssigned = assigned.map { it.trim().lowercase() }.toSet()
        return visibleClasses
            .filter { it.className.trim().lowercase() in normalizedAssigned }
            .map { it.id }
            .toSet()
    }

    class Factory(
        private val repository: StudentsRepository,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return StudentsViewModel(repository = repository) as T
        }
    }
}
