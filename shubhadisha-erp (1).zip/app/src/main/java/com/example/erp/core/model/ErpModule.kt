package com.example.erp.core.model

import com.example.erp.core.i18n.AppStrings

enum class ErpModule(
    val routeId: String,
    val allowedRoles: Set<UserRole>,
    val category: ModuleCategory,
    val isBatch1Target: Boolean = false,
) {
    NOTICES("notices", setOf(UserRole.ADMIN, UserRole.TEACHER, UserRole.STUDENT, UserRole.PARENT), ModuleCategory.COMMUNICATION, isBatch1Target = true),
    HOLIDAYS("holidays", setOf(UserRole.ADMIN, UserRole.TEACHER, UserRole.STUDENT, UserRole.PARENT), ModuleCategory.COMMUNICATION, isBatch1Target = true),
    STUDENTS("students", setOf(UserRole.ADMIN, UserRole.TEACHER), ModuleCategory.PEOPLE, isBatch1Target = true),
    TEACHERS("teachers", setOf(UserRole.ADMIN, UserRole.TEACHER), ModuleCategory.PEOPLE, isBatch1Target = true),
    ADMISSION("admission", setOf(UserRole.ADMIN), ModuleCategory.PEOPLE),
    FEES("fees", setOf(UserRole.ADMIN, UserRole.STUDENT, UserRole.PARENT), ModuleCategory.FINANCE),
    RECEIPTS("receipts", setOf(UserRole.ADMIN, UserRole.STUDENT, UserRole.PARENT), ModuleCategory.FINANCE),
    ATTENDANCE("attendance", setOf(UserRole.ADMIN, UserRole.TEACHER, UserRole.STUDENT, UserRole.PARENT), ModuleCategory.ACADEMICS),
    EXAMS("exams", setOf(UserRole.ADMIN, UserRole.TEACHER, UserRole.STUDENT, UserRole.PARENT), ModuleCategory.ACADEMICS),
    MARKSHEETS("marksheets", setOf(UserRole.ADMIN, UserRole.TEACHER, UserRole.STUDENT, UserRole.PARENT), ModuleCategory.ACADEMICS),
    CERTIFICATES("certificates", setOf(UserRole.ADMIN, UserRole.STUDENT, UserRole.PARENT), ModuleCategory.DOCUMENTS),
    ID_CARDS("id_cards", setOf(UserRole.ADMIN, UserRole.TEACHER, UserRole.STUDENT, UserRole.PARENT), ModuleCategory.DOCUMENTS),
    HOMEWORK("homework", setOf(UserRole.ADMIN, UserRole.TEACHER, UserRole.STUDENT, UserRole.PARENT), ModuleCategory.ACADEMICS),
    STUDY_MATERIALS("study_materials", setOf(UserRole.ADMIN, UserRole.TEACHER, UserRole.STUDENT, UserRole.PARENT), ModuleCategory.ACADEMICS),
    REPORTS("reports", setOf(UserRole.ADMIN, UserRole.TEACHER), ModuleCategory.ANALYTICS),
    ;

    fun title(strings: AppStrings): String = when (this) {
        NOTICES -> strings.modNotices
        HOLIDAYS -> strings.modHolidays
        STUDENTS -> strings.modStudents
        TEACHERS -> strings.modTeachers
        ADMISSION -> strings.modAdmission
        FEES -> strings.modFees
        RECEIPTS -> strings.modReceipts
        ATTENDANCE -> strings.modAttendance
        EXAMS -> strings.modExams
        MARKSHEETS -> strings.modMarksheets
        CERTIFICATES -> strings.modCertificates
        ID_CARDS -> strings.modIdCards
        HOMEWORK -> strings.modHomework
        STUDY_MATERIALS -> strings.modStudyMaterials
        REPORTS -> strings.modReports
    }

    fun subtitle(strings: AppStrings): String = when (this) {
        NOTICES -> strings.modNoticesDesc
        HOLIDAYS -> strings.modHolidaysDesc
        STUDENTS -> strings.modStudentsDesc
        TEACHERS -> strings.modTeachersDesc
        ADMISSION -> strings.modAdmissionDesc
        FEES -> strings.modFeesDesc
        RECEIPTS -> strings.modReceiptsDesc
        ATTENDANCE -> strings.modAttendanceDesc
        EXAMS -> strings.modExamsDesc
        MARKSHEETS -> strings.modMarksheetsDesc
        CERTIFICATES -> strings.modCertificatesDesc
        ID_CARDS -> strings.modIdCardsDesc
        HOMEWORK -> strings.modHomeworkDesc
        STUDY_MATERIALS -> strings.modStudyMaterialsDesc
        REPORTS -> strings.modReportsDesc
    }

    companion object {
        fun forRole(role: UserRole): List<ErpModule> =
            entries.filter { role in it.allowedRoles }

        fun fromRouteId(routeId: String?): ErpModule? =
            entries.firstOrNull { it.routeId == routeId }
    }
}

enum class ModuleCategory {
    PEOPLE,
    FINANCE,
    ACADEMICS,
    DOCUMENTS,
    COMMUNICATION,
    ANALYTICS,
}
