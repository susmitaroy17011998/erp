package com.example.erp.core.model

import androidx.compose.runtime.Immutable

enum class AdmissionStatus(val raw: String) {
    PENDING("pending"),
    REVIEWED("reviewed"),
    APPROVED("approved"),
    ADMITTED("admitted"),
    REJECTED("rejected"),
    ;

    companion object {
        fun fromRaw(value: String?): AdmissionStatus {
            val clean = value?.trim()?.lowercase().orEmpty()
            return entries.firstOrNull { it.raw == clean } ?: when (clean) {
                "new", "enquiry" -> PENDING
                "shortlisted", "verified" -> REVIEWED
                "enrolled" -> ADMITTED
                else -> PENDING
            }
        }
    }
}

@Immutable
data class AdmissionEnquiryRecord(
    val id: String,
    val schoolId: String,
    val recordId: String,
    val studentName: String,
    val guardianName: String,
    val phone: String,
    val email: String?,
    val appliedClass: String,
    val classId: String?,
    val enquiryDate: String,
    val dateOfBirth: String?,
    val gender: String?,
    val previousSchool: String?,
    val address: String?,
    val status: AdmissionStatus,
    val notes: String?,
    val enrolledStudentId: String?,
    val updatedAt: String,
    val rawRecordDataJson: String = "{}",
)

@Immutable
data class AdmissionEnquiryDraft(
    val id: String? = null,
    val recordId: String = "",
    val studentName: String = "",
    val guardianName: String = "",
    val phone: String = "",
    val email: String = "",
    val appliedClass: String = "",
    val classId: String = "",
    val enquiryDate: String = "",
    val dateOfBirth: String = "",
    val gender: String = "",
    val previousSchool: String = "",
    val address: String = "",
    val status: AdmissionStatus = AdmissionStatus.PENDING,
    val notes: String = "",
    val enrolledStudentId: String? = null,
    val rawRecordDataJson: String = "{}",
)

@Immutable
data class AdmissionEnrollDraft(
    val enquiry: AdmissionEnquiryRecord,
    val admissionNo: String = "",
    val rollNo: String = "",
    val classId: String = "",
)

enum class AdmissionStatusFilter {
    ALL,
    PENDING,
    REVIEWED,
    APPROVED,
    ADMITTED,
    REJECTED,
}
