package com.example.erp.features.students

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddAPhoto
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.erp.core.i18n.LocalAppStrings
import com.example.erp.core.model.SchoolClassItem
import com.example.erp.core.model.StudentDraft
import com.example.erp.ui.components.AuthenticatedAvatar
import com.example.ui.theme.LocalExtendedColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import kotlin.math.max

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StudentEditorDialog(
    draft: StudentDraft,
    classes: List<SchoolClassItem>,
    knownColumns: Set<String>,
    isSaving: Boolean,
    isUploadingPhoto: Boolean,
    photoUploadNotice: String?,
    errorMessage: String?,
    onDraftChange: (StudentDraft) -> Unit,
    onUploadPhotoBytes: (bytes: ByteArray, mimeType: String, extension: String) -> Unit,
    onDismiss: () -> Unit,
    onSave: () -> Unit,
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val busy = isSaving || isUploadingPhoto

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val prepared = readAndCompressImage(context, uri)
                if (prepared != null) {
                    onUploadPhotoBytes(prepared.bytes, prepared.mimeType, prepared.extension)
                }
            }
        }
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = {
            Text(if (draft.id == null) strings.addStudentTitle else strings.editStudentTitle)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    AuthenticatedAvatar(
                        photoUrl = draft.photoPreviewUrl,
                        contentDescription = draft.studentName.ifBlank { strings.studentNameLabel },
                        accentColor = MaterialTheme.colorScheme.primary,
                        fallbackIcon = Icons.Rounded.Person,
                        size = 64.dp,
                    )
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        OutlinedButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly),
                                )
                            },
                            enabled = !busy,
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 48.dp)
                                .testTag("upload_student_photo_button"),
                        ) {
                            if (isUploadingPhoto) {
                                CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(strings.uploadingPhotoLabel)
                            } else {
                                Icon(Icons.Rounded.AddAPhoto, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    if (draft.photoPath.isBlank()) strings.uploadPhotoButton else strings.changePhotoButton,
                                )
                            }
                        }
                        if (photoUploadNotice != null) {
                            Surface(
                                shape = MaterialTheme.shapes.small,
                                color = LocalExtendedColors.current.successContainer,
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.CheckCircle,
                                        contentDescription = null,
                                        tint = LocalExtendedColors.current.success,
                                        modifier = Modifier.size(14.dp),
                                    )
                                    Text(
                                        text = photoUploadNotice,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = LocalExtendedColors.current.success,
                                    )
                                }
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = draft.studentName,
                    onValueChange = { onDraftChange(draft.copy(studentName = it)) },
                    label = { Text(strings.studentNameLabel) },
                    singleLine = true,
                    enabled = !busy,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("student_editor_name"),
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    OutlinedTextField(
                        value = draft.admissionNo,
                        onValueChange = { onDraftChange(draft.copy(admissionNo = it)) },
                        label = { Text(strings.admissionNoLabel) },
                        singleLine = true,
                        enabled = !busy,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("student_editor_admission_no"),
                    )
                    OutlinedTextField(
                        value = draft.rollNo,
                        onValueChange = { onDraftChange(draft.copy(rollNo = it)) },
                        label = { Text(strings.rollNoLabel) },
                        singleLine = true,
                        enabled = !busy,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("student_editor_roll_no"),
                    )
                }

                if (classes.isNotEmpty()) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = strings.selectClassLabel,
                            style = MaterialTheme.typography.labelMedium,
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            classes.forEach { cls ->
                                FilterChip(
                                    selected = draft.classId == cls.id,
                                    onClick = { onDraftChange(draft.copy(classId = cls.id)) },
                                    label = { Text(cls.displayLabel) },
                                    modifier = Modifier.testTag("student_editor_class_${cls.id}"),
                                )
                            }
                        }
                    }
                }

                // Render schema-verified optional fields if present on the Supabase `students` table
                if ("date_of_birth" in knownColumns || "dob" in knownColumns) {
                    OutlinedTextField(
                        value = draft.dateOfBirth,
                        onValueChange = { onDraftChange(draft.copy(dateOfBirth = it)) },
                        label = { Text("${strings.dateOfBirthLabel} (YYYY-MM-DD)") },
                        singleLine = true,
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                if ("gender" in knownColumns) {
                    OutlinedTextField(
                        value = draft.gender,
                        onValueChange = { onDraftChange(draft.copy(gender = it)) },
                        label = { Text(strings.genderLabel) },
                        singleLine = true,
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                if ("blood_group" in knownColumns) {
                    OutlinedTextField(
                        value = draft.bloodGroup,
                        onValueChange = { onDraftChange(draft.copy(bloodGroup = it)) },
                        label = { Text(strings.bloodGroupLabel) },
                        singleLine = true,
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                if ("phone" in knownColumns) {
                    OutlinedTextField(
                        value = draft.phone,
                        onValueChange = { onDraftChange(draft.copy(phone = it)) },
                        label = { Text(strings.phoneLabel) },
                        singleLine = true,
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                if ("address" in knownColumns) {
                    OutlinedTextField(
                        value = draft.address,
                        onValueChange = { onDraftChange(draft.copy(address = it)) },
                        label = { Text(strings.addressLabel) },
                        minLines = 2,
                        maxLines = 3,
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                if ("guardian_name" in knownColumns) {
                    OutlinedTextField(
                        value = draft.guardianName,
                        onValueChange = { onDraftChange(draft.copy(guardianName = it)) },
                        label = { Text(strings.guardianNameLabel) },
                        singleLine = true,
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                if ("guardian_phone" in knownColumns) {
                    OutlinedTextField(
                        value = draft.guardianPhone,
                        onValueChange = { onDraftChange(draft.copy(guardianPhone = it)) },
                        label = { Text(strings.guardianPhoneLabel) },
                        singleLine = true,
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = strings.studentActiveSwitchLabel,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f),
                    )
                    Switch(
                        checked = draft.isActive,
                        onCheckedChange = { onDraftChange(draft.copy(isActive = it)) },
                        enabled = !busy,
                        modifier = Modifier.testTag("student_editor_active_switch"),
                    )
                }

                if (errorMessage != null) {
                    Text(
                        text = errorMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onSave,
                enabled = !busy,
                modifier = Modifier.testTag("save_student_button"),
            ) {
                if (isSaving) {
                    CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(16.dp))
                } else {
                    Text(strings.saveStudentButton)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !busy) {
                Text(strings.cancel)
            }
        },
    )
}

private data class PreparedImagePayload(
    val bytes: ByteArray,
    val mimeType: String,
    val extension: String,
)

private suspend fun readAndCompressImage(
    context: Context,
    uri: Uri,
): PreparedImagePayload? = withContext(Dispatchers.IO) {
    runCatching {
        val rawBytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: return@runCatching null
        if (rawBytes.isEmpty()) return@runCatching null

        val decoded = BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size)
        if (decoded != null) {
            val maxDim = 960
            val largest = max(decoded.width, decoded.height)
            val scaled = if (largest > maxDim && largest > 0) {
                val ratio = maxDim.toFloat() / largest.toFloat()
                Bitmap.createScaledBitmap(
                    decoded,
                    (decoded.width * ratio).toInt().coerceAtLeast(1),
                    (decoded.height * ratio).toInt().coerceAtLeast(1),
                    true,
                )
            } else {
                decoded
            }
            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 82, out)
            if (scaled !== decoded) scaled.recycle()
            decoded.recycle()
            PreparedImagePayload(
                bytes = out.toByteArray(),
                mimeType = "image/jpeg",
                extension = "jpg",
            )
        } else {
            val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
            val ext = when {
                mime.contains("png", ignoreCase = true) -> "png"
                mime.contains("webp", ignoreCase = true) -> "webp"
                else -> "jpg"
            }
            PreparedImagePayload(bytes = rawBytes, mimeType = mime, extension = ext)
        }
    }.getOrNull()
}
