package com.example.erp.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Assignment
import androidx.compose.material.icons.automirrored.rounded.MenuBook
import androidx.compose.material.icons.automirrored.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.AdminPanelSettings
import androidx.compose.material.icons.rounded.Analytics
import androidx.compose.material.icons.rounded.Badge
import androidx.compose.material.icons.rounded.Campaign
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.EventAvailable
import androidx.compose.material.icons.rounded.FamilyRestroom
import androidx.compose.material.icons.rounded.Grading
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.HowToReg
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PersonSearch
import androidx.compose.material.icons.rounded.Quiz
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.ImageLoader
import coil.compose.SubcomposeAsyncImage
import com.example.erp.core.i18n.AppLanguage
import com.example.erp.core.i18n.AppStrings
import com.example.erp.core.model.ErpModule
import com.example.erp.core.model.UserRole
import com.example.ui.theme.LocalExtendedColors

val LocalAuthenticatedImageLoader = staticCompositionLocalOf<ImageLoader?> { null }

@Composable
fun roleAccentColor(role: UserRole): Color {
    val extended = LocalExtendedColors.current
    return when (role) {
        UserRole.ADMIN -> extended.adminAccent
        UserRole.TEACHER -> extended.teacherAccent
        UserRole.STUDENT -> extended.studentAccent
        UserRole.PARENT -> extended.parentAccent
    }
}

fun roleIcon(role: UserRole): ImageVector = when (role) {
    UserRole.ADMIN -> Icons.Rounded.AdminPanelSettings
    UserRole.TEACHER -> Icons.Rounded.School
    UserRole.STUDENT -> Icons.AutoMirrored.Rounded.MenuBook
    UserRole.PARENT -> Icons.Rounded.FamilyRestroom
}

fun moduleIcon(module: ErpModule): ImageVector = when (module) {
    ErpModule.NOTICES -> Icons.Rounded.Campaign
    ErpModule.HOLIDAYS -> Icons.Rounded.EventAvailable
    ErpModule.STUDENTS -> Icons.Rounded.Groups
    ErpModule.TEACHERS -> Icons.Rounded.School
    ErpModule.ADMISSION -> Icons.Rounded.PersonSearch
    ErpModule.FEES -> Icons.Rounded.AccountBalanceWallet
    ErpModule.RECEIPTS -> Icons.AutoMirrored.Rounded.ReceiptLong
    ErpModule.ATTENDANCE -> Icons.Rounded.HowToReg
    ErpModule.EXAMS -> Icons.Rounded.Quiz
    ErpModule.MARKSHEETS -> Icons.Rounded.Grading
    ErpModule.CERTIFICATES -> Icons.Rounded.WorkspacePremium
    ErpModule.ID_CARDS -> Icons.Rounded.Badge
    ErpModule.HOMEWORK -> Icons.AutoMirrored.Rounded.Assignment
    ErpModule.STUDY_MATERIALS -> Icons.AutoMirrored.Rounded.MenuBook
    ErpModule.REPORTS -> Icons.Rounded.Analytics
}

@Composable
fun AuthenticatedAvatar(
    photoUrl: String?,
    contentDescription: String,
    accentColor: Color,
    fallbackIcon: ImageVector = Icons.Rounded.Person,
    size: Dp = 48.dp,
    modifier: Modifier = Modifier,
) {
    val imageLoader = LocalAuthenticatedImageLoader.current
    Surface(
        shape = CircleShape,
        color = accentColor.copy(alpha = 0.16f),
        border = BorderStroke(1.5.dp, accentColor.copy(alpha = 0.35f)),
        modifier = modifier.size(size),
    ) {
        if (!photoUrl.isNullOrBlank() && imageLoader != null) {
            SubcomposeAsyncImage(
                model = photoUrl,
                imageLoader = imageLoader,
                contentDescription = contentDescription,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
                error = {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                        Icon(
                            imageVector = fallbackIcon,
                            contentDescription = contentDescription,
                            tint = accentColor,
                            modifier = Modifier.size(size * 0.52f),
                        )
                    }
                },
            )
        } else {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                Icon(
                    imageVector = fallbackIcon,
                    contentDescription = contentDescription,
                    tint = accentColor,
                    modifier = Modifier.size(size * 0.52f),
                )
            }
        }
    }
}

@Composable
fun LanguageTogglePill(
    currentLanguage: AppLanguage,
    onLanguageSelected: (AppLanguage) -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier
            .defaultMinSize(minHeight = 48.dp)
            .testTag("language_toggle_pill"),
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.surfaceContainerLowest.copy(alpha = 0.94f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        tonalElevation = 2.dp,
    ) {
        Row(
            modifier = Modifier.padding(4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Icon(
                imageVector = Icons.Rounded.Language,
                contentDescription = "Switch language",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .padding(start = 8.dp, end = 4.dp)
                    .size(18.dp),
            )
            AppLanguage.entries.forEach { lang ->
                val isSelected = lang == currentLanguage
                val containerColor by animateColorAsState(
                    targetValue = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                    animationSpec = spring(),
                    label = "langBg",
                )
                val textColor by animateColorAsState(
                    targetValue = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                    animationSpec = spring(),
                    label = "langFg",
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(containerColor)
                        .defaultMinSize(minWidth = 48.dp, minHeight = 40.dp)
                        .clickable { onLanguageSelected(lang) }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .testTag("lang_option_${lang.code}"),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = lang.nativeLabel,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = textColor,
                    )
                }
            }
        }
    }
}

@Composable
fun SupabaseStatusBanner(
    isConfigured: Boolean,
    strings: AppStrings,
    modifier: Modifier = Modifier,
) {
    val extended = LocalExtendedColors.current
    val bgColor = if (isConfigured) extended.successContainer else extended.warningContainer
    val contentColor = if (isConfigured) extended.success else extended.warning
    val icon = if (isConfigured) Icons.Rounded.CheckCircle else Icons.Rounded.Info

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("supabase_status_banner"),
        shape = MaterialTheme.shapes.medium,
        color = bgColor.copy(alpha = 0.65f),
        border = BorderStroke(1.dp, contentColor.copy(alpha = 0.28f)),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.Top,
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(contentColor.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = contentColor,
                    modifier = Modifier.size(18.dp),
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = if (isConfigured) strings.supabaseReadyLabel else strings.supabaseMissingTitle,
                    style = MaterialTheme.typography.labelLarge,
                    color = contentColor,
                    fontWeight = FontWeight.SemiBold,
                )
                if (!isConfigured) {
                    Text(
                        text = strings.supabaseMissingBody,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                }
            }
        }
    }
}
