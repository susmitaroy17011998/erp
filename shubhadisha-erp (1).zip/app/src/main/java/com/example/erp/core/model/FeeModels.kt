package com.example.erp.core.model

import androidx.compose.runtime.Immutable

enum class FeePaymentStatus(val raw: String) {
    PENDING("pending"),
    PARTIAL("partial"),
    PAID("paid"),
    ;

    companion object {
        fun fromRaw(raw: String?, amount: Double = 0.0, paidAmount: Double = 0.0): FeePaymentStatus {
            val clean = raw?.trim()?.lowercase().orEmpty()
            return when {
                clean == "paid" || clean == "completed" -> PAID
                clean == "partial" || clean == "partially_paid" -> PARTIAL
                clean == "pending" || clean == "unpaid" -> PENDING
                amount > 0.0 && paidAmount >= amount -> PAID
                paidAmount > 0.0 -> PARTIAL
                else -> PENDING
            }
        }
    }
}

@Immutable
data class FeeRecord(
    val id: String,
    val studentId: String,
    val studentName: String,
    val admissionNo: String?,
    val rollNo: String?,
    val classId: String?,
    val className: String?,
    val feeName: String,
    val amount: Double,
    val dueDate: String?,
    val paidAmount: Double,
    val paymentDate: String?,
    val paymentStatus: FeePaymentStatus,
    val receiptNo: String?,
    val createdAt: String,
) {
    val balanceDue: Double
        get() = (amount - paidAmount).coerceAtLeast(0.0)
}

@Immutable
data class FeeDraft(
    val id: String? = null,
    val studentId: String = "",
    val feeName: String = "",
    val amount: String = "",
    val dueDate: String = "",
    val paidAmount: String = "0",
    val paymentDate: String = "",
    val paymentStatus: FeePaymentStatus = FeePaymentStatus.PENDING,
    val receiptNo: String = "",
)

@Immutable
data class FeePaymentDraft(
    val fee: FeeRecord,
    val collectAmount: String,
    val paymentDate: String,
    val receiptNo: String,
)

@Immutable
data class FeeSummaryTotals(
    val totalBilled: Double = 0.0,
    val totalCollected: Double = 0.0,
    val totalDue: Double = 0.0,
    val receiptCount: Int = 0,
)

enum class FeeStatusFilter {
    ALL,
    PENDING,
    PARTIAL,
    PAID,
}
