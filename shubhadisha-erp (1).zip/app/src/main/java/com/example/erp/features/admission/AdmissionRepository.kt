package com.example.erp.features.admission

import com.example.erp.core.model.AdmissionEnquiryDraft
import com.example.erp.core.model.AdmissionEnquiryRecord
import com.example.erp.core.model.AdmissionStatus
import com.example.erp.core.model.AdmissionStatusFilter
import com.example.erp.core.model.AuthSession
import com.example.erp.core.model.SchoolClassItem
import com.example.erp.core.model.StudentDraft
import com.example.erp.core.model.StudentRecord
import com.example.erp.core.model.UserRole
import com.example.erp.core.network.SupabaseClient
import com.example.erp.features.students.StudentsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.UUID

class AdmissionRepository(
    private val client: SupabaseClient,
    private val studentsRepository: StudentsRepository = StudentsRepository(client),
) {
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun fetchClasses(session: AuthSession): Result<List<SchoolClassItem>> =
        withContext(Dispatchers.IO) {
            runCatching {
                requireAdmin(session)
                studentsRepository.fetchClasses(session).getOrThrow()
            }
        }

    suspend fun fetchEnquiries(
        session: AuthSession,
        statusFilter: AdmissionStatusFilter = AdmissionStatusFilter.ALL,
        query: String = "",
    ): Result<List<AdmissionEnquiryRecord>> = withContext(Dispatchers.IO) {
        runCatching {
            requireAdmin(session)
            val request = client.authenticatedRequestBuilder(
                path = "/rest/v1/admission_enquiries?school_id=eq.shubhadisha&select=*&order=updated_at.desc",
                accessToken = session.accessToken,
            )
                .get()
                .build()

            val all = client.httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    error(extractRestError(body, response.code))
                }
                parseEnquiryArray(JSONArray(body))
            }

            val cleanQuery = query.trim().lowercase()
            all.filter { item ->
                val matchesStatus = when (statusFilter) {
                    AdmissionStatusFilter.ALL -> true
                    AdmissionStatusFilter.PENDING -> item.status == AdmissionStatus.PENDING
                    AdmissionStatusFilter.REVIEWED -> item.status == AdmissionStatus.REVIEWED
                    AdmissionStatusFilter.APPROVED -> item.status == AdmissionStatus.APPROVED
                    AdmissionStatusFilter.ADMITTED -> item.status == AdmissionStatus.ADMITTED
                    AdmissionStatusFilter.REJECTED -> item.status == AdmissionStatus.REJECTED
                }
                val matchesQuery = cleanQuery.isEmpty() ||
                    item.studentName.lowercase().contains(cleanQuery) ||
                    item.guardianName.lowercase().contains(cleanQuery) ||
                    item.phone.lowercase().contains(cleanQuery) ||
                    item.recordId.lowercase().contains(cleanQuery) ||
                    item.appliedClass.lowercase().contains(cleanQuery)
                matchesStatus && matchesQuery
            }
        }
    }

    suspend fun createEnquiry(
        session: AuthSession,
        draft: AdmissionEnquiryDraft,
        todayIso: String,
    ): Result<AdmissionEnquiryRecord> = withContext(Dispatchers.IO) {
        runCatching {
            requireAdmin(session)
            val recordId = draft.recordId.trim().ifEmpty {
                "ADM-${System.currentTimeMillis().toString().takeLast(6)}-${UUID.randomUUID().toString().take(4).uppercase()}"
            }
            val recordData = buildRecordDataJson(draft, todayIso)
            val payload = JSONObject().apply {
                put("school_id", "shubhadisha")
                put("record_id", recordId)
                put("record_data", recordData)
                put("created_by", session.user.userId)
            }.toString()

            val request = client.authenticatedRequestBuilder(
                path = "/rest/v1/admission_enquiries?select=*",
                accessToken = session.accessToken,
            )
                .header("Prefer", "return=representation")
                .post(payload.toRequestBody(jsonMediaType))
                .build()

            client.httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    error(extractRestError(body, response.code))
                }
                parseEnquiryArray(JSONArray(body)).firstOrNull()
                    ?: error("Enquiry saved but no row returned (check RLS).")
            }
        }
    }

    suspend fun updateEnquiry(
        session: AuthSession,
        enquiryId: String,
        draft: AdmissionEnquiryDraft,
        todayIso: String,
    ): Result<AdmissionEnquiryRecord> = withContext(Dispatchers.IO) {
        runCatching {
            requireAdmin(session)
            val recordData = buildRecordDataJson(draft, todayIso)
            val payload = JSONObject().apply {
                if (draft.recordId.isNotBlank()) {
                    put("record_id", draft.recordId.trim())
                }
                put("record_data", recordData)
            }.toString()

            val request = client.authenticatedRequestBuilder(
                path = "/rest/v1/admission_enquiries?id=eq.${encode(enquiryId)}&select=*",
                accessToken = session.accessToken,
            )
                .header("Prefer", "return=representation")
                .patch(payload.toRequestBody(jsonMediaType))
                .build()

            client.httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    error(extractRestError(body, response.code))
                }
                parseEnquiryArray(JSONArray(body)).firstOrNull()
                    ?: error("Enquiry updated but no row returned (check RLS).")
            }
        }
    }

    suspend fun deleteEnquiry(
        session: AuthSession,
        enquiryId: String,
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            requireAdmin(session)
            val request = client.authenticatedRequestBuilder(
                path = "/rest/v1/admission_enquiries?id=eq.${encode(enquiryId)}",
                accessToken = session.accessToken,
            )
                .delete()
                .build()

            client.httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    error(extractRestError(body, response.code))
                }
            }
        }
    }

    suspend fun enrollEnquiryAsStudent(
        session: AuthSession,
        enquiry: AdmissionEnquiryRecord,
        admissionNo: String,
        rollNo: String,
        classId: String,
        className: String?,
        todayIso: String,
    ): Result<Pair<AdmissionEnquiryRecord, StudentRecord>> = withContext(Dispatchers.IO) {
        runCatching {
            requireAdmin(session)
            val student = studentsRepository.createStudent(
                session = session,
                draft = StudentDraft(
                    studentName = enquiry.studentName,
                    admissionNo = admissionNo.trim(),
                    rollNo = rollNo.trim(),
                    classId = classId.trim(),
                    isActive = true,
                    dateOfBirth = enquiry.dateOfBirth.orEmpty(),
                    gender = enquiry.gender.orEmpty(),
                    phone = enquiry.phone,
                    address = enquiry.address.orEmpty(),
                    guardianName = enquiry.guardianName,
                    guardianPhone = enquiry.phone,
                ),
            ).getOrThrow()

            val updatedDraft = AdmissionEnquiryDraft(
                id = enquiry.id,
                recordId = enquiry.recordId,
                studentName = enquiry.studentName,
                guardianName = enquiry.guardianName,
                phone = enquiry.phone,
                email = enquiry.email.orEmpty(),
                appliedClass = className ?: enquiry.appliedClass,
                classId = classId,
                enquiryDate = enquiry.enquiryDate,
                dateOfBirth = enquiry.dateOfBirth.orEmpty(),
                gender = enquiry.gender.orEmpty(),
                previousSchool = enquiry.previousSchool.orEmpty(),
                address = enquiry.address.orEmpty(),
                status = AdmissionStatus.ADMITTED,
                notes = enquiry.notes.orEmpty(),
                enrolledStudentId = student.id,
                rawRecordDataJson = enquiry.rawRecordDataJson,
            )
            val updatedEnquiry = updateEnquiry(session, enquiry.id, updatedDraft, todayIso).getOrThrow()
            updatedEnquiry to student
        }
    }

    private fun requireAdmin(session: AuthSession) {
        require(session.user.role == UserRole.ADMIN) {
            "Only Admin can manage admission enquiries."
        }
    }

    private fun buildRecordDataJson(draft: AdmissionEnquiryDraft, todayIso: String): JSONObject {
        val base = runCatching { JSONObject(draft.rawRecordDataJson) }.getOrDefault(JSONObject())
        base.put("student_name", draft.studentName.trim())
        base.put("guardian_name", draft.guardianName.trim())
        base.put("phone", draft.phone.trim())
        base.put("email", draft.email.trim())
        base.put("applied_class", draft.appliedClass.trim())
        if (draft.classId.isNotBlank()) base.put("class_id", draft.classId.trim()) else base.remove("class_id")
        base.put("enquiry_date", draft.enquiryDate.trim().ifEmpty { todayIso })
        base.put("date_of_birth", draft.dateOfBirth.trim())
        base.put("gender", draft.gender.trim())
        base.put("previous_school", draft.previousSchool.trim())
        base.put("address", draft.address.trim())
        base.put("status", draft.status.raw)
        base.put("notes", draft.notes.trim())
        if (!draft.enrolledStudentId.isNullOrBlank()) {
            base.put("enrolled_student_id", draft.enrolledStudentId)
        }
        return base
    }

    private fun parseEnquiryArray(array: JSONArray): List<AdmissionEnquiryRecord> {
        val list = mutableListOf<AdmissionEnquiryRecord>()
        for (i in 0 until array.length()) {
            val row = array.getJSONObject(i)
            val id = row.optNullableString("id") ?: continue
            val data = row.optJSONObject("record_data") ?: JSONObject()
            list.add(
                AdmissionEnquiryRecord(
                    id = id,
                    schoolId = row.optString("school_id", "shubhadisha"),
                    recordId = row.optString("record_id", id.take(8)),
                    studentName = data.firstString("student_name", "studentName", "applicant_name", "name") ?: "Applicant",
                    guardianName = data.firstString("guardian_name", "guardianName", "father_name", "parent_name") ?: "",
                    phone = data.firstString("phone", "mobile", "guardian_phone", "contact") ?: "",
                    email = data.firstString("email"),
                    appliedClass = data.firstString("applied_class", "appliedClass", "class_name", "target_class") ?: "",
                    classId = data.firstString("class_id", "classId"),
                    enquiryDate = data.firstString("enquiry_date", "enquiryDate", "date") ?: row.optString("updated_at", "").take(10),
                    dateOfBirth = data.firstString("date_of_birth", "dateOfBirth", "dob"),
                    gender = data.firstString("gender"),
                    previousSchool = data.firstString("previous_school", "previousSchool"),
                    address = data.firstString("address"),
                    status = AdmissionStatus.fromRaw(data.firstString("status", "enquiry_status")),
                    notes = data.firstString("notes", "remarks"),
                    enrolledStudentId = data.firstString("enrolled_student_id", "student_id"),
                    updatedAt = row.optString("updated_at", ""),
                    rawRecordDataJson = data.toString(),
                ),
            )
        }
        return list
    }

    private fun JSONObject.firstString(vararg keys: String): String? {
        for (k in keys) {
            val v = optNullableString(k)
            if (v != null) return v
        }
        return null
    }

    private fun JSONObject.optNullableString(key: String): String? {
        if (!has(key) || isNull(key)) return null
        val value = optString(key).trim()
        return value.takeIf { it.isNotEmpty() && it != "null" }
    }

    private fun extractRestError(rawBody: String, statusCode: Int): String = runCatching {
        val json = JSONObject(rawBody)
        json.optString("message").takeIf { it.isNotBlank() }
            ?: json.optString("hint").takeIf { it.isNotBlank() }
            ?: json.optString("error").takeIf { it.isNotBlank() }
            ?: "Request failed (HTTP $statusCode)"
    }.getOrDefault("Request failed (HTTP $statusCode)")

    private fun encode(value: String): String = URLEncoder.encode(value, "UTF-8")
}
