package com.example.erp.features.notices

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.erp.core.model.AuthSession
import com.example.erp.core.model.HolidayDraft
import com.example.erp.core.model.HolidayItem
import com.example.erp.core.model.LoadableState
import com.example.erp.core.model.NoticeDraft
import com.example.erp.core.model.NoticeItem
import com.example.erp.core.model.NoticeStatusFilter
import com.example.erp.core.model.UserRole
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Immutable
data class NoticesHolidaysUiState(
    val noticesState: LoadableState<List<NoticeItem>> = LoadableState.Loading,
    val holidaysState: LoadableState<List<HolidayItem>> = LoadableState.Loading,
    val noticeSearchQuery: String = "",
    val selectedCategory: String? = null,
    val selectedStatusFilter: NoticeStatusFilter = NoticeStatusFilter.ALL,
    val holidaySearchQuery: String = "",
    val selectedHolidayType: String? = null,
    val selectedNoticeDetail: NoticeItem? = null,
    val editingNoticeDraft: NoticeDraft? = null,
    val editingHolidayDraft: HolidayDraft? = null,
    val pendingDeleteNotice: NoticeItem? = null,
    val pendingDeleteHoliday: HolidayItem? = null,
    val isSaving: Boolean = false,
    val formError: String? = null,
    val actionError: String? = null,
)

class NoticesHolidaysViewModel(
    private val repository: NoticesHolidaysRepository,
    private val todayProvider: () -> String = { currentIsoDate() },
) : ViewModel() {

    private val _uiState = MutableStateFlow(NoticesHolidaysUiState())
    val uiState: StateFlow<NoticesHolidaysUiState> = _uiState.asStateFlow()

    private var lastLoadedUserId: String? = null

    fun ensureLoaded(session: AuthSession) {
        if (lastLoadedUserId == session.user.userId &&
            _uiState.value.noticesState is LoadableState.Success &&
            _uiState.value.holidaysState is LoadableState.Success
        ) {
            return
        }
        lastLoadedUserId = session.user.userId
        refreshAll(session)
    }

    fun refreshAll(session: AuthSession) {
        refreshNotices(session)
        refreshHolidays(session)
    }

    fun refreshNotices(session: AuthSession) {
        viewModelScope.launch {
            _uiState.update { it.copy(noticesState = LoadableState.Loading, actionError = null) }
            val result = repository.fetchNotices(session)
            _uiState.update { state ->
                state.copy(
                    noticesState = result.fold(
                        onSuccess = { LoadableState.Success(it) },
                        onFailure = { LoadableState.Error(it.message ?: "Failed to load notices.") },
                    ),
                )
            }
        }
    }

    fun refreshHolidays(session: AuthSession) {
        viewModelScope.launch {
            _uiState.update { it.copy(holidaysState = LoadableState.Loading, actionError = null) }
            val result = repository.fetchHolidays(session)
            _uiState.update { state ->
                state.copy(
                    holidaysState = result.fold(
                        onSuccess = { LoadableState.Success(it) },
                        onFailure = { LoadableState.Error(it.message ?: "Failed to load holidays.") },
                    ),
                )
            }
        }
    }

    fun updateNoticeSearch(query: String) {
        _uiState.update { it.copy(noticeSearchQuery = query) }
    }

    fun selectCategory(category: String?) {
        _uiState.update { it.copy(selectedCategory = category) }
    }

    fun selectStatusFilter(filter: NoticeStatusFilter) {
        _uiState.update { it.copy(selectedStatusFilter = filter) }
    }

    fun updateHolidaySearch(query: String) {
        _uiState.update { it.copy(holidaySearchQuery = query) }
    }

    fun selectHolidayType(type: String?) {
        _uiState.update { it.copy(selectedHolidayType = type) }
    }

    fun openNoticeDetail(notice: NoticeItem) {
        _uiState.update { it.copy(selectedNoticeDetail = notice) }
    }

    fun closeNoticeDetail() {
        _uiState.update { it.copy(selectedNoticeDetail = null) }
    }

    fun openCreateNotice(session: AuthSession) {
        if (session.user.role != UserRole.ADMIN) return
        _uiState.update {
            it.copy(
                editingNoticeDraft = NoticeDraft(
                    noticeType = "General",
                    publishDate = todayProvider(),
                    isPublished = false,
                ),
                formError = null,
            )
        }
    }

    fun openEditNotice(session: AuthSession, notice: NoticeItem) {
        if (session.user.role != UserRole.ADMIN) return
        _uiState.update {
            it.copy(
                selectedNoticeDetail = null,
                editingNoticeDraft = NoticeDraft(
                    id = notice.id,
                    title = notice.title,
                    body = notice.body.orEmpty(),
                    noticeType = notice.noticeType,
                    publishDate = notice.publishDate.orEmpty(),
                    expiryDate = notice.expiryDate.orEmpty(),
                    isPublished = notice.isPublished,
                    thumbnailUrl = notice.thumbnailUrl.orEmpty(),
                ),
                formError = null,
            )
        }
    }

    fun updateNoticeDraft(transform: (NoticeDraft) -> NoticeDraft) {
        _uiState.update { state ->
            val current = state.editingNoticeDraft ?: return@update state
            state.copy(editingNoticeDraft = transform(current), formError = null)
        }
    }

    fun dismissNoticeEditor() {
        _uiState.update { it.copy(editingNoticeDraft = null, formError = null) }
    }

    fun saveNoticeDraft(session: AuthSession, titleRequiredMsg: String) {
        if (session.user.role != UserRole.ADMIN) return
        val draft = _uiState.value.editingNoticeDraft ?: return
        if (draft.title.trim().isEmpty()) {
            _uiState.update { it.copy(formError = titleRequiredMsg) }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true, formError = null, actionError = null) }
            val result = if (draft.id == null) {
                repository.createNotice(session, draft)
            } else {
                repository.updateNotice(session, draft.id, draft)
            }
            result.fold(
                onSuccess = { saved ->
                    _uiState.update { state ->
                        val existing = (state.noticesState as? LoadableState.Success)?.items.orEmpty()
                        val updated = if (draft.id == null) {
                            listOf(saved) + existing
                        } else {
                            existing.map { if (it.id == saved.id) saved else it }
                        }
                        state.copy(
                            noticesState = LoadableState.Success(updated),
                            editingNoticeDraft = null,
                            isSaving = false,
                        )
                    }
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            isSaving = false,
                            formError = err.message ?: "Failed to save notice.",
                        )
                    }
                },
            )
        }
    }

    fun toggleNoticePublish(session: AuthSession, notice: NoticeItem) {
        if (session.user.role != UserRole.ADMIN) return
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true, actionError = null) }
            val result = repository.setNoticePublished(
                session = session,
                noticeId = notice.id,
                isPublished = !notice.isPublished,
            )
            result.fold(
                onSuccess = { updatedNotice ->
                    _uiState.update { state ->
                        val existing = (state.noticesState as? LoadableState.Success)?.items.orEmpty()
                        state.copy(
                            noticesState = LoadableState.Success(
                                existing.map { if (it.id == updatedNotice.id) updatedNotice else it },
                            ),
                            selectedNoticeDetail = if (state.selectedNoticeDetail?.id == updatedNotice.id) {
                                updatedNotice
                            } else {
                                state.selectedNoticeDetail
                            },
                            isSaving = false,
                        )
                    }
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            isSaving = false,
                            actionError = err.message ?: "Failed to update publish status.",
                        )
                    }
                },
            )
        }
    }

    fun requestDeleteNotice(session: AuthSession, notice: NoticeItem) {
        if (session.user.role != UserRole.ADMIN) return
        _uiState.update { it.copy(pendingDeleteNotice = notice) }
    }

    fun dismissDeleteNotice() {
        _uiState.update { it.copy(pendingDeleteNotice = null) }
    }

    fun confirmDeleteNotice(session: AuthSession) {
        if (session.user.role != UserRole.ADMIN) return
        val target = _uiState.value.pendingDeleteNotice ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true, actionError = null) }
            val result = repository.deleteNotice(session, target.id)
            result.fold(
                onSuccess = {
                    _uiState.update { state ->
                        val existing = (state.noticesState as? LoadableState.Success)?.items.orEmpty()
                        state.copy(
                            noticesState = LoadableState.Success(existing.filterNot { it.id == target.id }),
                            pendingDeleteNotice = null,
                            selectedNoticeDetail = if (state.selectedNoticeDetail?.id == target.id) null else state.selectedNoticeDetail,
                            isSaving = false,
                        )
                    }
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            isSaving = false,
                            pendingDeleteNotice = null,
                            actionError = err.message ?: "Failed to delete notice.",
                        )
                    }
                },
            )
        }
    }

    fun openCreateHoliday(session: AuthSession) {
        if (session.user.role != UserRole.ADMIN) return
        _uiState.update {
            it.copy(
                editingHolidayDraft = HolidayDraft(
                    holidayDate = todayProvider(),
                    holidayType = "School Holiday",
                ),
                formError = null,
            )
        }
    }

    fun openEditHoliday(session: AuthSession, holiday: HolidayItem) {
        if (session.user.role != UserRole.ADMIN) return
        _uiState.update {
            it.copy(
                editingHolidayDraft = HolidayDraft(
                    id = holiday.id,
                    holidayName = holiday.holidayName,
                    holidayDate = holiday.holidayDate,
                    endDate = holiday.endDate.orEmpty(),
                    holidayType = holiday.holidayType,
                    description = holiday.description.orEmpty(),
                    schoolReopenDate = holiday.schoolReopenDate.orEmpty(),
                ),
                formError = null,
            )
        }
    }

    fun updateHolidayDraft(transform: (HolidayDraft) -> HolidayDraft) {
        _uiState.update { state ->
            val current = state.editingHolidayDraft ?: return@update state
            state.copy(editingHolidayDraft = transform(current), formError = null)
        }
    }

    fun dismissHolidayEditor() {
        _uiState.update { it.copy(editingHolidayDraft = null, formError = null) }
    }

    fun saveHolidayDraft(
        session: AuthSession,
        nameRequiredMsg: String,
        dateRequiredMsg: String,
    ) {
        if (session.user.role != UserRole.ADMIN) return
        val draft = _uiState.value.editingHolidayDraft ?: return
        if (draft.holidayName.trim().isEmpty()) {
            _uiState.update { it.copy(formError = nameRequiredMsg) }
            return
        }
        if (draft.holidayDate.trim().isEmpty()) {
            _uiState.update { it.copy(formError = dateRequiredMsg) }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true, formError = null, actionError = null) }
            val result = if (draft.id == null) {
                repository.createHoliday(session, draft)
            } else {
                repository.updateHoliday(session, draft.id, draft)
            }
            result.fold(
                onSuccess = { saved ->
                    _uiState.update { state ->
                        val existing = (state.holidaysState as? LoadableState.Success)?.items.orEmpty()
                        val updated = if (draft.id == null) {
                            (existing + saved).sortedBy { it.holidayDate }
                        } else {
                            existing.map { if (it.id == saved.id) saved else it }.sortedBy { it.holidayDate }
                        }
                        state.copy(
                            holidaysState = LoadableState.Success(updated),
                            editingHolidayDraft = null,
                            isSaving = false,
                        )
                    }
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            isSaving = false,
                            formError = err.message ?: "Failed to save holiday.",
                        )
                    }
                },
            )
        }
    }

    fun requestDeleteHoliday(session: AuthSession, holiday: HolidayItem) {
        if (session.user.role != UserRole.ADMIN) return
        _uiState.update { it.copy(pendingDeleteHoliday = holiday) }
    }

    fun dismissDeleteHoliday() {
        _uiState.update { it.copy(pendingDeleteHoliday = null) }
    }

    fun confirmDeleteHoliday(session: AuthSession) {
        if (session.user.role != UserRole.ADMIN) return
        val target = _uiState.value.pendingDeleteHoliday ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true, actionError = null) }
            val result = repository.deleteHoliday(session, target.id)
            result.fold(
                onSuccess = {
                    _uiState.update { state ->
                        val existing = (state.holidaysState as? LoadableState.Success)?.items.orEmpty()
                        state.copy(
                            holidaysState = LoadableState.Success(existing.filterNot { it.id == target.id }),
                            pendingDeleteHoliday = null,
                            isSaving = false,
                        )
                    }
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            isSaving = false,
                            pendingDeleteHoliday = null,
                            actionError = err.message ?: "Failed to delete holiday.",
                        )
                    }
                },
            )
        }
    }

    fun filterNotices(
        notices: List<NoticeItem>,
        role: UserRole,
        query: String,
        category: String?,
        statusFilter: NoticeStatusFilter,
    ): List<NoticeItem> {
        val today = todayProvider()
        val normalizedQuery = query.trim().lowercase()

        return notices.filter { notice ->
            val expired = isNoticeExpired(notice, today)
            if (role != UserRole.ADMIN) {
                if (!notice.isPublished || expired) return@filter false
            } else {
                val statusMatch = when (statusFilter) {
                    NoticeStatusFilter.ALL -> true
                    NoticeStatusFilter.PUBLISHED -> notice.isPublished && !expired
                    NoticeStatusFilter.DRAFT -> !notice.isPublished
                    NoticeStatusFilter.EXPIRED -> expired
                }
                if (!statusMatch) return@filter false
            }

            if (category != null && !notice.noticeType.equals(category, ignoreCase = true)) {
                return@filter false
            }

            if (normalizedQuery.isNotEmpty()) {
                val matchesTitle = notice.title.lowercase().contains(normalizedQuery)
                val matchesBody = notice.body?.lowercase()?.contains(normalizedQuery) == true
                val matchesType = notice.noticeType.lowercase().contains(normalizedQuery)
                if (!matchesTitle && !matchesBody && !matchesType) return@filter false
            }

            true
        }
    }

    fun filterHolidays(
        holidays: List<HolidayItem>,
        query: String,
        holidayType: String?,
    ): List<HolidayItem> {
        val normalizedQuery = query.trim().lowercase()
        return holidays.filter { holiday ->
            if (holidayType != null && !holiday.holidayType.equals(holidayType, ignoreCase = true)) {
                return@filter false
            }
            if (normalizedQuery.isNotEmpty()) {
                val matchesName = holiday.holidayName.lowercase().contains(normalizedQuery)
                val matchesDesc = holiday.description?.lowercase()?.contains(normalizedQuery) == true
                val matchesType = holiday.holidayType.lowercase().contains(normalizedQuery)
                if (!matchesName && !matchesDesc && !matchesType) return@filter false
            }
            true
        }
    }

    fun isNoticeExpired(notice: NoticeItem, todayIso: String = todayProvider()): Boolean {
        val expiry = notice.expiryDate?.takeIf { it.isNotBlank() } ?: return false
        return expiry < todayIso
    }

    fun resetSessionState() {
        lastLoadedUserId = null
        _uiState.value = NoticesHolidaysUiState()
    }

    class Factory(
        private val repository: NoticesHolidaysRepository,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return NoticesHolidaysViewModel(repository = repository) as T
        }
    }

    companion object {
        fun currentIsoDate(): String =
            SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }
}
