package com.example.erp.features.auth

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Login
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.erp.core.i18n.AppLanguage
import com.example.erp.core.i18n.LocalAppLanguage
import com.example.erp.core.i18n.LocalAppStrings
import com.example.erp.core.model.UserRole
import com.example.erp.ui.components.LanguageTogglePill
import com.example.erp.ui.components.SupabaseStatusBanner
import com.example.erp.ui.components.roleAccentColor
import com.example.erp.ui.components.roleIcon
import com.example.ui.theme.JetBrainsMonoFamily

@Composable
fun LoginScreen(
    formState: LoginFormState,
    isLoading: Boolean,
    isSupabaseConfigured: Boolean,
    onLanguageSelected: (AppLanguage) -> Unit,
    onRoleSelected: (UserRole) -> Unit,
    onEmailChanged: (String) -> Unit,
    onPasswordChanged: (String) -> Unit,
    onTogglePasswordVisibility: () -> Unit,
    onSignInClick: () -> Unit,
    onForgotPasswordClick: () -> Unit,
    onDismissResetDialog: () -> Unit,
    onResetEmailChanged: (String) -> Unit,
    onSubmitPasswordReset: () -> Unit,
) {
    val strings = LocalAppStrings.current
    val language = LocalAppLanguage.current

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
        ) {
            val isWideScreen = maxWidth >= 840.dp

            if (isWideScreen) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                ) {
                    AcademyShowcasePanel(
                        language = language,
                        onLanguageSelected = onLanguageSelected,
                        modifier = Modifier
                            .weight(1.05f)
                            .fillMaxSize(),
                    )
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .statusBarsPadding()
                            .navigationBarsPadding()
                            .imePadding()
                            .padding(horizontal = 32.dp, vertical = 24.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        LoginFormCard(
                            formState = formState,
                            isLoading = isLoading,
                            isSupabaseConfigured = isSupabaseConfigured,
                            onRoleSelected = onRoleSelected,
                            onEmailChanged = onEmailChanged,
                            onPasswordChanged = onPasswordChanged,
                            onTogglePasswordVisibility = onTogglePasswordVisibility,
                            onSignInClick = onSignInClick,
                            onForgotPasswordClick = onForgotPasswordClick,
                            modifier = Modifier.widthIn(max = 520.dp),
                        )
                    }
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .navigationBarsPadding()
                        .imePadding(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    CompactAcademyHeader(
                        language = language,
                        onLanguageSelected = onLanguageSelected,
                    )
                    LoginFormCard(
                        formState = formState,
                        isLoading = isLoading,
                        isSupabaseConfigured = isSupabaseConfigured,
                        onRoleSelected = onRoleSelected,
                        onEmailChanged = onEmailChanged,
                        onPasswordChanged = onPasswordChanged,
                        onTogglePasswordVisibility = onTogglePasswordVisibility,
                        onSignInClick = onSignInClick,
                        onForgotPasswordClick = onForgotPasswordClick,
                        modifier = Modifier
                            .widthIn(max = 560.dp)
                            .padding(horizontal = 20.dp, vertical = 16.dp),
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }

    if (formState.showResetDialog) {
        PasswordResetDialog(
            email = formState.resetEmail,
            inProgress = formState.resetInProgress,
            feedback = formState.resetFeedback,
            onEmailChanged = onResetEmailChanged,
            onDismiss = onDismissResetDialog,
            onSubmit = onSubmitPasswordReset,
        )
    }
}

@Composable
private fun CompactAcademyHeader(
    language: AppLanguage,
    onLanguageSelected: (AppLanguage) -> Unit,
) {
    val strings = LocalAppStrings.current
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(258.dp),
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_academy_banner),
            contentDescription = strings.schoolFullName,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xCC0A323D),
                            Color(0xB80F4C5C),
                            MaterialTheme.colorScheme.background,
                        ),
                    ),
                ),
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color.White.copy(alpha = 0.16f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.28f)),
                ) {
                    Text(
                        text = strings.academicSessionLabel,
                        style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFamily),
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    )
                }
                LanguageTogglePill(
                    currentLanguage = language,
                    onLanguageSelected = onLanguageSelected,
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 12.dp),
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color(0xFF0F4A5C),
                    border = BorderStroke(2.dp, Color(0xFFF6BE62)),
                    shadowElevation = 6.dp,
                    modifier = Modifier.size(64.dp),
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_app_icon_foreground),
                        contentDescription = strings.appShortName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = strings.schoolLocationTag,
                        style = MaterialTheme.typography.labelMedium,
                        color = Color(0xFFFFDEA8),
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        text = strings.schoolFullName,
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = strings.erpPortalSubtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.88f),
                    )
                }
            }
        }
    }
}

@Composable
private fun AcademyShowcasePanel(
    language: AppLanguage,
    onLanguageSelected: (AppLanguage) -> Unit,
    modifier: Modifier = Modifier,
) {
    val strings = LocalAppStrings.current
    Box(modifier = modifier) {
        Image(
            painter = painterResource(id = R.drawable.img_academy_banner),
            contentDescription = strings.schoolFullName,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xD6082932),
                            Color(0xC90F4C5C),
                            Color(0xE6092831),
                        ),
                    ),
                ),
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(36.dp),
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color.White.copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.24f)),
                ) {
                    Text(
                        text = strings.academicSessionLabel,
                        style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFamily),
                        color = Color(0xFFFFDEA8),
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    )
                }
                LanguageTogglePill(
                    currentLanguage = language,
                    onLanguageSelected = onLanguageSelected,
                )
            }

            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Surface(
                    shape = CircleShape,
                    color = Color(0xFF0F4A5C),
                    border = BorderStroke(2.dp, Color(0xFFF6BE62)),
                    modifier = Modifier.size(80.dp),
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_app_icon_foreground),
                        contentDescription = strings.appShortName,
                        contentScale = ContentScale.Crop,
                    )
                }
                Text(
                    text = strings.schoolLocationTag,
                    style = MaterialTheme.typography.labelLarge,
                    color = Color(0xFFFFDEA8),
                )
                Text(
                    text = strings.schoolFullName,
                    style = MaterialTheme.typography.displaySmall,
                    color = Color.White,
                )
                Text(
                    text = strings.erpPortalSubtitle,
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White.copy(alpha = 0.88f),
                )
            }

            Surface(
                shape = MaterialTheme.shapes.medium,
                color = Color.White.copy(alpha = 0.10f),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.VerifiedUser,
                        contentDescription = null,
                        tint = Color(0xFFFFDEA8),
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = strings.nativeArchitectureTag,
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White,
                    )
                }
            }
        }
    }
}

@Composable
private fun LoginFormCard(
    formState: LoginFormState,
    isLoading: Boolean,
    isSupabaseConfigured: Boolean,
    onRoleSelected: (UserRole) -> Unit,
    onEmailChanged: (String) -> Unit,
    onPasswordChanged: (String) -> Unit,
    onTogglePasswordVisibility: () -> Unit,
    onSignInClick: () -> Unit,
    onForgotPasswordClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val strings = LocalAppStrings.current
    val focusManager = LocalFocusManager.current

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        tonalElevation = 2.dp,
        shadowElevation = 4.dp,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = strings.signInTitle,
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    text = strings.signInSubtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            SupabaseStatusBanner(
                isConfigured = isSupabaseConfigured,
                strings = strings,
            )

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = strings.selectPortalRole,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                )

                val roles = UserRole.entries
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        RolePortalChip(
                            role = roles[0],
                            selected = formState.selectedRole == roles[0],
                            onClick = { onRoleSelected(roles[0]) },
                            modifier = Modifier.weight(1f),
                        )
                        RolePortalChip(
                            role = roles[1],
                            selected = formState.selectedRole == roles[1],
                            onClick = { onRoleSelected(roles[1]) },
                            modifier = Modifier.weight(1f),
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        RolePortalChip(
                            role = roles[2],
                            selected = formState.selectedRole == roles[2],
                            onClick = { onRoleSelected(roles[2]) },
                            modifier = Modifier.weight(1f),
                        )
                        RolePortalChip(
                            role = roles[3],
                            selected = formState.selectedRole == roles[3],
                            onClick = { onRoleSelected(roles[3]) },
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
            }

            OutlinedTextField(
                value = formState.email,
                onValueChange = onEmailChanged,
                label = { Text(strings.emailLabel) },
                placeholder = { Text(strings.emailPlaceholder) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Rounded.Email,
                        contentDescription = null,
                    )
                },
                isError = formState.emailError != null,
                supportingText = formState.emailError?.let { err -> { Text(err) } },
                singleLine = true,
                enabled = !isLoading,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email,
                    imeAction = ImeAction.Next,
                ),
                keyboardActions = KeyboardActions(
                    onNext = { focusManager.moveFocus(FocusDirection.Down) },
                ),
                shape = MaterialTheme.shapes.small,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("login_email_input"),
            )

            OutlinedTextField(
                value = formState.password,
                onValueChange = onPasswordChanged,
                label = { Text(strings.passwordLabel) },
                placeholder = { Text(strings.passwordPlaceholder) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Rounded.Lock,
                        contentDescription = null,
                    )
                },
                trailingIcon = {
                    IconButton(onClick = onTogglePasswordVisibility) {
                        Icon(
                            imageVector = if (formState.passwordVisible) {
                                Icons.Rounded.VisibilityOff
                            } else {
                                Icons.Rounded.Visibility
                            },
                            contentDescription = if (formState.passwordVisible) {
                                strings.hidePasswordDesc
                            } else {
                                strings.showPasswordDesc
                            },
                        )
                    }
                },
                visualTransformation = if (formState.passwordVisible) {
                    VisualTransformation.None
                } else {
                    PasswordVisualTransformation()
                },
                isError = formState.passwordError != null,
                supportingText = formState.passwordError?.let { err -> { Text(err) } },
                singleLine = true,
                enabled = !isLoading,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done,
                ),
                keyboardActions = KeyboardActions(
                    onDone = {
                        focusManager.clearFocus()
                        onSignInClick()
                    },
                ),
                shape = MaterialTheme.shapes.small,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("login_password_input"),
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
            ) {
                TextButton(
                    onClick = onForgotPasswordClick,
                    enabled = !isLoading,
                    modifier = Modifier.testTag("forgot_password_button"),
                ) {
                    Text(strings.forgotPassword)
                }
            }

            AnimatedVisibility(
                visible = formState.authError != null,
                enter = fadeIn(),
                exit = fadeOut(),
            ) {
                Surface(
                    shape = MaterialTheme.shapes.small,
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ErrorOutline,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = formState.authError.orEmpty(),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                        )
                    }
                }
            }

            Button(
                onClick = {
                    focusManager.clearFocus()
                    onSignInClick()
                },
                enabled = !isLoading,
                shape = MaterialTheme.shapes.medium,
                colors = ButtonDefaults.buttonColors(
                    containerColor = roleAccentColor(formState.selectedRole),
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 52.dp)
                    .testTag("login_submit_button"),
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 2.5.dp,
                        modifier = Modifier.size(20.dp),
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(strings.signingInButton)
                } else {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.Login,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp),
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = strings.signInButton,
                        style = MaterialTheme.typography.labelLarge,
                    )
                }
            }
        }
    }
}

@Composable
private fun RolePortalChip(
    role: UserRole,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val strings = LocalAppStrings.current
    val accent = roleAccentColor(role)
    val bgColor = if (selected) accent.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surfaceContainerLow
    val borderColor = if (selected) accent else MaterialTheme.colorScheme.outlineVariant

    Surface(
        modifier = modifier
            .defaultMinSize(minHeight = 56.dp)
            .clip(MaterialTheme.shapes.small)
            .clickable(onClick = onClick)
            .testTag("role_chip_${role.key}"),
        shape = MaterialTheme.shapes.small,
        color = bgColor,
        border = BorderStroke(if (selected) 1.5.dp else 1.dp, borderColor),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(if (selected) accent else MaterialTheme.colorScheme.surfaceContainerHigh),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = roleIcon(role),
                    contentDescription = null,
                    tint = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp),
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = role.label(strings),
                    style = MaterialTheme.typography.labelLarge,
                    color = if (selected) accent else MaterialTheme.colorScheme.onSurface,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = role.description(strings),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun PasswordResetDialog(
    email: String,
    inProgress: Boolean,
    feedback: String?,
    onEmailChanged: (String) -> Unit,
    onDismiss: () -> Unit,
    onSubmit: () -> Unit,
) {
    val strings = LocalAppStrings.current
    AlertDialog(
        onDismissRequest = { if (!inProgress) onDismiss() },
        title = { Text(strings.resetPasswordTitle) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = strings.resetPasswordDesc,
                    style = MaterialTheme.typography.bodyMedium,
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = onEmailChanged,
                    label = { Text(strings.emailLabel) },
                    singleLine = true,
                    enabled = !inProgress,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    modifier = Modifier.fillMaxWidth(),
                )
                if (feedback != null) {
                    Text(
                        text = feedback,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onSubmit,
                enabled = !inProgress,
            ) {
                if (inProgress) {
                    CircularProgressIndicator(
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(16.dp),
                    )
                } else {
                    Text(strings.sendResetLink)
                }
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                enabled = !inProgress,
            ) {
                Text(strings.cancel)
            }
        },
    )
}
