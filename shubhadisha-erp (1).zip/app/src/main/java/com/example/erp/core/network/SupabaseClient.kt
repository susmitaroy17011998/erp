package com.example.erp.core.network

import android.content.Context
import coil.ImageLoader
import com.example.erp.core.config.SupabaseConfig
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.logging.HttpLoggingInterceptor
import java.util.concurrent.TimeUnit

class SupabaseClient(
    val config: SupabaseConfig,
    extraInterceptor: Interceptor? = null,
) {
    private val isLegacyJwtKey: Boolean
        get() = config.anonKey.trim().startsWith("eyJ")

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BASIC
        redactHeader("apikey")
        redactHeader("Authorization")
    }

    private val apiKeyInterceptor = Interceptor { chain ->
        val original = chain.request()
        val requestBuilder = original.newBuilder()
            .header("apikey", config.anonKey.trim())
            .header("Accept", original.header("Accept") ?: "application/json")
        chain.proceed(requestBuilder.build())
    }

    val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(25, TimeUnit.SECONDS)
        .addInterceptor(apiKeyInterceptor)
        .apply { if (extraInterceptor != null) addInterceptor(extraInterceptor) }
        .addInterceptor(loggingInterceptor)
        .build()

    /**
     * Builds a request against Supabase GoTrue/PostgREST/Storage.
     * IMPORTANT: For `sb_publishable_...` keys, `Authorization: Bearer` is ONLY attached
     * when a real user JWT [accessToken] is present (or when using a legacy JWT anon key).
     */
    fun authenticatedRequestBuilder(
        path: String,
        accessToken: String? = null,
    ): Request.Builder {
        val cleanPath = if (path.startsWith("/")) path else "/$path"
        val builder = Request.Builder()
            .url("${config.normalizedBaseUrl}$cleanPath")

        val userBearer = accessToken?.takeIf { it.isNotBlank() }
        if (userBearer != null) {
            builder.header("Authorization", "Bearer $userBearer")
        } else if (isLegacyJwtKey) {
            builder.header("Authorization", "Bearer ${config.anonKey.trim()}")
        }
        return builder
    }

    /**
     * Resolves a stored file path or Supabase Storage URL in the private `school-files` bucket
     * into a full authenticated Storage URL.
     */
    fun resolveStorageUrl(rawUrlOrPath: String?): String? {
        val value = rawUrlOrPath?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        if (value.startsWith("https://") || value.startsWith("http://")) {
            return value
        }
        val cleanPath = value.trimStart('/')
        return if (cleanPath.startsWith("school-files/")) {
            "${config.normalizedBaseUrl}/storage/v1/object/authenticated/$cleanPath"
        } else {
            "${config.normalizedBaseUrl}/storage/v1/object/authenticated/school-files/$cleanPath"
        }
    }

    /**
     * Creates a Coil ImageLoader that attaches `apikey` and active user `Authorization: Bearer`
     * headers when fetching private images from Supabase Storage (`school-files`).
     */
    fun createAuthenticatedImageLoader(
        context: Context,
        accessTokenProvider: () -> String?,
    ): ImageLoader {
        val storageClient = httpClient.newBuilder()
            .addInterceptor { chain ->
                val original = chain.request()
                val reqHost = original.url.host
                val supabaseHost = runCatching {
                    java.net.URI(config.normalizedBaseUrl).host
                }.getOrNull()

                val builder = original.newBuilder()
                if (supabaseHost != null && reqHost.equals(supabaseHost, ignoreCase = true)) {
                    val token = accessTokenProvider()
                    if (!token.isNullOrBlank()) {
                        builder.header("Authorization", "Bearer $token")
                    }
                }
                chain.proceed(builder.build())
            }
            .build()

        return ImageLoader.Builder(context.applicationContext)
            .okHttpClient(storageClient)
            .crossfade(true)
            .build()
    }
}
