package com.example.erp.features.teachers

import com.example.erp.core.model.AssignedClassLink
import com.example.erp.core.model.AuthSession
import com.example.erp.core.model.LinkedAccountProfile
import com.example.erp.core.model.SchoolClassItem
import com.example.erp.core.model.StaffDraft
import com.example.erp.core.model.StaffProfileOption
import com.example.erp.core.model.StaffRecord
import com.example.erp.core.model.StaffRoutineSlot
import com.example.erp.core.model.StaffStatusFilter
import com.example.erp.core.model.UserRole
import com.example.erp.core.network.SupabaseClient
import com.example.erp.features.students.UploadedPhotoResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

data class StaffPage(
    val items: List<StaffRecord>,
    val totalCount: Int?,
    val hasMore: Boolean,
    val detectedColumns: Set<String>,
)

data class StaffDetailPayload(
    val staff: StaffRecord,
    val linkedProfile: LinkedAccountProfile?,
    val assignedClasses: List<AssignedClassLink>,
    val routineSlots: List<StaffRoutineSlot>,
)

class TeachersRepository(
    private val client: SupabaseClient,
) {
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun fetchClasses(session: AuthSession): Result<List<SchoolClassItem>> =
        withContext(Dispatchers.IO) {
            runCatching {
                requireStaffDirectoryAccess(session)
                val request = client.authenticatedRequestBuilder(
                    path = "/rest/v1/classes?select=*&order=class_name.asc",
                    accessToken = session.accessToken,
                )
                    .get()
                    .build()
                client.httpClient.newCall(request).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        error(extractRestError(body, response.code))
                    }
                    parseClassArray(JSONArray(body))
                }
            }
        }

    suspend fun fetchStaffPage(
        session: AuthSession,
        designationFilter: String? = null,
        statusFilter: StaffStatusFilter = StaffStatusFilter.ALL,
        query: String = "",
        offset: Int = 0,
        limit: Int = DEFAULT_PAGE_SIZE,
    ): Result<StaffPage> = withContext(Dispatchers.IO) {
        runCatching {
            requireStaffDirectoryAccess(session)
            val role = session.user.role
            val safeOffset = offset.coerceAtLeast(0)
            val safeLimit = limit.coerceIn(1, 100)
            val params = mutableListOf(
                "select=*",
                "order=staff_name.asc,id.asc",
            )

            if (role == UserRole.TEACHER) {
                params.add("is_active=eq.true")
            } else {
                when (statusFilter) {
                    StaffStatusFilter.ALL -> Unit
                    StaffStatusFilter.ACTIVE -> params.add("is_active=eq.true")
                    StaffStatusFilter.INACTIVE -> params.add("is_active=eq.false")
                }
            }

            val cleanDesig = designationFilter?.trim()?.takeIf { it.isNotEmpty() }
            if (cleanDesig != null) {
                params.add("designation=eq.${encode(cleanDesig)}")
            }

            val cleanQuery = sanitizeSearchQuery(query)
            if (cleanQuery.isNotEmpty()) {
                val pattern = encode("*$cleanQuery*")
                params.add("or=(staff_name.ilike.$pattern,designation.ilike.$pattern,phone.ilike.$pattern)")
            }

            val rangeEnd = safeOffset + safeLimit - 1
            val request = client.authenticatedRequestBuilder(
                path = "/rest/v1/staff?${params.joinToString("&")}",
                accessToken = session.accessToken,
            )
                .header("Prefer", "count=exact")
                .header("Range", "$safeOffset-$rangeEnd")
                .get()
                .build()

            client.httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    error(extractRestError(body, response.code))
                }
                val parsed = parseStaffArray(JSONArray(body))
                val totalCount = parseContentRangeTotal(response.header("Content-Range"))
                val hasMore = when {
                    totalCount != null -> (safeOffset + parsed.first.size) < totalCount
                    else -> parsed.first.size >= safeLimit
                }
                StaffPage(
                    items = parsed.first,
                    totalCount = totalCount ?: (safeOffset + parsed.first.size),
                    hasMore = hasMore,
                    detectedColumns = parsed.second,
                )
            }
        }
    }

    suspend fun fetchStaffDetail(
        session: AuthSession,
        staff: StaffRecord,
    ): Result<StaffDetailPayload> = withContext(Dispatchers.IO) {
        runCatching {
            requireStaffDirectoryAccess(session)
            val freshStaff = fetchSingleStaff(session, staff.id) ?: staff
            if (session.user.role == UserRole.TEACHER) {
                require(freshStaff.isActive) { "Teachers can only view active staff records." }
            }

            val profileId = freshStaff.profileId?.takeIf { it.isNotBlank() }
            val linkedProfile = if (profileId != null) {
                fetchProfileById(session.accessToken, profileId)
            } else {
                null
            }

            val assignedClasses = if (profileId != null) {
                fetchAssignedClasses(session.accessToken, profileId)
            } else {
                emptyList()
            }

            val routineSlots = fetchTeacherRoutines(session.accessToken, freshStaff.staffName)

            StaffDetailPayload(
                staff = freshStaff,
                linkedProfile = linkedProfile,
                assignedClasses = assignedClasses,
                routineSlots = routineSlots,
            )
        }
    }

    suspend fun fetchTeacherProfileOptions(session: AuthSession): Result<List<StaffProfileOption>> =
        withContext(Dispatchers.IO) {
            runCatching {
                require(session.user.role == UserRole.ADMIN) {
                    "Only Admin can browse staff login profiles."
                }
                val rows = getJsonArray(
                    path = "/rest/v1/profiles?role=in.(admin,teacher)&is_active=eq.true&select=id,full_name,role,phone&order=full_name.asc",
                    accessToken = session.accessToken,
                ) ?: JSONArray()

                buildList {
                    for (i in 0 until rows.length()) {
                        val obj = rows.getJSONObject(i)
                        val id = obj.optNullableString("id") ?: continue
                        add(
                            StaffProfileOption(
                                id = id,
                                fullName = obj.optNullableString("full_name") ?: "Staff",
                                role = obj.optNullableString("role") ?: "teacher",
                                phone = obj.optNullableString("phone"),
                            ),
                        )
                    }
                }
            }
        }

    suspend fun createStaff(
        session: AuthSession,
        draft: StaffDraft,
        knownColumns: Set<String> = StaffRecord.DEFAULT_CORE_COLUMNS,
    ): Result<StaffRecord> = withContext(Dispatchers.IO) {
        runCatching {
            require(session.user.role == UserRole.ADMIN) {
                "Only Admin can add staff records."
            }
            val payload = staffPayload(draft, knownColumns)
            executeWriteWithSchemaFallback(
                method = "POST",
                path = "/rest/v1/staff?select=*",
                accessToken = session.accessToken,
                payload = payload,
            )
        }
    }

    suspend fun updateStaff(
        session: AuthSession,
        staffId: String,
        draft: StaffDraft,
        knownColumns: Set<String> = StaffRecord.DEFAULT_CORE_COLUMNS,
    ): Result<StaffRecord> = withContext(Dispatchers.IO) {
        runCatching {
            require(session.user.role == UserRole.ADMIN) {
                "Only Admin can edit staff records."
            }
            val payload = staffPayload(draft, knownColumns)
            executeWriteWithSchemaFallback(
                method = "PATCH",
                path = "/rest/v1/staff?id=eq.${encode(staffId)}&select=*",
                accessToken = session.accessToken,
                payload = payload,
            )
        }
    }

    suspend fun uploadStaffPhoto(
        session: AuthSession,
        staffKey: String,
        imageBytes: ByteArray,
        mimeType: String = "image/jpeg",
        fileExtension: String = "jpg",
        timestampMillis: Long = System.currentTimeMillis(),
    ): Result<UploadedPhotoResult> = withContext(Dispatchers.IO) {
        runCatching {
            require(session.user.role == UserRole.ADMIN) {
                "Only Admin can upload staff photos."
            }
            require(imageBytes.isNotEmpty()) { "Selected image file is empty." }

            val cleanKey = staffKey.trim()
                .replace(Regex("[^a-zA-Z0-9_-]"), "_")
                .ifBlank { "staff" }
            val cleanExt = fileExtension.trim().lowercase()
                .replace(Regex("[^a-z0-9]"), "")
                .ifBlank { "jpg" }
            val storagePath = "staff/${cleanKey}_$timestampMillis.$cleanExt"

            val request = client.authenticatedRequestBuilder(
                path = "/storage/v1/object/school-files/$storagePath",
                accessToken = session.accessToken,
            )
                .header("x-upsert", "true")
                .header("Content-Type", mimeType)
                .post(imageBytes.toRequestBody(mimeType.toMediaType()))
                .build()

            client.httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    error(extractRestError(body, response.code))
                }
            }

            val resolvedUrl = client.resolveStorageUrl(storagePath)
                ?: error("Could not resolve authenticated storage URL.")
            UploadedPhotoResult(
                storagePath = storagePath,
                authenticatedUrl = resolvedUrl,
            )
        }
    }

    suspend fun assignClassTeacher(
        session: AuthSession,
        teacherProfileId: String,
        classId: String,
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            require(session.user.role == UserRole.ADMIN) {
                "Only Admin can assign class teachers."
            }
            require(teacherProfileId.isNotBlank()) { "Link a staff portal profile first." }
            val payload = JSONObject().apply {
                put("teacher_profile_id", teacherProfileId)
                put("class_id", classId)
            }.toString()

            val request = client.authenticatedRequestBuilder(
                path = "/rest/v1/class_teachers",
                accessToken = session.accessToken,
            )
                .header("Prefer", "return=representation")
                .post(payload.toRequestBody(jsonMediaType))
                .build()

            client.httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    error(extractRestError(body, response.code))
                }
            }
        }
    }

    suspend fun removeClassTeacher(
        session: AuthSession,
        link: AssignedClassLink,
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            require(session.user.role == UserRole.ADMIN) {
                "Only Admin can remove class teacher assignments."
            }
            val path = if (!link.id.isNullOrBlank()) {
                "/rest/v1/class_teachers?id=eq.${encode(link.id)}"
            } else {
                "/rest/v1/class_teachers?teacher_profile_id=eq.${encode(link.teacherProfileId)}&class_id=eq.${encode(link.classId)}"
            }
            val request = client.authenticatedRequestBuilder(
                path = path,
                accessToken = session.accessToken,
            )
                .delete()
                .build()

            client.httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    error(extractRestError(body, response.code))
                }
            }
        }
    }

    private fun requireStaffDirectoryAccess(session: AuthSession) {
        require(session.user.role == UserRole.ADMIN || session.user.role == UserRole.TEACHER) {
            "Students and Parents cannot access staff directory records."
        }
    }

    private fun executeWriteWithSchemaFallback(
        method: String,
        path: String,
        accessToken: String,
        payload: JSONObject,
    ): StaffRecord {
        val workingPayload = JSONObject(payload.toString())
        repeat(4) {
            val builder = client.authenticatedRequestBuilder(
                path = path,
                accessToken = accessToken,
            )
                .header("Prefer", "return=representation")
            val bodyObj = workingPayload.toString().toRequestBody(jsonMediaType)
            val request = if (method == "POST") {
                builder.post(bodyObj).build()
            } else {
                builder.patch(bodyObj).build()
            }

            client.httpClient.newCall(request).execute().use { response ->
                val rawBody = response.body?.string().orEmpty()
                if (response.isSuccessful) {
                    val parsed = parseStaffArray(JSONArray(rawBody))
                    return parsed.first.firstOrNull()
                        ?: error("Operation completed but no staff row was returned (check RLS).")
                }
                val missingCol = extractMissingColumnName(rawBody)
                if (missingCol != null && workingPayload.has(missingCol)) {
                    workingPayload.remove(missingCol)
                } else {
                    error(extractRestError(rawBody, response.code))
                }
            }
        }
        error("Failed to save staff record after schema fallback.")
    }

    private fun fetchSingleStaff(session: AuthSession, staffId: String): StaffRecord? {
        val rows = getJsonArray(
            path = "/rest/v1/staff?id=eq.${encode(staffId)}&select=*&limit=1",
            accessToken = session.accessToken,
        ) ?: return null
        return parseStaffArray(rows).first.firstOrNull()
    }

    private fun fetchProfileById(accessToken: String, profileId: String): LinkedAccountProfile? {
        val rows = getJsonArray(
            path = "/rest/v1/profiles?id=eq.${encode(profileId)}&select=id,full_name,phone,role,is_active&limit=1",
            accessToken = accessToken,
        ) ?: return null
        if (rows.length() == 0) return null
        val p = rows.getJSONObject(0)
        return LinkedAccountProfile(
            id = p.optNullableString("id") ?: profileId,
            fullName = p.optNullableString("full_name") ?: "",
            phone = p.optNullableString("phone"),
            role = p.optNullableString("role"),
            isActive = p.optBoolean("is_active", true),
        )
    }

    private fun fetchAssignedClasses(
        accessToken: String,
        teacherProfileId: String,
    ): List<AssignedClassLink> {
        val rows = getJsonArray(
            path = "/rest/v1/class_teachers?teacher_profile_id=eq.${encode(teacherProfileId)}&select=id,teacher_profile_id,class_id,classes(id,class_name,section)",
            accessToken = accessToken,
        ) ?: return emptyList()
        return buildList {
            for (i in 0 until rows.length()) {
                val obj = rows.getJSONObject(i)
                val cls = obj.optJSONObject("classes")
                val classId = obj.optNullableString("class_id") ?: cls?.optNullableString("id") ?: continue
                val className = cls?.optNullableString("class_name")
                    ?: cls?.optNullableString("name")
                    ?: classId
                add(
                    AssignedClassLink(
                        id = obj.optNullableString("id"),
                        teacherProfileId = teacherProfileId,
                        classId = classId,
                        className = className,
                        section = cls?.optNullableString("section"),
                    ),
                )
            }
        }
    }

    private fun fetchTeacherRoutines(
        accessToken: String,
        staffName: String,
    ): List<StaffRoutineSlot> {
        val cleanName = sanitizeSearchQuery(staffName)
        if (cleanName.isBlank()) return emptyList()
        val rows = getJsonArray(
            path = "/rest/v1/class_routines?teacher=ilike.${encode("*$cleanName*")}&select=*&order=day.asc,period.asc",
            accessToken = accessToken,
        ) ?: return emptyList()
        return buildList {
            for (i in 0 until rows.length()) {
                val obj = rows.getJSONObject(i)
                add(
                    StaffRoutineSlot(
                        id = obj.optNullableString("id") ?: "$i",
                        day = obj.optString("day", ""),
                        className = obj.optString("class_name", ""),
                        period = obj.optInt("period", 0),
                        subject = obj.optString("subject", ""),
                        teacher = obj.optString("teacher", ""),
                        routineTime = obj.optString("routine_time", ""),
                        room = obj.optString("room", ""),
                    ),
                )
            }
        }
    }

    private fun staffPayload(
        draft: StaffDraft,
        knownColumns: Set<String>,
    ): JSONObject = JSONObject().apply {
        put("staff_name", draft.staffName.trim())
        put("designation", draft.designation.trim().ifEmpty { "Teacher" })
        put("phone", draft.phone.trim().ifEmpty { JSONObject.NULL })
        put("joining_date", draft.joiningDate.trim().ifEmpty { JSONObject.NULL })
        put("photo_url", draft.photoPath.trim().ifEmpty { JSONObject.NULL })
        put("is_active", draft.isActive)
        if ("profile_id" in knownColumns) {
            put("profile_id", draft.profileId.trim().ifEmpty { JSONObject.NULL })
        }
    }

    private fun parseClassArray(array: JSONArray): List<SchoolClassItem> {
        val list = mutableListOf<SchoolClassItem>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val id = obj.optNullableString("id") ?: continue
            val name = obj.optNullableString("class_name")
                ?: obj.optNullableString("name")
                ?: continue
            list.add(
                SchoolClassItem(
                    id = id,
                    className = name,
                    section = obj.optNullableString("section"),
                    academicYear = obj.optNullableString("academic_year"),
                ),
            )
        }
        return list
    }

    private fun parseStaffArray(array: JSONArray): Pair<List<StaffRecord>, Set<String>> {
        val list = mutableListOf<StaffRecord>()
        val columns = linkedSetOf<String>().apply { addAll(StaffRecord.DEFAULT_CORE_COLUMNS) }
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val id = obj.optNullableString("id") ?: continue
            val keys = obj.keys()
            val extra = linkedMapOf<String, String>()
            while (keys.hasNext()) {
                val key = keys.next()
                columns.add(key)
                if (key !in HANDLED_STAFF_KEYS) {
                    val v = obj.optNullableString(key)
                    if (v != null) extra[key] = v
                }
            }
            val rawPhoto = obj.optNullableString("photo_url")
            list.add(
                StaffRecord(
                    id = id,
                    profileId = obj.optNullableString("profile_id"),
                    staffName = obj.optNullableString("staff_name") ?: "",
                    designation = obj.optNullableString("designation") ?: "Teacher",
                    phone = obj.optNullableString("phone"),
                    joiningDate = obj.optNullableString("joining_date"),
                    photoPath = rawPhoto,
                    photoUrl = client.resolveStorageUrl(rawPhoto),
                    isActive = obj.optBoolean("is_active", true),
                    createdAt = obj.optString("created_at", ""),
                    extraFields = extra,
                    knownColumns = columns.toSet(),
                ),
            )
        }
        return list to columns.toSet()
    }

    private fun getJsonArray(path: String, accessToken: String): JSONArray? {
        val request = client.authenticatedRequestBuilder(path = path, accessToken = accessToken)
            .get()
            .build()
        return runCatching {
            client.httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val body = response.body?.string().orEmpty()
                if (body.isBlank()) null else JSONArray(body)
            }
        }.getOrNull()
    }

    private fun parseContentRangeTotal(contentRange: String?): Int? {
        if (contentRange.isNullOrBlank()) return null
        val totalPart = contentRange.substringAfter("/", "").trim()
        return if (totalPart == "*" || totalPart.isEmpty()) null else totalPart.toIntOrNull()
    }

    private fun sanitizeSearchQuery(raw: String): String =
        raw.trim().replace(Regex("[,()*\\\\]"), " ").trim()

    private fun extractMissingColumnName(rawBody: String): String? = runCatching {
        val json = JSONObject(rawBody)
        val code = json.optString("code")
        val message = json.optString("message")
        if (code == "PGRST204" || message.contains("Could not find the", ignoreCase = true)) {
            Regex("'([^']+)' column").find(message)?.groupValues?.getOrNull(1)
        } else {
            null
        }
    }.getOrNull()

    private fun JSONObject.optNullableString(key: String): String? {
        if (!has(key) || isNull(key)) return null
        val value = optString(key).trim()
        return value.takeIf { it.isNotEmpty() && it != "null" }
    }

    private fun extractRestError(rawBody: String, statusCode: Int): String = runCatching {
        val json = JSONObject(rawBody)
        json.optString("message").takeIf { it.isNotBlank() }
            ?: json.optString("hint").takeIf { it.isNotBlank() }
            ?: json.optString("error").takeIf { it.isNotBlank() }
            ?: "Request failed (HTTP $statusCode)"
    }.getOrDefault("Request failed (HTTP $statusCode)")

    private fun encode(value: String): String = URLEncoder.encode(value, "UTF-8")

    companion object {
        const val DEFAULT_PAGE_SIZE = 20

        private val HANDLED_STAFF_KEYS = setOf(
            "id",
            "profile_id",
            "staff_name",
            "designation",
            "phone",
            "joining_date",
            "photo_url",
            "is_active",
            "created_at",
            "updated_at",
        )
    }
}
