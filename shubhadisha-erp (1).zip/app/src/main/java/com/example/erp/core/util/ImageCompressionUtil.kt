package com.example.erp.core.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import kotlin.math.max

data class PreparedBinaryPayload(
    val bytes: ByteArray,
    val mimeType: String,
    val extension: String,
    val displayName: String,
)

object ImageCompressionUtil {
    suspend fun readAndCompressImage(
        context: Context,
        uri: Uri,
        maxDimensionPx: Int = 960,
        jpegQuality: Int = 82,
    ): PreparedBinaryPayload? = withContext(Dispatchers.IO) {
        runCatching {
            val rawBytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: return@runCatching null
            if (rawBytes.isEmpty()) return@runCatching null

            val decoded = BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size)
            if (decoded != null) {
                val largest = max(decoded.width, decoded.height)
                val scaled = if (largest > maxDimensionPx && largest > 0) {
                    val ratio = maxDimensionPx.toFloat() / largest.toFloat()
                    Bitmap.createScaledBitmap(
                        decoded,
                        (decoded.width * ratio).toInt().coerceAtLeast(1),
                        (decoded.height * ratio).toInt().coerceAtLeast(1),
                        true,
                    )
                } else {
                    decoded
                }
                val out = ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, jpegQuality, out)
                if (scaled !== decoded) scaled.recycle()
                decoded.recycle()
                PreparedBinaryPayload(
                    bytes = out.toByteArray(),
                    mimeType = "image/jpeg",
                    extension = "jpg",
                    displayName = "photo.jpg",
                )
            } else {
                val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
                val ext = when {
                    mime.contains("png", ignoreCase = true) -> "png"
                    mime.contains("webp", ignoreCase = true) -> "webp"
                    else -> "jpg"
                }
                PreparedBinaryPayload(
                    bytes = rawBytes,
                    mimeType = mime,
                    extension = ext,
                    displayName = "photo.$ext",
                )
            }
        }.getOrNull()
    }

    suspend fun readDocumentBytes(
        context: Context,
        uri: Uri,
        maxBytes: Int = 10 * 1024 * 1024,
    ): PreparedBinaryPayload? = withContext(Dispatchers.IO) {
        runCatching {
            val mime = context.contentResolver.getType(uri) ?: "application/octet-stream"
            val rawBytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: return@runCatching null
            if (rawBytes.isEmpty() || rawBytes.size > maxBytes) return@runCatching null
            val ext = when {
                mime.contains("pdf", ignoreCase = true) -> "pdf"
                mime.contains("png", ignoreCase = true) -> "png"
                mime.contains("webp", ignoreCase = true) -> "webp"
                mime.contains("jpeg", ignoreCase = true) || mime.contains("jpg", ignoreCase = true) -> "jpg"
                else -> "bin"
            }
            val lastSeg = uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.isNotBlank() }
                ?: "attachment.$ext"
            PreparedBinaryPayload(
                bytes = rawBytes,
                mimeType = mime,
                extension = ext,
                displayName = lastSeg,
            )
        }.getOrNull()
    }
}
