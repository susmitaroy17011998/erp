package com.example.erp.features.fees

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.erp.core.model.AuthSession
import com.example.erp.core.model.FeeDraft
import com.example.erp.core.model.FeePaymentDraft
import com.example.erp.core.model.FeePaymentStatus
import com.example.erp.core.model.FeeRecord
import com.example.erp.core.model.FeeStatusFilter
import com.example.erp.core.model.FeeSummaryTotals
import com.example.erp.core.model.LoadableState
import com.example.erp.core.model.SchoolClassItem
import com.example.erp.core.model.StudentRecord
import com.example.erp.core.model.UserRole
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Immutable
data class FeesUiState(
    val classes: List<SchoolClassItem> = emptyList(),
    val selectableStudents: List<StudentRecord> = emptyList(),
    val feesState: LoadableState<List<FeeRecord>> = LoadableState.Loading,
    val summary: FeeSummaryTotals = FeeSummaryTotals(),
    val selectedClassId: String? = null,
    val selectedWardId: String? = null,
    val statusFilter: FeeStatusFilter = FeeStatusFilter.ALL,
    val searchQuery: String = "",
    val editingDraft: FeeDraft? = null,
    val paymentDraft: FeePaymentDraft? = null,
    val pendingDelete: FeeRecord? = null,
    val isSaving: Boolean = false,
    val formError: String? = null,
    val actionError: String? = null,
)

class FeesViewModel(
    private val repository: FeesRepository,
    private val todayProvider: () -> String = {
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    },
) : ViewModel() {

    private val _uiState = MutableStateFlow(FeesUiState())
    val uiState: StateFlow<FeesUiState> = _uiState.asStateFlow()

    private var lastLoadedUserId: String? = null
    private var searchJob: Job? = null

    fun ensureLoaded(session: AuthSession) {
        val existing = (_uiState.value.feesState as? LoadableState.Success)?.items
        if (lastLoadedUserId == session.user.userId && existing != null) return
        lastLoadedUserId = session.user.userId
        refreshAll(session)
    }

    fun refreshAll(session: AuthSession) {
        viewModelScope.launch {
            if (session.user.role == UserRole.ADMIN) {
                repository.fetchClasses(session).onSuccess { list ->
                    _uiState.update { it.copy(classes = list) }
                }
                repository.fetchSelectableStudents(session).onSuccess { list ->
                    _uiState.update { it.copy(selectableStudents = list) }
                }
            }
            loadFees(session)
        }
    }

    fun selectClassFilter(session: AuthSession, classId: String?) {
        _uiState.update { it.copy(selectedClassId = classId) }
        loadFees(session)
    }

    fun selectWardFilter(session: AuthSession, studentId: String?) {
        _uiState.update { it.copy(selectedWardId = studentId) }
        loadFees(session)
    }

    fun selectStatusFilter(session: AuthSession, filter: FeeStatusFilter) {
        _uiState.update { it.copy(statusFilter = filter) }
        loadFees(session)
    }

    fun updateSearchQuery(session: AuthSession, query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            delay(250L)
            loadFees(session)
        }
    }

    fun loadFees(session: AuthSession) {
        viewModelScope.launch {
            _uiState.update { it.copy(feesState = LoadableState.Loading, actionError = null) }
            val current = _uiState.value
            repository.fetchFees(
                session = session,
                classId = current.selectedClassId,
                studentFilterId = current.selectedWardId,
                statusFilter = current.statusFilter,
                query = current.searchQuery,
            ).fold(
                onSuccess = { items ->
                    val summary = FeeSummaryTotals(
                        totalBilled = items.sumOf { it.amount },
                        totalCollected = items.sumOf { it.paidAmount },
                        totalDue = items.sumOf { it.balanceDue },
                        receiptCount = items.count { it.paidAmount > 0.0 || !it.receiptNo.isNullOrBlank() },
                    )
                    _uiState.update {
                        it.copy(
                            feesState = LoadableState.Success(items),
                            summary = summary,
                        )
                    }
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(feesState = LoadableState.Error(err.message ?: "Failed to load fees."))
                    }
                },
            )
        }
    }

    fun openCreateFee(session: AuthSession) {
        if (session.user.role != UserRole.ADMIN) return
        val firstStudent = _uiState.value.selectableStudents.firstOrNull()?.id.orEmpty()
        _uiState.update {
            it.copy(
                editingDraft = FeeDraft(
                    studentId = firstStudent,
                    dueDate = todayProvider(),
                ),
                formError = null,
            )
        }
    }

    fun openEditFee(session: AuthSession, fee: FeeRecord) {
        if (session.user.role != UserRole.ADMIN) return
        _uiState.update {
            it.copy(
                editingDraft = FeeDraft(
                    id = fee.id,
                    studentId = fee.studentId,
                    feeName = fee.feeName,
                    amount = fee.amount.toString(),
                    dueDate = fee.dueDate.orEmpty(),
                    paidAmount = fee.paidAmount.toString(),
                    paymentDate = fee.paymentDate.orEmpty(),
                    paymentStatus = fee.paymentStatus,
                    receiptNo = fee.receiptNo.orEmpty(),
                ),
                formError = null,
            )
        }
    }

    fun updateDraft(transform: (FeeDraft) -> FeeDraft) {
        _uiState.update { state ->
            val current = state.editingDraft ?: return@update state
            state.copy(editingDraft = transform(current), formError = null)
        }
    }

    fun dismissEditor() {
        _uiState.update { it.copy(editingDraft = null, formError = null) }
    }

    fun saveDraft(session: AuthSession, requiredError: String) {
        if (session.user.role != UserRole.ADMIN) return
        val draft = _uiState.value.editingDraft ?: return
        if (draft.studentId.isBlank() || draft.feeName.isBlank()) {
            _uiState.update { it.copy(formError = requiredError) }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true, formError = null) }
            val result = if (draft.id == null) {
                repository.createFee(session, draft)
            } else {
                repository.updateFee(session, draft.id, draft)
            }
            result.fold(
                onSuccess = {
                    _uiState.update { it.copy(isSaving = false, editingDraft = null) }
                    loadFees(session)
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(isSaving = false, formError = err.message ?: "Failed to save fee.")
                    }
                },
            )
        }
    }

    fun openCollectPayment(session: AuthSession, fee: FeeRecord) {
        if (session.user.role != UserRole.ADMIN) return
        val suggestedReceipt = fee.receiptNo?.takeIf { it.isNotBlank() }
            ?: "PMS-RCP-${System.currentTimeMillis().toString().takeLast(6)}"
        _uiState.update {
            it.copy(
                paymentDraft = FeePaymentDraft(
                    fee = fee,
                    collectAmount = fee.balanceDue.takeIf { b -> b > 0.0 }?.toString() ?: "",
                    paymentDate = todayProvider(),
                    receiptNo = suggestedReceipt,
                ),
                formError = null,
            )
        }
    }

    fun updatePaymentDraft(transform: (FeePaymentDraft) -> FeePaymentDraft) {
        _uiState.update { state ->
            val current = state.paymentDraft ?: return@update state
            state.copy(paymentDraft = transform(current), formError = null)
        }
    }

    fun dismissPaymentDialog() {
        _uiState.update { it.copy(paymentDraft = null, formError = null) }
    }

    fun confirmPayment(session: AuthSession) {
        if (session.user.role != UserRole.ADMIN) return
        val draft = _uiState.value.paymentDraft ?: return
        val amt = draft.collectAmount.trim().toDoubleOrNull()
        if (amt == null || amt <= 0.0) {
            _uiState.update { it.copy(formError = "Enter a valid positive payment amount.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true, formError = null) }
            repository.recordPayment(
                session = session,
                fee = draft.fee,
                additionalPayment = amt,
                paymentDate = draft.paymentDate,
                receiptNo = draft.receiptNo,
            ).fold(
                onSuccess = {
                    _uiState.update { it.copy(isSaving = false, paymentDraft = null) }
                    loadFees(session)
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(isSaving = false, formError = err.message ?: "Failed to record payment.")
                    }
                },
            )
        }
    }

    fun requestDelete(fee: FeeRecord) {
        _uiState.update { it.copy(pendingDelete = fee) }
    }

    fun dismissDelete() {
        _uiState.update { it.copy(pendingDelete = null) }
    }

    fun confirmDelete(session: AuthSession) {
        if (session.user.role != UserRole.ADMIN) return
        val target = _uiState.value.pendingDelete ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true, actionError = null) }
            repository.deleteFee(session, target.id).fold(
                onSuccess = {
                    _uiState.update { it.copy(isSaving = false, pendingDelete = null) }
                    loadFees(session)
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            isSaving = false,
                            pendingDelete = null,
                            actionError = err.message ?: "Failed to delete fee.",
                        )
                    }
                },
            )
        }
    }

    fun resetSessionState() {
        searchJob?.cancel()
        lastLoadedUserId = null
        _uiState.value = FeesUiState()
    }

    class Factory(
        private val repository: FeesRepository,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return FeesViewModel(repository = repository) as T
        }
    }
}
