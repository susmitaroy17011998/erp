package com.example.erp.features.dashboard

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Badge
import androidx.compose.material.icons.rounded.Campaign
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.EventAvailable
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.erp.core.i18n.AppLanguage
import com.example.erp.core.i18n.LocalAppLanguage
import com.example.erp.core.i18n.LocalAppStrings
import com.example.erp.core.model.AuthSession
import com.example.erp.core.model.DashboardSnapshot
import com.example.erp.core.model.ErpModule
import com.example.erp.core.model.LinkedStudentInfo
import com.example.erp.core.model.UserRole
import com.example.erp.ui.components.AuthenticatedAvatar
import com.example.erp.ui.components.LanguageTogglePill
import com.example.erp.ui.components.moduleIcon
import com.example.erp.ui.components.roleAccentColor
import com.example.erp.ui.components.roleIcon
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LocalExtendedColors

private data class ShellTab(
    val label: String,
    val icon: ImageVector,
)

@Composable
fun AdminShellScreen(
    session: AuthSession,
    roleNotice: String?,
    snapshot: DashboardSnapshot,
    isSyncingProfile: Boolean,
    onLanguageSelected: (AppLanguage) -> Unit,
    onSyncProfile: () -> Unit,
    onOpenModule: (ErpModule) -> Unit,
    onSignOut: () -> Unit,
) {
    RoleShellContainer(
        expectedRole = UserRole.ADMIN,
        session = session,
        roleNotice = roleNotice,
        snapshot = snapshot,
        isSyncingProfile = isSyncingProfile,
        onLanguageSelected = onLanguageSelected,
        onSyncProfile = onSyncProfile,
        onOpenModule = onOpenModule,
        onSignOut = onSignOut,
    )
}

@Composable
fun TeacherShellScreen(
    session: AuthSession,
    roleNotice: String?,
    snapshot: DashboardSnapshot,
    isSyncingProfile: Boolean,
    onLanguageSelected: (AppLanguage) -> Unit,
    onSyncProfile: () -> Unit,
    onOpenModule: (ErpModule) -> Unit,
    onSignOut: () -> Unit,
) {
    RoleShellContainer(
        expectedRole = UserRole.TEACHER,
        session = session,
        roleNotice = roleNotice,
        snapshot = snapshot,
        isSyncingProfile = isSyncingProfile,
        onLanguageSelected = onLanguageSelected,
        onSyncProfile = onSyncProfile,
        onOpenModule = onOpenModule,
        onSignOut = onSignOut,
    )
}

@Composable
fun StudentShellScreen(
    session: AuthSession,
    roleNotice: String?,
    snapshot: DashboardSnapshot,
    isSyncingProfile: Boolean,
    onLanguageSelected: (AppLanguage) -> Unit,
    onSyncProfile: () -> Unit,
    onOpenModule: (ErpModule) -> Unit,
    onSignOut: () -> Unit,
    onOpenStudentProfile: (String) -> Unit = {},
) {
    RoleShellContainer(
        expectedRole = UserRole.STUDENT,
        session = session,
        roleNotice = roleNotice,
        snapshot = snapshot,
        isSyncingProfile = isSyncingProfile,
        onLanguageSelected = onLanguageSelected,
        onSyncProfile = onSyncProfile,
        onOpenModule = onOpenModule,
        onOpenStudentProfile = onOpenStudentProfile,
        onSignOut = onSignOut,
    )
}

@Composable
fun ParentShellScreen(
    session: AuthSession,
    roleNotice: String?,
    snapshot: DashboardSnapshot,
    isSyncingProfile: Boolean,
    onLanguageSelected: (AppLanguage) -> Unit,
    onSyncProfile: () -> Unit,
    onOpenModule: (ErpModule) -> Unit,
    onSignOut: () -> Unit,
    onOpenStudentProfile: (String) -> Unit = {},
) {
    RoleShellContainer(
        expectedRole = UserRole.PARENT,
        session = session,
        roleNotice = roleNotice,
        snapshot = snapshot,
        isSyncingProfile = isSyncingProfile,
        onLanguageSelected = onLanguageSelected,
        onSyncProfile = onSyncProfile,
        onOpenModule = onOpenModule,
        onOpenStudentProfile = onOpenStudentProfile,
        onSignOut = onSignOut,
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RoleShellContainer(
    expectedRole: UserRole,
    session: AuthSession,
    roleNotice: String?,
    snapshot: DashboardSnapshot,
    isSyncingProfile: Boolean,
    onLanguageSelected: (AppLanguage) -> Unit,
    onSyncProfile: () -> Unit,
    onOpenModule: (ErpModule) -> Unit,
    onSignOut: () -> Unit,
    onOpenStudentProfile: (String) -> Unit = {},
) {
    val strings = LocalAppStrings.current
    val language = LocalAppLanguage.current
    val roleAccent = roleAccentColor(expectedRole)
    val allowedModules = ErpModule.forRole(expectedRole)
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }

    val tabs = listOf(
        ShellTab(strings.dashboardTab, Icons.Rounded.Dashboard),
        ShellTab(strings.modulesTab, Icons.Rounded.Apps),
        ShellTab(strings.profileTab, Icons.Rounded.Person),
    )

    if (selectedTab >= tabs.size) {
        selectedTab = 0
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavRail = maxWidth >= 600.dp

        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            contentWindowInsets = WindowInsets.navigationBars,
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                    ),
                    title = {
                        Column {
                            Text(
                                text = strings.appShortName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                            )
                            Text(
                                text = expectedRole.label(strings),
                                style = MaterialTheme.typography.labelSmall,
                                color = roleAccent,
                                fontWeight = FontWeight.SemiBold,
                            )
                        }
                    },
                    actions = {
                        LanguageTogglePill(
                            currentLanguage = language,
                            onLanguageSelected = onLanguageSelected,
                            modifier = Modifier.padding(end = 8.dp),
                        )
                    },
                )
            },
            bottomBar = {
                if (!useNavRail) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                    ) {
                        tabs.forEachIndexed { index, tab ->
                            NavigationBarItem(
                                selected = selectedTab == index,
                                onClick = { selectedTab = index },
                                icon = { Icon(imageVector = tab.icon, contentDescription = tab.label) },
                                label = { Text(tab.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                modifier = Modifier.testTag("nav_tab_$index"),
                            )
                        }
                    }
                }
            },
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
            ) {
                if (useNavRail) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                        modifier = Modifier.fillMaxHeight(),
                    ) {
                        Spacer(modifier = Modifier.height(12.dp))
                        tabs.forEachIndexed { index, tab ->
                            NavigationRailItem(
                                selected = selectedTab == index,
                                onClick = { selectedTab = index },
                                icon = { Icon(imageVector = tab.icon, contentDescription = tab.label) },
                                label = { Text(tab.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                modifier = Modifier.testTag("nav_rail_$index"),
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxSize(),
                    contentAlignment = Alignment.TopCenter,
                ) {
                    when (selectedTab) {
                        0 -> OverviewTabContent(
                            role = expectedRole,
                            session = session,
                            roleNotice = roleNotice,
                            snapshot = snapshot,
                            modules = allowedModules,
                            onOpenModule = onOpenModule,
                            onOpenStudentProfile = onOpenStudentProfile,
                        )
                        1 -> ModulesDirectoryTab(
                            role = expectedRole,
                            modules = allowedModules,
                            onOpenModule = onOpenModule,
                        )
                        else -> AccountTabContent(
                            role = expectedRole,
                            session = session,
                            isSyncingProfile = isSyncingProfile,
                            onSyncProfile = onSyncProfile,
                            onSignOut = onSignOut,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun OverviewTabContent(
    role: UserRole,
    session: AuthSession,
    roleNotice: String?,
    snapshot: DashboardSnapshot,
    modules: List<ErpModule>,
    onOpenModule: (ErpModule) -> Unit,
    onOpenStudentProfile: (String) -> Unit = {},
) {
    val strings = LocalAppStrings.current
    val accent = roleAccentColor(role)
    val avatarUrl = session.user.staffInfo?.photoUrl ?: session.user.studentInfo?.photoUrl

    LazyColumn(
        modifier = Modifier
            .widthIn(max = 960.dp)
            .fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Surface(
                shape = MaterialTheme.shapes.large,
                color = Color.Transparent,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Box(
                    modifier = Modifier
                        .background(
                            Brush.linearGradient(
                                colors = listOf(accent, accent.copy(alpha = 0.82f)),
                            ),
                            shape = MaterialTheme.shapes.large,
                        )
                        .padding(20.dp),
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            AuthenticatedAvatar(
                                photoUrl = avatarUrl,
                                contentDescription = session.user.fullName,
                                accentColor = Color.White,
                                fallbackIcon = roleIcon(role),
                                size = 56.dp,
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${strings.welcomeGreeting}, ${session.user.fullName}",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                )
                                Text(
                                    text = "${role.label(strings)} • ${strings.schoolFullName}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White.copy(alpha = 0.9f),
                                )
                            }
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = Color.White.copy(alpha = 0.18f),
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Verified,
                                        contentDescription = null,
                                        tint = Color(0xFFFFDEA8),
                                        modifier = Modifier.size(14.dp),
                                    )
                                    Text(
                                        text = if (session.user.profileVerified) {
                                            strings.profileSyncedBadge
                                        } else {
                                            strings.academicSessionLabel
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White,
                                    )
                                }
                            }
                        }

                        if (roleNotice != null) {
                            Surface(
                                shape = MaterialTheme.shapes.small,
                                color = Color.White.copy(alpha = 0.16f),
                            ) {
                                Text(
                                    text = roleNotice,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                )
                            }
                        }
                    }
                }
            }
        }

        // Academy Snapshot Metrics
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = strings.quickOverviewTitle,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    if (role == UserRole.ADMIN || role == UserRole.TEACHER) {
                        MetricTile(
                            label = strings.activeStudentsMetric,
                            value = snapshot.studentCount?.toString() ?: "—",
                            icon = Icons.Rounded.Groups,
                            accent = accent,
                            modifier = Modifier.weight(1f),
                        )
                        MetricTile(
                            label = strings.activeStaffMetric,
                            value = snapshot.staffCount?.toString() ?: "—",
                            icon = Icons.Rounded.School,
                            accent = accent,
                            modifier = Modifier.weight(1f),
                        )
                    }
                    MetricTile(
                        label = strings.publishedNoticesMetric,
                        value = snapshot.publishedNoticeCount?.toString() ?: "—",
                        icon = Icons.Rounded.Campaign,
                        accent = accent,
                        modifier = Modifier.weight(1f),
                    )
                    MetricTile(
                        label = strings.upcomingHolidaysMetric,
                        value = snapshot.holidayCount?.toString() ?: "—",
                        icon = Icons.Rounded.EventAvailable,
                        accent = accent,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }

        // Role-specific profile context card
        when (role) {
            UserRole.TEACHER -> {
                item {
                    TeacherContextCard(session = session, accent = accent)
                }
            }
            UserRole.STUDENT -> {
                item {
                    StudentContextCard(
                        session = session,
                        accent = accent,
                        onOpenStudentProfile = onOpenStudentProfile,
                    )
                }
            }
            UserRole.PARENT -> {
                item {
                    ParentWardsSection(
                        wards = session.user.linkedWards,
                        accent = accent,
                        onOpenStudentProfile = onOpenStudentProfile,
                    )
                }
            }
            UserRole.ADMIN -> Unit
        }

        item {
            Text(
                text = "${strings.plannedModulesHeader} (${modules.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
            )
        }

        items(modules, key = { it.routeId }) { module ->
            ModuleCardRow(
                module = module,
                accent = accent,
                onClick = { onOpenModule(module) },
            )
        }
    }
}

@Composable
private fun MetricTile(
    label: String,
    value: String,
    icon: ImageVector,
    accent: Color,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
        tonalElevation = 1.dp,
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accent,
                modifier = Modifier.size(18.dp),
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(fontFamily = JetBrainsMonoFamily),
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TeacherContextCard(
    session: AuthSession,
    accent: Color,
) {
    val strings = LocalAppStrings.current
    val staff = session.user.staffInfo
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.35f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                text = "${strings.designationLabel}: ${staff?.designation ?: strings.roleTeacher}",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = accent,
            )
            Text(
                text = strings.assignedClassesLabel,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            val classes = staff?.assignedClasses.orEmpty()
            if (classes.isEmpty()) {
                Text(
                    text = strings.noAssignedClassesNotice,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    classes.forEach { cls ->
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = accent.copy(alpha = 0.12f),
                        ) {
                            Text(
                                text = cls,
                                style = MaterialTheme.typography.labelMedium,
                                color = accent,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StudentContextCard(
    session: AuthSession,
    accent: Color,
    onOpenStudentProfile: (String) -> Unit,
) {
    val strings = LocalAppStrings.current
    val student = session.user.studentInfo ?: return
    WardSummaryCard(
        ward = student,
        accent = accent,
        strings = strings,
        onClick = { onOpenStudentProfile(student.studentId) },
    )
}

@Composable
private fun ParentWardsSection(
    wards: List<LinkedStudentInfo>,
    accent: Color,
    onOpenStudentProfile: (String) -> Unit,
) {
    val strings = LocalAppStrings.current
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = strings.linkedWardsTitle,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
        )
        if (wards.isEmpty()) {
            Surface(
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surfaceContainerLowest,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    text = strings.noLinkedWardNotice,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(14.dp),
                )
            }
        } else {
            wards.forEach { ward ->
                WardSummaryCard(
                    ward = ward,
                    accent = accent,
                    strings = strings,
                    onClick = { onOpenStudentProfile(ward.studentId) },
                )
            }
        }
    }
}

@Composable
private fun WardSummaryCard(
    ward: LinkedStudentInfo,
    accent: Color,
    strings: com.example.erp.core.i18n.AppStrings,
    onClick: () -> Unit = {},
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.35f)),
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .testTag("ward_summary_card_${ward.studentId}"),
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            AuthenticatedAvatar(
                photoUrl = ward.photoUrl,
                contentDescription = ward.studentName,
                accentColor = accent,
                fallbackIcon = Icons.Rounded.Badge,
                size = 52.dp,
            )
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                    text = ward.studentName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
                val metaParts = buildList {
                    ward.className?.let { add(it) }
                    ward.rollNo?.let { add("${strings.rollNoLabel}: $it") }
                    ward.admissionNo?.let { add("${strings.admissionNoLabel}: $it") }
                }
                if (metaParts.isNotEmpty()) {
                    Text(
                        text = metaParts.joinToString(" • "),
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                ward.relationship?.let { rel ->
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = accent.copy(alpha = 0.12f),
                    ) {
                        Text(
                            text = rel,
                            style = MaterialTheme.typography.labelSmall,
                            color = accent,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        )
                    }
                }
            }
            Icon(
                imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                contentDescription = strings.modStudents,
                tint = accent,
            )
        }
    }
}

@Composable
private fun ModulesDirectoryTab(
    role: UserRole,
    modules: List<ErpModule>,
    onOpenModule: (ErpModule) -> Unit,
) {
    val strings = LocalAppStrings.current
    val accent = roleAccentColor(role)

    Column(
        modifier = Modifier
            .widthIn(max = 960.dp)
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            text = "${strings.plannedModulesHeader} (${modules.size})",
            style = MaterialTheme.typography.titleLarge,
        )

        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 164.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            items(modules, key = { it.routeId }) { module ->
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.surfaceContainerLowest,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)),
                    tonalElevation = 1.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 136.dp)
                        .clip(MaterialTheme.shapes.medium)
                        .clickable { onOpenModule(module) }
                        .testTag("module_grid_card_${module.routeId}"),
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(accent.copy(alpha = 0.14f)),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(
                                    imageVector = moduleIcon(module),
                                    contentDescription = module.title(strings),
                                    tint = accent,
                                    modifier = Modifier.size(20.dp),
                                )
                            }
                            val isLive = module == ErpModule.NOTICES ||
                                module == ErpModule.HOLIDAYS ||
                                module == ErpModule.STUDENTS ||
                                module == ErpModule.TEACHERS ||
                                module == ErpModule.ADMISSION
                            if (isLive || module.isBatch1Target) {
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = LocalExtendedColors.current.successContainer,
                                ) {
                                    Text(
                                        text = if (isLive) strings.liveModuleBadge else strings.batch1ReadyBadge,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = LocalExtendedColors.current.success,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = module.title(strings),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = module.subtitle(strings),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AccountTabContent(
    role: UserRole,
    session: AuthSession,
    isSyncingProfile: Boolean,
    onSyncProfile: () -> Unit,
    onSignOut: () -> Unit,
) {
    val strings = LocalAppStrings.current
    val accent = roleAccentColor(role)
    val avatarUrl = session.user.staffInfo?.photoUrl ?: session.user.studentInfo?.photoUrl

    Column(
        modifier = Modifier
            .widthIn(max = 600.dp)
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Surface(
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surfaceContainerLowest,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    AuthenticatedAvatar(
                        photoUrl = avatarUrl,
                        contentDescription = session.user.fullName,
                        accentColor = accent,
                        fallbackIcon = roleIcon(role),
                        size = 60.dp,
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = strings.signedInAs,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(
                            text = session.user.fullName,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            text = session.user.email,
                            style = MaterialTheme.typography.bodyMedium.copy(fontFamily = JetBrainsMonoFamily),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }

                if (!session.user.phone.isNullOrBlank()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.Phone,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${strings.phoneLabel}: ${session.user.phone}",
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily),
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = accent.copy(alpha = 0.14f),
                    ) {
                        Text(
                            text = role.label(strings),
                            style = MaterialTheme.typography.labelMedium,
                            color = accent,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        )
                    }
                    if (session.user.profileVerified) {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = LocalExtendedColors.current.successContainer,
                        ) {
                            Text(
                                text = strings.profileSyncedBadge,
                                style = MaterialTheme.typography.labelMedium,
                                color = LocalExtendedColors.current.success,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            )
                        }
                    }
                }
            }
        }

        Button(
            onClick = onSyncProfile,
            enabled = !isSyncingProfile,
            modifier = Modifier
                .fillMaxWidth()
                .defaultMinSize(minHeight = 48.dp)
                .testTag("sync_profile_button"),
        ) {
            if (isSyncingProfile) {
                CircularProgressIndicator(
                    color = MaterialTheme.colorScheme.onPrimary,
                    strokeWidth = 2.dp,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(strings.refreshingLabel)
            } else {
                Icon(imageVector = Icons.Rounded.Refresh, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(strings.refreshProfileButton)
            }
        }

        OutlinedButton(
            onClick = onSignOut,
            modifier = Modifier
                .fillMaxWidth()
                .defaultMinSize(minHeight = 50.dp)
                .testTag("sign_out_button"),
        ) {
            Icon(imageVector = Icons.AutoMirrored.Rounded.Logout, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(strings.signOut)
        }
    }
}

@Composable
private fun ModuleCardRow(
    module: ErpModule,
    accent: Color,
    onClick: () -> Unit,
) {
    val strings = LocalAppStrings.current
    val extended = LocalExtendedColors.current
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
        modifier = Modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 64.dp)
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .testTag("module_row_${module.routeId}"),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(accent.copy(alpha = 0.13f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = moduleIcon(module),
                    contentDescription = module.title(strings),
                    tint = accent,
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = module.title(strings),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    text = module.subtitle(strings),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            val isLive = module == ErpModule.NOTICES ||
                module == ErpModule.HOLIDAYS ||
                module == ErpModule.STUDENTS ||
                module == ErpModule.TEACHERS ||
                module == ErpModule.ADMISSION
            Surface(
                shape = RoundedCornerShape(50),
                color = if (isLive || module.isBatch1Target) {
                    extended.successContainer
                } else {
                    MaterialTheme.colorScheme.surfaceContainerHigh
                },
            ) {
                Text(
                    text = when {
                        isLive -> strings.liveModuleBadge
                        module.isBatch1Target -> strings.batch1ReadyBadge
                        else -> strings.pendingApprovalBadge
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isLive || module.isBatch1Target) {
                        extended.success
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModuleArchitecturePreviewScreen(
    module: ErpModule,
    role: UserRole,
    onBack: () -> Unit,
) {
    val strings = LocalAppStrings.current
    val accent = roleAccentColor(role)

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(module.title(strings)) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("module_back_button")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = strings.backToOverview,
                        )
                    }
                },
            )
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(24.dp),
            contentAlignment = Alignment.Center,
        ) {
            Surface(
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surfaceContainerLowest,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.widthIn(max = 500.dp),
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(accent.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            imageVector = moduleIcon(module),
                            contentDescription = null,
                            tint = accent,
                            modifier = Modifier.size(32.dp),
                        )
                    }
                    Text(
                        text = module.title(strings),
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        text = module.subtitle(strings),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = accent.copy(alpha = 0.10f),
                    ) {
                        Text(
                            text = strings.modulePreviewMessage,
                            style = MaterialTheme.typography.bodySmall,
                            color = accent,
                            modifier = Modifier.padding(14.dp),
                        )
                    }
                }
            }
        }
    }
}
