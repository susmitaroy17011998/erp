package com.example.erp.core.model

enum class NoticeStatusFilter {
    ALL,
    PUBLISHED,
    DRAFT,
    EXPIRED,
}

data class NoticeItem(
    val id: String,
    val title: String,
    val body: String?,
    val noticeType: String,
    val publishDate: String?,
    val expiryDate: String?,
    val isPublished: Boolean,
    val createdBy: String?,
    val createdAt: String,
    val thumbnailUrl: String?,
)

data class NoticeDraft(
    val id: String? = null,
    val title: String = "",
    val body: String = "",
    val noticeType: String = "General",
    val publishDate: String = "",
    val expiryDate: String = "",
    val isPublished: Boolean = false,
    val thumbnailUrl: String = "",
)

data class HolidayItem(
    val id: String,
    val holidayName: String,
    val holidayDate: String,
    val endDate: String?,
    val holidayType: String,
    val description: String?,
    val schoolReopenDate: String?,
    val createdAt: String,
)

data class HolidayDraft(
    val id: String? = null,
    val holidayName: String = "",
    val holidayDate: String = "",
    val endDate: String = "",
    val holidayType: String = "School Holiday",
    val description: String = "",
    val schoolReopenDate: String = "",
)

sealed interface LoadableState<out T> {
    data object Loading : LoadableState<Nothing>
    data class Success<T>(val items: T) : LoadableState<T>
    data class Error(val message: String) : LoadableState<Nothing>
}
