package com.example.erp.core.config

import com.example.BuildConfig

data class SupabaseConfig(
    val url: String,
    val anonKey: String,
) {
    val normalizedBaseUrl: String
        get() = url.trim().trimEnd('/')

    val isConfigured: Boolean
        get() {
            val cleanUrl = normalizedBaseUrl
            val cleanKey = anonKey.trim()
            val hasValidUrl = cleanUrl.startsWith("https://") &&
                !cleanUrl.contains("YOUR_PROJECT_REF", ignoreCase = true)
            val hasValidKey = cleanKey.isNotEmpty() &&
                !cleanKey.contains("YOUR_SUPABASE_ANON_KEY", ignoreCase = true)
            return hasValidUrl && hasValidKey
        }

    companion object {
        fun fromBuildConfig(): SupabaseConfig = SupabaseConfig(
            url = BuildConfig.SUPABASE_URL,
            anonKey = BuildConfig.SUPABASE_ANON_KEY,
        )
    }
}
