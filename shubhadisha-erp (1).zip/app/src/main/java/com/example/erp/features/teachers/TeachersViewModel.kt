package com.example.erp.features.teachers

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.erp.core.model.AssignedClassLink
import com.example.erp.core.model.AuthSession
import com.example.erp.core.model.LoadableState
import com.example.erp.core.model.SchoolClassItem
import com.example.erp.core.model.StaffDraft
import com.example.erp.core.model.StaffProfileOption
import com.example.erp.core.model.StaffRecord
import com.example.erp.core.model.StaffStatusFilter
import com.example.erp.core.model.UserRole
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

@Immutable
data class TeachersUiState(
    val classes: List<SchoolClassItem> = emptyList(),
    val staffState: LoadableState<List<StaffRecord>> = LoadableState.Loading,
    val totalCount: Int? = null,
    val hasMore: Boolean = false,
    val isLoadingMore: Boolean = false,
    val loadMoreError: String? = null,
    val searchQuery: String = "",
    val selectedDesignation: String? = null,
    val selectedStatusFilter: StaffStatusFilter = StaffStatusFilter.ALL,
    val knownColumns: Set<String> = StaffRecord.DEFAULT_CORE_COLUMNS,
    val activeDetailStaff: StaffRecord? = null,
    val detailState: LoadableState<StaffDetailPayload>? = null,
    val profileOptions: List<StaffProfileOption> = emptyList(),
    val showAssignClassDialog: Boolean = false,
    val isMutatingClassLink: Boolean = false,
    val editingDraft: StaffDraft? = null,
    val isSaving: Boolean = false,
    val isUploadingPhoto: Boolean = false,
    val photoUploadNotice: String? = null,
    val formError: String? = null,
    val actionError: String? = null,
)

class TeachersViewModel(
    private val repository: TeachersRepository,
    private val pageSize: Int = TeachersRepository.DEFAULT_PAGE_SIZE,
) : ViewModel() {

    private val _uiState = MutableStateFlow(TeachersUiState())
    val uiState: StateFlow<TeachersUiState> = _uiState.asStateFlow()

    private var lastLoadedUserId: String? = null
    private var searchDebounceJob: Job? = null
    private var activeLoadJob: Job? = null

    fun ensureLoaded(session: AuthSession) {
        val existing = (_uiState.value.staffState as? LoadableState.Success)?.items
        if (lastLoadedUserId == session.user.userId && existing != null) return
        lastLoadedUserId = session.user.userId
        refreshAll(session)
    }

    fun refreshAll(session: AuthSession) {
        viewModelScope.launch {
            val classesResult = repository.fetchClasses(session)
            classesResult.onSuccess { list ->
                _uiState.update { it.copy(classes = list) }
            }
            loadFirstPage(session)
        }
    }

    fun refreshList(session: AuthSession) {
        loadFirstPage(session)
    }

    fun updateSearchQuery(session: AuthSession, query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        searchDebounceJob?.cancel()
        searchDebounceJob = viewModelScope.launch {
            delay(280L)
            loadFirstPage(session)
        }
    }

    fun selectDesignationFilter(session: AuthSession, designation: String?) {
        _uiState.update { it.copy(selectedDesignation = designation) }
        loadFirstPage(session)
    }

    fun selectStatusFilter(session: AuthSession, filter: StaffStatusFilter) {
        if (session.user.role != UserRole.ADMIN) return
        _uiState.update { it.copy(selectedStatusFilter = filter) }
        loadFirstPage(session)
    }

    private fun loadFirstPage(session: AuthSession) {
        activeLoadJob?.cancel()
        activeLoadJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    staffState = LoadableState.Loading,
                    loadMoreError = null,
                    isLoadingMore = false,
                    actionError = null,
                )
            }
            val current = _uiState.value
            val result = repository.fetchStaffPage(
                session = session,
                designationFilter = current.selectedDesignation,
                statusFilter = current.selectedStatusFilter,
                query = current.searchQuery,
                offset = 0,
                limit = pageSize,
            )
            result.fold(
                onSuccess = { page ->
                    _uiState.update { state ->
                        state.copy(
                            staffState = LoadableState.Success(page.items),
                            totalCount = page.totalCount,
                            hasMore = page.hasMore,
                            knownColumns = state.knownColumns + page.detectedColumns,
                        )
                    }
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            staffState = LoadableState.Error(err.message ?: "Failed to load staff."),
                        )
                    }
                },
            )
        }
    }

    fun loadNextPage(session: AuthSession) {
        val state = _uiState.value
        val existing = (state.staffState as? LoadableState.Success)?.items ?: return
        if (!state.hasMore || state.isLoadingMore) return

        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingMore = true, loadMoreError = null) }
            val result = repository.fetchStaffPage(
                session = session,
                designationFilter = state.selectedDesignation,
                statusFilter = state.selectedStatusFilter,
                query = state.searchQuery,
                offset = existing.size,
                limit = pageSize,
            )
            result.fold(
                onSuccess = { page ->
                    _uiState.update { latest ->
                        val base = (latest.staffState as? LoadableState.Success)?.items.orEmpty()
                        val merged = (base + page.items).distinctBy { it.id }
                        latest.copy(
                            staffState = LoadableState.Success(merged),
                            totalCount = page.totalCount ?: latest.totalCount,
                            hasMore = page.hasMore,
                            isLoadingMore = false,
                            knownColumns = latest.knownColumns + page.detectedColumns,
                        )
                    }
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            isLoadingMore = false,
                            loadMoreError = err.message ?: "Failed to load more staff.",
                        )
                    }
                },
            )
        }
    }

    fun openStaffProfile(session: AuthSession, staff: StaffRecord) {
        _uiState.update {
            it.copy(
                activeDetailStaff = staff,
                detailState = LoadableState.Loading,
                actionError = null,
            )
        }
        viewModelScope.launch {
            val result = repository.fetchStaffDetail(session, staff)
            _uiState.update { state ->
                state.copy(
                    activeDetailStaff = result.getOrNull()?.staff ?: state.activeDetailStaff,
                    detailState = result.fold(
                        onSuccess = { LoadableState.Success(it) },
                        onFailure = { LoadableState.Error(it.message ?: "Failed to load staff profile.") },
                    ),
                )
            }
        }
    }

    fun closeStaffProfile() {
        _uiState.update {
            it.copy(
                activeDetailStaff = null,
                detailState = null,
                showAssignClassDialog = false,
            )
        }
    }

    fun openAddStaff(session: AuthSession) {
        if (session.user.role != UserRole.ADMIN) return
        loadProfileOptionsIfNeeded(session)
        _uiState.update {
            it.copy(
                editingDraft = StaffDraft(designation = "Teacher", isActive = true),
                formError = null,
                photoUploadNotice = null,
            )
        }
    }

    fun openEditStaff(session: AuthSession, staff: StaffRecord) {
        if (session.user.role != UserRole.ADMIN) return
        loadProfileOptionsIfNeeded(session)
        _uiState.update {
            it.copy(
                editingDraft = StaffDraft(
                    id = staff.id,
                    profileId = staff.profileId.orEmpty(),
                    staffName = staff.staffName,
                    designation = staff.designation,
                    phone = staff.phone.orEmpty(),
                    joiningDate = staff.joiningDate.orEmpty(),
                    photoPath = staff.photoPath.orEmpty(),
                    photoPreviewUrl = staff.photoUrl,
                    isActive = staff.isActive,
                ),
                formError = null,
                photoUploadNotice = null,
            )
        }
    }

    private fun loadProfileOptionsIfNeeded(session: AuthSession) {
        if (_uiState.value.profileOptions.isNotEmpty()) return
        viewModelScope.launch {
            repository.fetchTeacherProfileOptions(session).onSuccess { list ->
                _uiState.update { it.copy(profileOptions = list) }
            }
        }
    }

    fun updateDraft(transform: (StaffDraft) -> StaffDraft) {
        _uiState.update { state ->
            val current = state.editingDraft ?: return@update state
            state.copy(editingDraft = transform(current), formError = null)
        }
    }

    fun dismissEditor() {
        _uiState.update {
            it.copy(
                editingDraft = null,
                formError = null,
                photoUploadNotice = null,
            )
        }
    }

    fun uploadDraftPhoto(
        session: AuthSession,
        imageBytes: ByteArray,
        mimeType: String,
        extension: String,
        successNotice: String,
    ) {
        if (session.user.role != UserRole.ADMIN) return
        val draft = _uiState.value.editingDraft ?: return
        val staffKey = draft.id ?: draft.staffName.ifBlank { "staff" }

        viewModelScope.launch {
            _uiState.update { it.copy(isUploadingPhoto = true, formError = null, photoUploadNotice = null) }
            repository.uploadStaffPhoto(
                session = session,
                staffKey = staffKey,
                imageBytes = imageBytes,
                mimeType = mimeType,
                fileExtension = extension,
            ).fold(
                onSuccess = { uploaded ->
                    _uiState.update { state ->
                        state.copy(
                            isUploadingPhoto = false,
                            editingDraft = state.editingDraft?.copy(
                                photoPath = uploaded.storagePath,
                                photoPreviewUrl = uploaded.authenticatedUrl,
                            ),
                            photoUploadNotice = successNotice,
                        )
                    }
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            isUploadingPhoto = false,
                            formError = err.message ?: "Failed to upload staff photo.",
                        )
                    }
                },
            )
        }
    }

    fun saveDraft(session: AuthSession, nameRequiredError: String) {
        if (session.user.role != UserRole.ADMIN) return
        val state = _uiState.value
        val draft = state.editingDraft ?: return
        if (draft.staffName.trim().isEmpty()) {
            _uiState.update { it.copy(formError = nameRequiredError) }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true, formError = null, actionError = null) }
            val result = if (draft.id == null) {
                repository.createStaff(session, draft, state.knownColumns)
            } else {
                repository.updateStaff(session, draft.id, draft, state.knownColumns)
            }
            result.fold(
                onSuccess = { saved ->
                    _uiState.update { latest ->
                        val currentList = (latest.staffState as? LoadableState.Success)?.items.orEmpty()
                        val updatedList = if (draft.id == null) {
                            (listOf(saved) + currentList).distinctBy { it.id }
                        } else {
                            currentList.map { if (it.id == saved.id) saved else it }
                        }
                        val updatedDetail = if (latest.activeDetailStaff?.id == saved.id) {
                            (latest.detailState as? LoadableState.Success)?.items?.copy(staff = saved)
                                ?.let { LoadableState.Success(it) } ?: latest.detailState
                        } else {
                            latest.detailState
                        }
                        latest.copy(
                            staffState = LoadableState.Success(updatedList),
                            totalCount = if (draft.id == null) (latest.totalCount ?: 0) + 1 else latest.totalCount,
                            activeDetailStaff = if (latest.activeDetailStaff?.id == saved.id) saved else latest.activeDetailStaff,
                            detailState = updatedDetail,
                            editingDraft = null,
                            isSaving = false,
                            photoUploadNotice = null,
                        )
                    }
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            isSaving = false,
                            formError = err.message ?: "Failed to save staff record.",
                        )
                    }
                },
            )
        }
    }

    fun openAssignClassDialog(session: AuthSession) {
        if (session.user.role != UserRole.ADMIN) return
        _uiState.update { it.copy(showAssignClassDialog = true) }
    }

    fun dismissAssignClassDialog() {
        _uiState.update { it.copy(showAssignClassDialog = false) }
    }

    fun assignClass(session: AuthSession, staff: StaffRecord, classId: String) {
        if (session.user.role != UserRole.ADMIN) return
        val profileId = staff.profileId.orEmpty()
        viewModelScope.launch {
            _uiState.update { it.copy(isMutatingClassLink = true, actionError = null) }
            repository.assignClassTeacher(session, profileId, classId).fold(
                onSuccess = {
                    _uiState.update { it.copy(isMutatingClassLink = false, showAssignClassDialog = false) }
                    openStaffProfile(session, staff)
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            isMutatingClassLink = false,
                            actionError = err.message ?: "Failed to assign class.",
                        )
                    }
                },
            )
        }
    }

    fun removeClassAssignment(session: AuthSession, staff: StaffRecord, link: AssignedClassLink) {
        if (session.user.role != UserRole.ADMIN) return
        viewModelScope.launch {
            _uiState.update { it.copy(isMutatingClassLink = true, actionError = null) }
            repository.removeClassTeacher(session, link).fold(
                onSuccess = {
                    _uiState.update { it.copy(isMutatingClassLink = false) }
                    openStaffProfile(session, staff)
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            isMutatingClassLink = false,
                            actionError = err.message ?: "Failed to remove class assignment.",
                        )
                    }
                },
            )
        }
    }

    fun resetSessionState() {
        searchDebounceJob?.cancel()
        activeLoadJob?.cancel()
        lastLoadedUserId = null
        _uiState.value = TeachersUiState()
    }

    class Factory(
        private val repository: TeachersRepository,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return TeachersViewModel(repository = repository) as T
        }
    }
}
