package com.example.erp.core.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.erp.core.i18n.AppLanguage
import com.example.erp.core.model.AuthSession
import com.example.erp.core.model.UserProfile
import com.example.erp.core.model.UserRole
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

private val Context.erpDataStore: DataStore<Preferences> by preferencesDataStore(name = "shubhadisha_erp_store")

class SecureSessionStore(private val context: Context) {

    private object Keys {
        val LANGUAGE = stringPreferencesKey("app_language")
        val ACCESS_TOKEN_ENC = stringPreferencesKey("enc_access_token")
        val REFRESH_TOKEN_ENC = stringPreferencesKey("enc_refresh_token")
        val EXPIRES_AT = longPreferencesKey("expires_at")
        val USER_ID = stringPreferencesKey("user_id")
        val USER_EMAIL = stringPreferencesKey("user_email")
        val USER_NAME = stringPreferencesKey("user_name")
        val USER_ROLE = stringPreferencesKey("user_role")
        val USER_PHONE = stringPreferencesKey("user_phone")
        val PROFILE_VERIFIED = booleanPreferencesKey("profile_verified")
    }

    val languageFlow: Flow<AppLanguage> = context.erpDataStore.data.map { prefs ->
        AppLanguage.fromCode(prefs[Keys.LANGUAGE])
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.erpDataStore.edit { prefs ->
            prefs[Keys.LANGUAGE] = language.code
        }
    }

    suspend fun saveSession(session: AuthSession) {
        val encAccess = encrypt(session.accessToken)
        val encRefresh = encrypt(session.refreshToken)
        context.erpDataStore.edit { prefs ->
            prefs[Keys.ACCESS_TOKEN_ENC] = encAccess
            prefs[Keys.REFRESH_TOKEN_ENC] = encRefresh
            prefs[Keys.EXPIRES_AT] = session.expiresAtEpochSeconds
            prefs[Keys.USER_ID] = session.user.userId
            prefs[Keys.USER_EMAIL] = session.user.email
            prefs[Keys.USER_NAME] = session.user.fullName
            prefs[Keys.USER_ROLE] = session.user.role.key
            if (session.user.phone != null) {
                prefs[Keys.USER_PHONE] = session.user.phone
            } else {
                prefs.remove(Keys.USER_PHONE)
            }
            prefs[Keys.PROFILE_VERIFIED] = session.user.profileVerified
        }
    }

    suspend fun readSession(): AuthSession? {
        val prefs = context.erpDataStore.data.first()
        val encAccess = prefs[Keys.ACCESS_TOKEN_ENC] ?: return null
        val encRefresh = prefs[Keys.REFRESH_TOKEN_ENC] ?: return null
        val userId = prefs[Keys.USER_ID] ?: return null
        val email = prefs[Keys.USER_EMAIL] ?: return null
        val fullName = prefs[Keys.USER_NAME] ?: email
        val role = UserRole.fromRaw(prefs[Keys.USER_ROLE])
        val expiresAt = prefs[Keys.EXPIRES_AT] ?: 0L
        val phone = prefs[Keys.USER_PHONE]
        val verified = prefs[Keys.PROFILE_VERIFIED] ?: false

        val accessToken = decrypt(encAccess) ?: return null
        val refreshToken = decrypt(encRefresh) ?: return null

        return AuthSession(
            accessToken = accessToken,
            refreshToken = refreshToken,
            expiresAtEpochSeconds = expiresAt,
            user = UserProfile(
                userId = userId,
                email = email,
                fullName = fullName,
                role = role,
                phone = phone,
                profileVerified = verified,
            ),
        )
    }

    suspend fun clearSession() {
        context.erpDataStore.edit { prefs ->
            prefs.remove(Keys.ACCESS_TOKEN_ENC)
            prefs.remove(Keys.REFRESH_TOKEN_ENC)
            prefs.remove(Keys.EXPIRES_AT)
            prefs.remove(Keys.USER_ID)
            prefs.remove(Keys.USER_EMAIL)
            prefs.remove(Keys.USER_NAME)
            prefs.remove(Keys.USER_ROLE)
            prefs.remove(Keys.USER_PHONE)
            prefs.remove(Keys.PROFILE_VERIFIED)
        }
    }

    private fun getOrCreateAesKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        val existingKey = (keyStore.getEntry(KEY_ALIAS, null) as? KeyStore.SecretKeyEntry)?.secretKey
        if (existingKey != null) return existingKey

        val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }

    private fun encrypt(plainText: String): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateAesKey())
        val iv = cipher.iv
        val cipherBytes = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
        val ivEncoded = Base64.encodeToString(iv, Base64.NO_WRAP)
        val dataEncoded = Base64.encodeToString(cipherBytes, Base64.NO_WRAP)
        return "$ivEncoded:$dataEncoded"
    }

    private fun decrypt(payload: String): String? {
        return runCatching {
            val parts = payload.split(":")
            if (parts.size != 2) return null
            val iv = Base64.decode(parts[0], Base64.NO_WRAP)
            val cipherBytes = Base64.decode(parts[1], Base64.NO_WRAP)
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateAesKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(cipherBytes), Charsets.UTF_8)
        }.getOrNull()
    }

    private companion object {
        const val ANDROID_KEYSTORE = "AndroidKeyStore"
        const val KEY_ALIAS = "shubhadisha_session_aes_key"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
    }
}
