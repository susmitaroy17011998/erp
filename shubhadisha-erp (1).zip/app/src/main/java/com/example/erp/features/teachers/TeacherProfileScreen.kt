package com.example.erp.features.teachers

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.erp.core.i18n.AppStrings
import com.example.erp.core.i18n.LocalAppStrings
import com.example.erp.core.model.AssignedClassLink
import com.example.erp.core.model.AuthSession
import com.example.erp.core.model.LinkedAccountProfile
import com.example.erp.core.model.LoadableState
import com.example.erp.core.model.SchoolClassItem
import com.example.erp.core.model.StaffRecord
import com.example.erp.core.model.StaffRoutineSlot
import com.example.erp.core.model.UserRole
import com.example.erp.ui.components.AuthenticatedAvatar
import com.example.erp.ui.components.roleAccentColor
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LocalExtendedColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherProfileContent(
    session: AuthSession,
    staff: StaffRecord,
    detailState: LoadableState<StaffDetailPayload>?,
    allClasses: List<SchoolClassItem>,
    showAssignClassDialog: Boolean,
    isMutatingClassLink: Boolean,
    actionError: String?,
    showTopBar: Boolean,
    onBack: () -> Unit,
    onRefresh: () -> Unit,
    onEdit: () -> Unit,
    onOpenAssignClass: () -> Unit,
    onDismissAssignClass: () -> Unit,
    onConfirmAssignClass: (classId: String) -> Unit,
    onRemoveClassAssignment: (AssignedClassLink) -> Unit,
) {
    val strings = LocalAppStrings.current
    val isAdmin = session.user.role == UserRole.ADMIN
    val accent = roleAccentColor(session.user.role)
    var selectedTab by rememberSaveable(staff.id) { mutableIntStateOf(0) }

    val payload = (detailState as? LoadableState.Success)?.items
    val displayStaff = payload?.staff ?: staff
    val linkedProfile = payload?.linkedProfile
    val assignedClasses = payload?.assignedClasses.orEmpty()
    val routineSlots = payload?.routineSlots.orEmpty()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets.navigationBars,
        topBar = {
            if (showTopBar) {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                    ),
                    title = {
                        Column {
                            Text(
                                text = displayStaff.staffName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                text = displayStaff.designation,
                                style = MaterialTheme.typography.labelSmall,
                                color = accent,
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.testTag("staff_profile_back_button"),
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = strings.backToOverview,
                            )
                        }
                    },
                    actions = {
                        IconButton(onClick = onRefresh) {
                            Icon(Icons.Rounded.Refresh, contentDescription = strings.refreshActionDesc)
                        }
                        if (isAdmin) {
                            IconButton(
                                onClick = onEdit,
                                modifier = Modifier.testTag("staff_profile_edit_button"),
                            ) {
                                Icon(Icons.Rounded.Edit, contentDescription = strings.editButton)
                            }
                        }
                    },
                )
            }
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter,
        ) {
            LazyColumn(
                modifier = Modifier
                    .widthIn(max = 820.dp)
                    .fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                item {
                    StaffHeroCard(
                        staff = displayStaff,
                        accent = accent,
                        isAdmin = isAdmin,
                        strings = strings,
                        onEdit = onEdit,
                    )
                }

                if (actionError != null) {
                    item {
                        Surface(
                            shape = MaterialTheme.shapes.small,
                            color = MaterialTheme.colorScheme.errorContainer,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(
                                text = actionError,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.padding(12.dp),
                            )
                        }
                    }
                }

                item {
                    val tabs = listOf(
                        strings.teachers.staffOverviewTab,
                        strings.assignedClassesLabel,
                        strings.teachers.staffRoutineTab,
                    )
                    PrimaryTabRow(selectedTabIndex = selectedTab) {
                        tabs.forEachIndexed { index, title ->
                            Tab(
                                selected = selectedTab == index,
                                onClick = { selectedTab = index },
                                text = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                modifier = Modifier.testTag("staff_profile_tab_$index"),
                            )
                        }
                    }
                }

                if (detailState is LoadableState.Loading) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.Center,
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        }
                    }
                } else if (detailState is LoadableState.Error) {
                    item {
                        Surface(
                            shape = MaterialTheme.shapes.small,
                            color = MaterialTheme.colorScheme.errorContainer,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    text = detailState.message,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    modifier = Modifier.weight(1f),
                                )
                                TextButton(onClick = onRefresh) {
                                    Text(strings.retryButton)
                                }
                            }
                        }
                    }
                }

                when (selectedTab) {
                    0 -> item {
                        StaffOverviewCard(
                            staff = displayStaff,
                            linkedProfile = linkedProfile,
                            strings = strings,
                        )
                    }
                    1 -> item {
                        StaffAssignedClassesCard(
                            staff = displayStaff,
                            assignedClasses = assignedClasses,
                            isAdmin = isAdmin,
                            isMutating = isMutatingClassLink,
                            accent = accent,
                            strings = strings,
                            onOpenAssignClass = onOpenAssignClass,
                            onRemoveClass = onRemoveClassAssignment,
                        )
                    }
                    else -> item {
                        StaffRoutineCard(
                            slots = routineSlots,
                            accent = accent,
                            strings = strings,
                        )
                    }
                }
            }
        }
    }

    if (showAssignClassDialog && isAdmin) {
        AssignClassTeacherDialog(
            classes = allClasses,
            alreadyAssignedIds = assignedClasses.map { it.classId }.toSet(),
            isSaving = isMutatingClassLink,
            onDismiss = onDismissAssignClass,
            onAssign = onConfirmAssignClass,
        )
    }
}

@Composable
private fun StaffHeroCard(
    staff: StaffRecord,
    accent: Color,
    isAdmin: Boolean,
    strings: AppStrings,
    onEdit: () -> Unit,
) {
    val extended = LocalExtendedColors.current
    Surface(
        shape = MaterialTheme.shapes.large,
        color = Color.Transparent,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Box(
            modifier = Modifier
                .background(
                    Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.82f))),
                    shape = MaterialTheme.shapes.large,
                )
                .padding(18.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    AuthenticatedAvatar(
                        photoUrl = staff.photoUrl,
                        contentDescription = staff.staffName,
                        accentColor = Color.White,
                        fallbackIcon = Icons.Rounded.School,
                        size = 64.dp,
                    )
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = staff.staffName,
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            text = staff.designation,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.9f),
                        )
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = if (staff.isActive) extended.successContainer else MaterialTheme.colorScheme.errorContainer,
                        ) {
                            Text(
                                text = if (staff.isActive) strings.statusActiveBadge else strings.statusInactiveBadge,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (staff.isActive) extended.success else MaterialTheme.colorScheme.error,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                            )
                        }
                    }
                    if (isAdmin) {
                        IconButton(onClick = onEdit) {
                            Icon(Icons.Rounded.Edit, contentDescription = strings.editButton, tint = Color.White)
                        }
                    }
                }
                Text(
                    text = "${strings.teachers.staffIdLabel}: ${staff.id}",
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                    color = Color.White.copy(alpha = 0.88f),
                )
            }
        }
    }
}

@Composable
private fun StaffOverviewCard(
    staff: StaffRecord,
    linkedProfile: LinkedAccountProfile?,
    strings: AppStrings,
) {
    val extended = LocalExtendedColors.current
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            StaffFieldRow(strings.teachers.staffNameLabel, staff.staffName)
            StaffFieldRow(strings.designationLabel, staff.designation)
            StaffFieldRow(strings.phoneLabel, staff.phone ?: linkedProfile?.phone ?: strings.notProvidedValue, mono = true)
            StaffFieldRow(strings.teachers.joiningDateLabel, staff.joiningDate ?: strings.notProvidedValue, mono = true)

            Surface(
                shape = MaterialTheme.shapes.small,
                color = if (linkedProfile != null || !staff.profileId.isNullOrBlank()) {
                    extended.successContainer.copy(alpha = 0.55f)
                } else {
                    MaterialTheme.colorScheme.surfaceContainerLow
                },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.VerifiedUser,
                        contentDescription = null,
                        tint = if (linkedProfile != null || !staff.profileId.isNullOrBlank()) {
                            extended.success
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                    )
                    Column {
                        Text(
                            text = strings.linkedAccountLabel,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                        )
                        Text(
                            text = when {
                                linkedProfile != null -> "${linkedProfile.fullName} (${linkedProfile.role ?: "staff"})"
                                !staff.profileId.isNullOrBlank() -> "${strings.accountLinkedBadge} (${staff.profileId.take(8)}…)"
                                else -> strings.accountNotLinkedLabel
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StaffAssignedClassesCard(
    staff: StaffRecord,
    assignedClasses: List<AssignedClassLink>,
    isAdmin: Boolean,
    isMutating: Boolean,
    accent: Color,
    strings: AppStrings,
    onOpenAssignClass: () -> Unit,
    onRemoveClass: (AssignedClassLink) -> Unit,
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = strings.assignedClassesLabel,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
                if (isAdmin && !staff.profileId.isNullOrBlank()) {
                    OutlinedButton(
                        onClick = onOpenAssignClass,
                        enabled = !isMutating,
                        modifier = Modifier
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("assign_class_teacher_button"),
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(strings.teachers.assignClassButton)
                    }
                }
            }

            if (staff.profileId.isNullOrBlank()) {
                Text(
                    text = strings.teachers.linkPortalAccountNotice,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else if (assignedClasses.isEmpty()) {
                Text(
                    text = strings.noAssignedClassesNotice,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                assignedClasses.forEach { link ->
                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = MaterialTheme.colorScheme.surfaceContainerLow,
                        border = BorderStroke(1.dp, accent.copy(alpha = 0.25f)),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text(
                                text = link.displayLabel,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = accent,
                            )
                            if (isAdmin) {
                                IconButton(
                                    onClick = { onRemoveClass(link) },
                                    enabled = !isMutating,
                                    modifier = Modifier.testTag("remove_class_link_${link.classId}"),
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Delete,
                                        contentDescription = strings.deleteButton,
                                        tint = MaterialTheme.colorScheme.error,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StaffRoutineCard(
    slots: List<StaffRoutineSlot>,
    accent: Color,
    strings: AppStrings,
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Rounded.Schedule, contentDescription = null, tint = accent)
                Text(
                    text = strings.teachers.staffRoutineTab,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
            }
            if (slots.isEmpty()) {
                Text(
                    text = strings.teachers.noRoutineSlotsNotice,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                slots.forEach { slot ->
                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = MaterialTheme.colorScheme.surfaceContainerLow,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Text(
                                    text = "${slot.day} • ${slot.className}",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = accent,
                                )
                                Text(
                                    text = String.format(strings.teachers.periodLabelFormat, slot.period),
                                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                                )
                            }
                            Text(
                                text = slot.subject,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                            )
                            val meta = listOfNotNull(
                                slot.routineTime.takeIf { it.isNotBlank() },
                                slot.room.takeIf { it.isNotBlank() }?.let { "Room $it" },
                            ).joinToString(" • ")
                            if (meta.isNotBlank()) {
                                Text(
                                    text = meta,
                                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AssignClassTeacherDialog(
    classes: List<SchoolClassItem>,
    alreadyAssignedIds: Set<String>,
    isSaving: Boolean,
    onDismiss: () -> Unit,
    onAssign: (String) -> Unit,
) {
    val strings = LocalAppStrings.current
    val available = classes.filter { it.id !in alreadyAssignedIds }
    var selectedClassId by remember(available) { mutableStateOf(available.firstOrNull()?.id.orEmpty()) }

    AlertDialog(
        onDismissRequest = { if (!isSaving) onDismiss() },
        title = { Text(strings.teachers.assignClassButton) },
        text = {
            if (available.isEmpty()) {
                Text(strings.allClassesFilter)
            } else {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    available.forEach { cls ->
                        FilterChip(
                            selected = selectedClassId == cls.id,
                            onClick = { selectedClassId = cls.id },
                            label = { Text(cls.displayLabel) },
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onAssign(selectedClassId) },
                enabled = !isSaving && selectedClassId.isNotBlank(),
            ) {
                Text(strings.teachers.assignClassButton)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !isSaving) {
                Text(strings.cancel)
            }
        },
    )
}

@Composable
private fun StaffFieldRow(label: String, value: String, mono: Boolean = false) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            text = value,
            style = if (mono) {
                MaterialTheme.typography.bodyMedium.copy(fontFamily = JetBrainsMonoFamily)
            } else {
                MaterialTheme.typography.bodyMedium
            },
            fontWeight = FontWeight.Medium,
        )
    }
}
