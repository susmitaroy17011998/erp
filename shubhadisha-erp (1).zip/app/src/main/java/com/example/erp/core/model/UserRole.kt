package com.example.erp.core.model

import com.example.erp.core.i18n.AppStrings

enum class UserRole(val key: String) {
    ADMIN("admin"),
    TEACHER("teacher"),
    STUDENT("student"),
    PARENT("parent"),
    ;

    fun label(strings: AppStrings): String = when (this) {
        ADMIN -> strings.roleAdmin
        TEACHER -> strings.roleTeacher
        STUDENT -> strings.roleStudent
        PARENT -> strings.roleParent
    }

    fun description(strings: AppStrings): String = when (this) {
        ADMIN -> strings.roleAdminDesc
        TEACHER -> strings.roleTeacherDesc
        STUDENT -> strings.roleStudentDesc
        PARENT -> strings.roleParentDesc
    }

    companion object {
        fun fromRaw(raw: String?, fallback: UserRole = ADMIN): UserRole {
            val normalized = raw?.trim()?.lowercase().orEmpty()
            return when {
                normalized in setOf("admin", "administrator", "principal", "super_admin", "office") -> ADMIN
                normalized in setOf("teacher", "faculty", "staff", "educator") -> TEACHER
                normalized in setOf("student", "learner", "pupil") -> STUDENT
                normalized in setOf("parent", "guardian", "mother", "father") -> PARENT
                else -> fallback
            }
        }
    }
}
