package com.example.erp.core.network

import com.example.erp.core.model.AuthSession
import com.example.erp.core.model.DashboardSnapshot
import com.example.erp.core.model.LinkedStaffInfo
import com.example.erp.core.model.LinkedStudentInfo
import com.example.erp.core.model.UserProfile
import com.example.erp.core.model.UserRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

class InactiveAccountException : Exception("Account is inactive")
class ProfileMissingException : Exception("Profile record missing")

class SupabaseAuthService(
    private val client: SupabaseClient,
) {
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun signInWithPassword(
        email: String,
        password: String,
        selectedRoleHint: UserRole,
    ): Result<AuthSession> = withContext(Dispatchers.IO) {
        runCatching {
            if (!client.config.isConfigured) {
                error("Supabase URL and Anon Key must be configured in AI Studio Secrets.")
            }

            val payload = JSONObject().apply {
                put("email", email.trim())
                put("password", password)
            }.toString()

            val request = client.authenticatedRequestBuilder("/auth/v1/token?grant_type=password")
                .post(payload.toRequestBody(jsonMediaType))
                .build()

            val baseSession = client.httpClient.newCall(request).execute().use { response ->
                val rawBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    error(extractErrorMessage(rawBody, response.code))
                }
                parseBaseSession(rawBody, selectedRoleHint)
            }

            hydrateProfileAndRoleLinks(baseSession)
        }
    }

    suspend fun refreshSession(
        refreshToken: String,
        fallbackRole: UserRole,
    ): Result<AuthSession> = withContext(Dispatchers.IO) {
        runCatching {
            if (!client.config.isConfigured) {
                error("Supabase configuration missing.")
            }

            val payload = JSONObject().apply {
                put("refresh_token", refreshToken)
            }.toString()

            val request = client.authenticatedRequestBuilder("/auth/v1/token?grant_type=refresh_token")
                .post(payload.toRequestBody(jsonMediaType))
                .build()

            val baseSession = client.httpClient.newCall(request).execute().use { response ->
                val rawBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    error(extractErrorMessage(rawBody, response.code))
                }
                parseBaseSession(rawBody, fallbackRole)
            }

            hydrateProfileAndRoleLinks(baseSession)
        }
    }

    suspend fun hydrateProfileAndRoleLinks(baseSession: AuthSession): AuthSession =
        withContext(Dispatchers.IO) {
            val uid = encode(baseSession.user.userId)
            val profileRows = getJsonArray(
                path = "/rest/v1/profiles?id=eq.$uid&select=id,full_name,role,phone,is_active&limit=1",
                accessToken = baseSession.accessToken,
            )

            if (profileRows == null || profileRows.length() == 0) {
                runCatching { signOut(baseSession.accessToken) }
                throw ProfileMissingException()
            }

            val p = profileRows.getJSONObject(0)
            val isActive = p.optBoolean("is_active", true)
            if (!isActive) {
                runCatching { signOut(baseSession.accessToken) }
                throw InactiveAccountException()
            }

            val profileName = p.optString("full_name").takeIf { it.isNotBlank() }
                ?: baseSession.user.fullName
            val profileRole = UserRole.fromRaw(
                raw = p.optString("role"),
                fallback = UserRole.STUDENT,
            )
            val phone = p.optString("phone").takeIf { it.isNotBlank() && it != "null" }

            var resolvedUser = baseSession.user.copy(
                fullName = profileName,
                role = profileRole,
                phone = phone,
                isActive = true,
                profileVerified = true,
            )

            resolvedUser = when (resolvedUser.role) {
                UserRole.TEACHER -> {
                    val staff = fetchStaffInfo(resolvedUser.userId, baseSession.accessToken)
                    if (staff != null && !staff.second) {
                        runCatching { signOut(baseSession.accessToken) }
                        throw InactiveAccountException()
                    }
                    resolvedUser.copy(staffInfo = staff?.first)
                }
                UserRole.STUDENT -> {
                    val student = fetchStudentInfo(resolvedUser.userId, baseSession.accessToken)
                    if (student != null && !student.second) {
                        runCatching { signOut(baseSession.accessToken) }
                        throw InactiveAccountException()
                    }
                    resolvedUser.copy(studentInfo = student?.first)
                }
                UserRole.PARENT -> {
                    val wards = fetchParentWards(resolvedUser.userId, baseSession.accessToken)
                    resolvedUser.copy(linkedWards = wards)
                }
                UserRole.ADMIN -> {
                    val staff = fetchStaffInfo(resolvedUser.userId, baseSession.accessToken)
                    resolvedUser.copy(staffInfo = staff?.first)
                }
            }

            baseSession.copy(user = resolvedUser)
        }

    suspend fun fetchDashboardSnapshot(session: AuthSession): DashboardSnapshot =
        withContext(Dispatchers.IO) {
            val token = session.accessToken
            var studentCount: Int? = null
            var staffCount: Int? = null

            // Check portal_shared_data projection first (lightweight single-row summary)
            val sharedRows = getJsonArray(
                path = "/rest/v1/portal_shared_data?school_id=eq.shubhadisha&select=payload&limit=1",
                accessToken = token,
            )
            if (sharedRows != null && sharedRows.length() > 0) {
                val payload = sharedRows.getJSONObject(0).optJSONObject("payload")
                if (payload != null) {
                    if (payload.has("studentCount") && !payload.isNull("studentCount")) {
                        studentCount = payload.optInt("studentCount")
                    }
                    if (payload.has("staffCount") && !payload.isNull("staffCount")) {
                        staffCount = payload.optInt("staffCount")
                    }
                }
            }

            // If Admin/Teacher, query exact active counts via PostgREST Prefer: count=exact
            if (session.user.role == UserRole.ADMIN) {
                studentCount = fetchExactCount("/rest/v1/students?is_active=eq.true&select=id", token)
                    ?: studentCount
                staffCount = fetchExactCount("/rest/v1/staff?is_active=eq.true&select=id", token)
                    ?: staffCount
            }

            val noticeCount = fetchExactCount(
                "/rest/v1/notices?is_published=eq.true&select=id",
                token,
            )
            val holidayCount = fetchExactCount(
                "/rest/v1/holidays?select=id",
                token,
            )

            DashboardSnapshot(
                studentCount = studentCount,
                staffCount = staffCount,
                publishedNoticeCount = noticeCount,
                holidayCount = holidayCount,
            )
        }

    private fun fetchStaffInfo(profileId: String, accessToken: String): Pair<LinkedStaffInfo, Boolean>? {
        val uid = encode(profileId)
        val rows = getJsonArray(
            path = "/rest/v1/staff?profile_id=eq.$uid&select=id,staff_name,designation,phone,joining_date,photo_url,is_active&limit=1",
            accessToken = accessToken,
        ) ?: return null
        if (rows.length() == 0) return null

        val s = rows.getJSONObject(0)
        val staffActive = s.optBoolean("is_active", true)
        val classRows = getJsonArray(
            path = "/rest/v1/class_teachers?teacher_profile_id=eq.$uid&select=classes(class_name)",
            accessToken = accessToken,
        )
        val classNames = mutableListOf<String>()
        if (classRows != null) {
            for (i in 0 until classRows.length()) {
                val cls = classRows.getJSONObject(i).optJSONObject("classes")
                val name = cls?.optString("class_name")?.takeIf { it.isNotBlank() }
                if (name != null) classNames.add(name)
            }
        }

        val info = LinkedStaffInfo(
            staffId = s.getString("id"),
            staffName = s.optString("staff_name"),
            designation = s.optString("designation", "Teacher"),
            phone = s.optString("phone").takeIf { it.isNotBlank() && it != "null" },
            joiningDate = s.optString("joining_date").takeIf { it.isNotBlank() && it != "null" },
            photoUrl = client.resolveStorageUrl(s.optString("photo_url").takeIf { it != "null" }),
            assignedClasses = classNames,
        )
        return info to staffActive
    }

    private fun fetchStudentInfo(profileId: String, accessToken: String): Pair<LinkedStudentInfo, Boolean>? {
        val uid = encode(profileId)
        val rows = getJsonArray(
            path = "/rest/v1/students?profile_id=eq.$uid&select=id,student_name,admission_no,roll_no,class_id,photo_url,is_active,classes(class_name)&limit=1",
            accessToken = accessToken,
        ) ?: return null
        if (rows.length() == 0) return null

        val st = rows.getJSONObject(0)
        val studentActive = st.optBoolean("is_active", true)
        val clsName = st.optJSONObject("classes")?.optString("class_name")
            ?.takeIf { it.isNotBlank() && it != "null" }

        val info = LinkedStudentInfo(
            studentId = st.getString("id"),
            studentName = st.optString("student_name"),
            admissionNo = st.optString("admission_no").takeIf { it.isNotBlank() && it != "null" },
            rollNo = st.optString("roll_no").takeIf { it.isNotBlank() && it != "null" },
            classId = st.optString("class_id").takeIf { it.isNotBlank() && it != "null" },
            className = clsName,
            photoUrl = client.resolveStorageUrl(st.optString("photo_url").takeIf { it != "null" }),
        )
        return info to studentActive
    }

    private fun fetchParentWards(parentProfileId: String, accessToken: String): List<LinkedStudentInfo> {
        val uid = encode(parentProfileId)
        val rows = getJsonArray(
            path = "/rest/v1/student_guardians?parent_profile_id=eq.$uid&select=relationship,students(id,student_name,admission_no,roll_no,class_id,photo_url,classes(class_name))",
            accessToken = accessToken,
        ) ?: return emptyList()

        val list = mutableListOf<LinkedStudentInfo>()
        for (i in 0 until rows.length()) {
            val row = rows.getJSONObject(i)
            val st = row.optJSONObject("students") ?: continue
            val clsName = st.optJSONObject("classes")?.optString("class_name")
                ?.takeIf { it.isNotBlank() && it != "null" }
            list.add(
                LinkedStudentInfo(
                    studentId = st.getString("id"),
                    studentName = st.optString("student_name"),
                    admissionNo = st.optString("admission_no").takeIf { it.isNotBlank() && it != "null" },
                    rollNo = st.optString("roll_no").takeIf { it.isNotBlank() && it != "null" },
                    classId = st.optString("class_id").takeIf { it.isNotBlank() && it != "null" },
                    className = clsName,
                    photoUrl = client.resolveStorageUrl(st.optString("photo_url").takeIf { it != "null" }),
                    relationship = row.optString("relationship").takeIf { it.isNotBlank() && it != "null" },
                ),
            )
        }
        return list
    }

    private fun getJsonArray(path: String, accessToken: String): JSONArray? {
        val request = client.authenticatedRequestBuilder(path = path, accessToken = accessToken)
            .get()
            .build()
        return runCatching {
            client.httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val body = response.body?.string().orEmpty()
                if (body.isBlank()) null else JSONArray(body)
            }
        }.getOrNull()
    }

    private fun fetchExactCount(path: String, accessToken: String): Int? {
        val request = client.authenticatedRequestBuilder(path = path, accessToken = accessToken)
            .header("Prefer", "count=exact")
            .header("Range", "0-0")
            .head()
            .build()
        return runCatching {
            client.httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val contentRange = response.header("Content-Range") ?: return null
                contentRange.substringAfter("/", "").toIntOrNull()
            }
        }.getOrNull()
    }

    suspend fun sendPasswordReset(email: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            if (!client.config.isConfigured) {
                error("Supabase configuration missing.")
            }

            val payload = JSONObject().apply {
                put("email", email.trim())
            }.toString()

            val request = client.authenticatedRequestBuilder("/auth/v1/recover")
                .post(payload.toRequestBody(jsonMediaType))
                .build()

            client.httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val rawBody = response.body?.string().orEmpty()
                    error(extractErrorMessage(rawBody, response.code))
                }
            }
        }
    }

    suspend fun signOut(accessToken: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            if (!client.config.isConfigured) return@runCatching
            val request = client.authenticatedRequestBuilder(
                path = "/auth/v1/logout",
                accessToken = accessToken,
            )
                .post("{}".toRequestBody(jsonMediaType))
                .build()

            client.httpClient.newCall(request).execute().close()
        }
    }

    private fun parseBaseSession(rawJson: String, fallbackRole: UserRole): AuthSession {
        val root = JSONObject(rawJson)
        val accessToken = root.getString("access_token")
        val refreshToken = root.optString("refresh_token", "")
        val expiresIn = root.optLong("expires_in", 3600L)
        val expiresAt = root.optLong(
            "expires_at",
            (System.currentTimeMillis() / 1000L) + expiresIn,
        )

        val userObj = root.getJSONObject("user")
        val userId = userObj.getString("id")
        val email = userObj.optString("email", "")
        val userMeta = userObj.optJSONObject("user_metadata")
        val appMeta = userObj.optJSONObject("app_metadata")

        val fullName = userMeta?.optString("full_name")?.takeIf { it.isNotBlank() }
            ?: userMeta?.optString("name")?.takeIf { it.isNotBlank() }
            ?: email.substringBefore("@").ifBlank { "Academy User" }

        val rawRole = appMeta?.optString("role")?.takeIf { it.isNotBlank() }
            ?: userMeta?.optString("role")?.takeIf { it.isNotBlank() }
            ?: userMeta?.optString("user_role")?.takeIf { it.isNotBlank() }

        val resolvedRole = UserRole.fromRaw(rawRole, fallback = fallbackRole)

        return AuthSession(
            accessToken = accessToken,
            refreshToken = refreshToken,
            expiresAtEpochSeconds = expiresAt,
            user = UserProfile(
                userId = userId,
                email = email,
                fullName = fullName,
                role = resolvedRole,
            ),
        )
    }

    private fun extractErrorMessage(rawBody: String, statusCode: Int): String {
        return runCatching {
            val json = JSONObject(rawBody)
            json.optString("error_description").takeIf { it.isNotBlank() }
                ?: json.optString("msg").takeIf { it.isNotBlank() }
                ?: json.optString("message").takeIf { it.isNotBlank() }
                ?: "Authentication error (HTTP $statusCode)"
        }.getOrDefault("Authentication failed (HTTP $statusCode)")
    }

    private fun encode(value: String): String = URLEncoder.encode(value, "UTF-8")
}
