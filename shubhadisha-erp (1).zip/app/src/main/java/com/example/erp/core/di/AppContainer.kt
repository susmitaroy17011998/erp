package com.example.erp.core.di

import android.content.Context
import coil.ImageLoader
import com.example.erp.core.config.SupabaseConfig
import com.example.erp.core.network.SupabaseAuthService
import com.example.erp.core.network.SupabaseClient
import com.example.erp.core.security.SecureSessionStore
import com.example.erp.features.admission.AdmissionRepository
import com.example.erp.features.notices.NoticesHolidaysRepository
import com.example.erp.features.students.StudentsRepository
import com.example.erp.features.teachers.TeachersRepository
import java.util.concurrent.atomic.AtomicReference

class AppContainer(context: Context) {
    val supabaseConfig: SupabaseConfig = SupabaseConfig.fromBuildConfig()
    val sessionStore: SecureSessionStore = SecureSessionStore(context.applicationContext)
    val supabaseClient: SupabaseClient = SupabaseClient(supabaseConfig)
    val authService: SupabaseAuthService = SupabaseAuthService(supabaseClient)
    val noticesHolidaysRepository: NoticesHolidaysRepository by lazy {
        NoticesHolidaysRepository(supabaseClient)
    }
    val studentsRepository: StudentsRepository by lazy {
        StudentsRepository(supabaseClient)
    }
    val teachersRepository: TeachersRepository by lazy {
        TeachersRepository(supabaseClient)
    }
    val admissionRepository: AdmissionRepository by lazy {
        AdmissionRepository(supabaseClient, studentsRepository)
    }

    private val activeTokenRef = AtomicReference<String?>(null)

    fun updateActiveAccessToken(token: String?) {
        activeTokenRef.set(token)
    }

    val authenticatedImageLoader: ImageLoader by lazy {
        supabaseClient.createAuthenticatedImageLoader(
            context = context.applicationContext,
            accessTokenProvider = { activeTokenRef.get() },
        )
    }
}
