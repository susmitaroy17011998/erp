package com.example.erp.core.model

import androidx.compose.runtime.Immutable

@Immutable
data class AssignedClassLink(
    val id: String? = null,
    val teacherProfileId: String,
    val classId: String,
    val className: String,
    val section: String? = null,
) {
    val displayLabel: String
        get() = listOfNotNull(className.takeIf { it.isNotBlank() }, section?.takeIf { it.isNotBlank() })
            .joinToString(" • ")
}

@Immutable
data class StaffRoutineSlot(
    val id: String,
    val day: String,
    val className: String,
    val period: Int,
    val subject: String,
    val teacher: String,
    val routineTime: String,
    val room: String,
)

@Immutable
data class StaffRecord(
    val id: String,
    val profileId: String?,
    val staffName: String,
    val designation: String,
    val phone: String?,
    val joiningDate: String?,
    val photoPath: String?,
    val photoUrl: String?,
    val isActive: Boolean,
    val createdAt: String = "",
    val extraFields: Map<String, String> = emptyMap(),
    val knownColumns: Set<String> = DEFAULT_CORE_COLUMNS,
) {
    companion object {
        val DEFAULT_CORE_COLUMNS = setOf(
            "id",
            "profile_id",
            "staff_name",
            "designation",
            "phone",
            "joining_date",
            "photo_url",
            "is_active",
        )
    }
}

@Immutable
data class StaffDraft(
    val id: String? = null,
    val profileId: String = "",
    val staffName: String = "",
    val designation: String = "Teacher",
    val phone: String = "",
    val joiningDate: String = "",
    val photoPath: String = "",
    val photoPreviewUrl: String? = null,
    val isActive: Boolean = true,
)

@Immutable
data class StaffProfileOption(
    val id: String,
    val fullName: String,
    val role: String,
    val phone: String?,
)

enum class StaffStatusFilter {
    ALL,
    ACTIVE,
    INACTIVE,
}
