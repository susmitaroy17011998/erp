package com.example.erp.ui.navigation

import com.example.erp.core.model.ErpModule
import com.example.erp.core.model.UserRole

object AppRoutes {
    const val LOGIN = "login"
    const val ADMIN_SHELL = "admin_shell"
    const val TEACHER_SHELL = "teacher_shell"
    const val STUDENT_SHELL = "student_shell"
    const val PARENT_SHELL = "parent_shell"
    const val NOTICES = "notices"
    const val HOLIDAYS = "holidays"
    const val STUDENTS = "students"
    const val TEACHERS = "teachers"
    const val ADMISSION = "admission"
    const val MODULE_ROUTE_PATTERN = "module/{moduleId}"

    fun shellForRole(role: UserRole): String = when (role) {
        UserRole.ADMIN -> ADMIN_SHELL
        UserRole.TEACHER -> TEACHER_SHELL
        UserRole.STUDENT -> STUDENT_SHELL
        UserRole.PARENT -> PARENT_SHELL
    }

    fun moduleRoute(module: ErpModule): String = when (module) {
        ErpModule.NOTICES -> NOTICES
        ErpModule.HOLIDAYS -> HOLIDAYS
        ErpModule.STUDENTS -> STUDENTS
        ErpModule.TEACHERS -> TEACHERS
        ErpModule.ADMISSION -> ADMISSION
        else -> "module/${module.routeId}"
    }
}
