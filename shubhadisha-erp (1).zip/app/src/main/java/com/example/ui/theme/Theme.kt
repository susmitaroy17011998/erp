package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.example.erp.core.i18n.AppLanguage

private val LightColorScheme = lightColorScheme(
    primary = HeritageTeal,
    onPrimary = Color.White,
    primaryContainer = HeritageTealContainer,
    onPrimaryContainer = OnHeritageTealContainer,
    secondary = TerracottaAccent,
    onSecondary = Color.White,
    secondaryContainer = TerracottaContainer,
    onSecondaryContainer = OnTerracottaContainer,
    tertiary = MarigoldGold,
    onTertiary = Color.White,
    tertiaryContainer = MarigoldContainer,
    onTertiaryContainer = OnMarigoldContainer,
    background = IvoryBackground,
    onBackground = InkPrimary,
    surface = IvoryBackground,
    onSurface = InkPrimary,
    surfaceVariant = SlateSurfaceVariant,
    onSurfaceVariant = InkSecondary,
    surfaceContainerLowest = IvorySurfaceLowest,
    surfaceContainerLow = IvorySurfaceLow,
    surfaceContainer = IvorySurface,
    surfaceContainerHigh = IvorySurfaceHigh,
    surfaceContainerHighest = IvorySurfaceHighest,
    outline = InkOutline,
    outlineVariant = InkOutlineVariant,
    error = SemanticErrorLight,
    onError = Color.White,
    errorContainer = SemanticErrorContainerLight,
)

private val DarkColorScheme = darkColorScheme(
    primary = HeritageTealLight,
    onPrimary = Color(0xFF003543),
    primaryContainer = HeritageTealDarkContainer,
    onPrimaryContainer = HeritageTealContainer,
    secondary = TerracottaLight,
    onSecondary = Color(0xFF5D1900),
    secondaryContainer = TerracottaDarkContainer,
    onSecondaryContainer = TerracottaContainer,
    tertiary = MarigoldLight,
    onTertiary = Color(0xFF442C00),
    tertiaryContainer = MarigoldDarkContainer,
    onTertiaryContainer = MarigoldContainer,
    background = ObsidianBackground,
    onBackground = LightInkPrimary,
    surface = ObsidianBackground,
    onSurface = LightInkPrimary,
    surfaceVariant = ObsidianSurfaceVariant,
    onSurfaceVariant = LightInkSecondary,
    surfaceContainerLowest = ObsidianSurfaceLowest,
    surfaceContainerLow = ObsidianSurfaceLow,
    surfaceContainer = ObsidianSurface,
    surfaceContainerHigh = ObsidianSurfaceHigh,
    surfaceContainerHighest = ObsidianSurfaceHighest,
    outline = DarkOutline,
    outlineVariant = DarkOutlineVariant,
    error = SemanticErrorDark,
    onError = Color(0xFF690005),
    errorContainer = SemanticErrorContainerDark,
)

@Immutable
data class ErpExtendedColors(
    val success: Color,
    val successContainer: Color,
    val warning: Color,
    val warningContainer: Color,
    val adminAccent: Color,
    val teacherAccent: Color,
    val studentAccent: Color,
    val parentAccent: Color,
)

private val LightExtendedColors = ErpExtendedColors(
    success = SemanticSuccess,
    successContainer = SemanticSuccessContainer,
    warning = SemanticWarning,
    warningContainer = SemanticWarningContainer,
    adminAccent = RoleAdminColor,
    teacherAccent = RoleTeacherColor,
    studentAccent = RoleStudentColor,
    parentAccent = RoleParentColor,
)

private val DarkExtendedColors = ErpExtendedColors(
    success = SemanticSuccessDark,
    successContainer = SemanticSuccessContainerDark,
    warning = SemanticWarningDark,
    warningContainer = SemanticWarningContainerDark,
    adminAccent = HeritageTealLight,
    teacherAccent = Color(0xFF7AD8A8),
    studentAccent = Color(0xFF90C2FF),
    parentAccent = TerracottaLight,
)

val LocalExtendedColors = staticCompositionLocalOf { LightExtendedColors }

@Composable
fun ShubhadishaErpTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    language: AppLanguage = AppLanguage.ENGLISH,
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val extendedColors = if (darkTheme) DarkExtendedColors else LightExtendedColors

    CompositionLocalProvider(LocalExtendedColors provides extendedColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = shubhadishaTypography(language),
            shapes = ShubhadishaShapes,
            content = content,
        )
    }
}
