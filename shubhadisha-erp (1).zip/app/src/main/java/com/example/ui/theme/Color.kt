package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Brand Palette — Bengal Academic Heritage
val HeritageTeal = Color(0xFF0F4C5C)
val HeritageTealLight = Color(0xFF83D2E5)
val HeritageTealContainer = Color(0xFFCBEBF2)
val OnHeritageTealContainer = Color(0xFF001F28)
val HeritageTealDarkContainer = Color(0xFF003543)

val TerracottaAccent = Color(0xFFC85A32)
val TerracottaLight = Color(0xFFFFB59D)
val TerracottaContainer = Color(0xFFFFDAD0)
val OnTerracottaContainer = Color(0xFF3B0B00)
val TerracottaDarkContainer = Color(0xFF7D2E12)

val MarigoldGold = Color(0xFFB87D14)
val MarigoldLight = Color(0xFFF6BE62)
val MarigoldContainer = Color(0xFFFFDEA8)
val OnMarigoldContainer = Color(0xFF291800)
val MarigoldDarkContainer = Color(0xFF5A3D00)

// Surfaces — Warm Ivory Parchment (Light) & Deep Obsidian Slate (Dark)
val IvoryBackground = Color(0xFFFAF8F3)
val IvorySurfaceLowest = Color(0xFFFFFFFF)
val IvorySurfaceLow = Color(0xFFF4F2EC)
val IvorySurface = Color(0xFFEEECE5)
val IvorySurfaceHigh = Color(0xFFE8E6DF)
val IvorySurfaceHighest = Color(0xFFE2E0D9)
val SlateSurfaceVariant = Color(0xFFE1E8EA)

val ObsidianBackground = Color(0xFF0D1416)
val ObsidianSurfaceLowest = Color(0xFF080E10)
val ObsidianSurfaceLow = Color(0xFF131C1F)
val ObsidianSurface = Color(0xFF182226)
val ObsidianSurfaceHigh = Color(0xFF222D31)
val ObsidianSurfaceHighest = Color(0xFF2C383D)
val ObsidianSurfaceVariant = Color(0xFF3A464A)

val InkPrimary = Color(0xFF171D1E)
val InkSecondary = Color(0xFF444D50)
val InkOutline = Color(0xFF70797B)
val InkOutlineVariant = Color(0xFFC4CDCF)

val LightInkPrimary = Color(0xFFE4EAEB)
val LightInkSecondary = Color(0xFFB3C0C3)
val DarkOutline = Color(0xFF899396)
val DarkOutlineVariant = Color(0xFF3F484B)

val SemanticErrorLight = Color(0xFFBA1A1A)
val SemanticErrorContainerLight = Color(0xFFFFDAD6)
val SemanticErrorDark = Color(0xFFFFB4AB)
val SemanticErrorContainerDark = Color(0xFF93000A)

val SemanticSuccess = Color(0xFF1B6B46)
val SemanticSuccessContainer = Color(0xFFC7F2D9)
val SemanticSuccessDark = Color(0xFF7AD8A8)
val SemanticSuccessContainerDark = Color(0xFF0E4A2F)

val SemanticWarning = Color(0xFF9C5D00)
val SemanticWarningContainer = Color(0xFFFFE0B2)
val SemanticWarningDark = Color(0xFFFFC168)
val SemanticWarningContainerDark = Color(0xFF5D3600)

// Role Identity Accents
val RoleAdminColor = Color(0xFF0F4C5C)
val RoleTeacherColor = Color(0xFF1F6E4A)
val RoleStudentColor = Color(0xFF265C9E)
val RoleParentColor = Color(0xFFC85A32)
